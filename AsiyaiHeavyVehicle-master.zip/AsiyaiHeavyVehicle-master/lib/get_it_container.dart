// import 'package:asiayai_heavy_vehicle_app/data/dio_client.dart';
// import 'package:asiayai_heavy_vehicle_app/data/repository/auth_repo.dart';
// import 'package:asiayai_heavy_vehicle_app/data/repository/get_addresses_repo.dart';
// import 'package:asiayai_heavy_vehicle_app/data/repository/get_master_data.dart';
// import 'package:asiayai_heavy_vehicle_app/data/repository/post_addre_repo.dart';
// import 'package:asiayai_heavy_vehicle_app/data/repository/register_repo.dart';
// import 'package:asiayai_heavy_vehicle_app/data/repository/request_repo.dart';
// import 'package:asiayai_heavy_vehicle_app/data/repository/requirement_repo.dart';
// import 'package:asiayai_heavy_vehicle_app/data/repository/uploadfile_repo.dart';
// import 'package:asiayai_heavy_vehicle_app/provider/address_provider.dart';
// import 'package:asiayai_heavy_vehicle_app/provider/auth_provider.dart';
// import 'package:asiayai_heavy_vehicle_app/provider/master_data_provider.dart';
// import 'package:asiayai_heavy_vehicle_app/provider/post_addres_provider.dart';
// import 'package:asiayai_heavy_vehicle_app/provider/register_provider.dart';
// import 'package:asiayai_heavy_vehicle_app/provider/request_provider.dart';
// import 'package:asiayai_heavy_vehicle_app/provider/requirement_provider.dart';
// import 'package:asiayai_heavy_vehicle_app/utils/app_constants.dart';
// import 'package:get_it/get_it.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// GetIt gi = GetIt.instance;

// Future<void> init() async {
//   final sharedpreserence = await SharedPreferences.getInstance();
//   gi.registerLazySingleton(() => sharedpreserence);
//   gi.registerLazySingleton(
//       () => DioClient(baseUrl: AppConstants.BASE_URL, sharedPreferences: gi()));

//   // repo

//   gi.registerLazySingleton(
//       () => AuthRepo(dioClient: gi(), sharedPreferences: gi()));

//   gi.registerLazySingleton(
//       () => RegisterRepo(dioClient: gi(), sharedPreferences: gi()));

//   gi.registerLazySingleton(
//       () => AddressRepo(dioClient: gi(), sharedPreferences: gi()));

//   gi.registerLazySingleton(
//       () => ImageUploadRepo(dioClient: gi(), sharedPreferences: gi()));

//   gi.registerLazySingleton(
//       () => MasterDataRepo(dioClient: gi(), sharedPreferences: gi()));

//   gi.registerLazySingleton(
//       () => RequirementRepo(dioClient: gi(), sharedPreferences: gi()));

//   gi.registerLazySingleton(
//       () => RequestRepo(dioClient: gi(), sharedPreferences: gi()));

//   gi.registerLazySingleton(
//       () => PostAddressRepo(dioClient: gi(), sharedPreferences: gi()));

//   // providers
//   gi.registerFactory(() => AuthProvider(
//         authRepo: gi(),
//         sharedPreferences: gi(),
//       ));
//   gi.registerFactory(() => AddressProvider(addressRepo: gi()));
//   gi.registerFactory(() => RegisterProvider(registerRepo: gi()));
//   gi.registerFactory(() => MasterDataProvider(masterDataRepo: gi()));
//   // gi.registerFactory(() => RequirementProvider(requirementRepo: gi()));
//   gi.registerFactory(() => RequestProvider(requestRepo: gi()));
//   gi.registerFactory(() => PostAddressProvider(postAddressRepo: gi()));
// }
