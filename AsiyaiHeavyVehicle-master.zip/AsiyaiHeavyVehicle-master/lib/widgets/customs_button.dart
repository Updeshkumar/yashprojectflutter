import 'package:flutter/material.dart';

import '../utils/colour_resource.dart';
import '../utils/text_styles.dart';

class CustomButton extends StatelessWidget {
  String text;
  double? height;
  double? width;
  VoidCallback onTap;
  Color? buttonColor;
  Color? textColor;
  double? textSize;
  Color? borderColor;
  IconData? icons;
  Color? iconColor;
  String? image;

  CustomButton(
      {required this.text,
      this.height,
      this.width,
      this.icons,
      this.iconColor = Colors.black,
      required this.onTap,
      this.buttonColor = Colours.YELLOW_DARK,
      this.textSize,
      this.borderColor,
      this.image,
      this.textColor = Colors.white});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        color: buttonColor,
        borderRadius: BorderRadius.circular(20),
        // border: Border.all(color:bord , width: 1),
      ),
      child: InkWell(
        onTap: onTap,
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (image != null)
                Image.asset(
                  image.toString(),
                  color: Colours.PRIMARY_BLACK,
                  height: 20,
                ),
              if (image != null)
                const SizedBox(
                  width: 10,
                ),
              Text(
                text,
                style: TextStyles.ktext16(context).copyWith(
                    color: textColor,
                    fontSize: textSize,
                    fontWeight: FontWeight.w500),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
