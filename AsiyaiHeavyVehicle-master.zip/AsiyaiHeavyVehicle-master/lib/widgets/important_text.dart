import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:flutter/material.dart';

class ImportantText extends StatelessWidget {
  String name;
  ImportantText({required this.name});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 5),
      child: Text(
        name.toUpperCase().toString(),
        style: TextStyles.ktext18(context),
      ),
    );
  }
}
