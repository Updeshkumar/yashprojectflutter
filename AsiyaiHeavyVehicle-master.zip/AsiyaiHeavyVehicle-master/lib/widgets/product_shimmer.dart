import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

class ProductShimmer extends StatelessWidget {
  const ProductShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height / 7,
      child: ListView.builder(
          itemCount: 5,
          itemBuilder: (context, index) {
            return Shimmer.fromColors(
              baseColor: Colours.PRIMARY_GREY_LIGHT.withOpacity(0.3),
              highlightColor: Colours.PRIMARY_BLUE_MILD.withOpacity(0.5),
              enabled: true,
              // Provider.of<UserProvider>(context).vehicle_details.length ==
              //     0,
              child: Container(
                height: size.height / 7,
                width: size.width / 3.6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            );
          }),
    );
  }
}
