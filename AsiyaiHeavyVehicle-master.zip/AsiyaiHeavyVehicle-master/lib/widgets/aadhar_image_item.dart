import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:flutter/material.dart';

class AadharImageItem extends StatefulWidget {
  String? title;
  File? selectedFile;
  AadharImageItem({this.title, this.selectedFile});

  @override
  State<AadharImageItem> createState() => _AadharImageItemState();
}

class _AadharImageItemState extends State<AadharImageItem> {
  @override
  Size? _size;
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      height: _size!.height * 0.25,
      decoration: BoxDecoration(
        color: Colours.PRIMARY_BLUE_MILD,
        borderRadius: BorderRadius.circular(12),
      ),
      child: widget.selectedFile != null
          ? ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(
                File(widget.selectedFile!.path),
                fit: BoxFit.fill,
              ),
            )
          : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  Images.docs_icon,
                  color: Colours.YELLOW_LIGHT,
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  widget.title!,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Colours.YELLOW_LIGHT,
                  ),
                )
              ],
            ),
    );
  }
}
