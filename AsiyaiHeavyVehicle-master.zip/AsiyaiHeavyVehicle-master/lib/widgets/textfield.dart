import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/colour_resource.dart';
import '../utils/text_styles.dart';

class IconTextField extends StatelessWidget {
  String? title, image, labelText;
  TextEditingController? controller;
  Function? onValidate;
  TextInputType? textInputType;
  List<TextInputFormatter>? textInputFormatter;

  int? maxlenght;

  IconTextField(
      {this.image,
      this.title,
      this.controller,
      this.onValidate,
      this.labelText,
      this.textInputFormatter,
      this.maxlenght,
      this.textInputType});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Container(
      margin: EdgeInsets.only(bottom: size.height / 80),
      child: TextFormField(
        autofocus: false,
        controller: controller,
        keyboardType: textInputType,
        inputFormatters: textInputFormatter,
        maxLength: maxlenght,
        textInputAction: TextInputAction.next,
        validator: (value) {
          return onValidate!(value);
        },
        style: TextStyles.ktext18(context).copyWith(
          color: Colours.PRIMARY_GREY_LIGHT,
          fontWeight: FontWeight.w500,
        ),
        decoration: InputDecoration(
          labelText: labelText,
          contentPadding:
              const EdgeInsets.only(left: 20, right: 15, top: 15, bottom: 10),
          fillColor: Colours.PRIMARY_BLUE_MILD,
          filled: true,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(6),
            borderSide: const BorderSide(color: Colours.PRIMARY_BLUE_MILD),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colours.PRIMARY_BLUE_MILD),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colours.PRIMARY_BLUE_MILD),
          ),
          hintText: title,
          hintStyle: TextStyles.ktext16(context).copyWith(
            color: Colours.PRIMARY_GREY_LIGHT,
            fontWeight: FontWeight.w500,
          ),
          // suffixIcon: image != null
          //     ? Image.asset(
          //         image.toString(),
          //         scale: 4,
          //       )
          //     : null,
        ),
      ),
    );
  }
}
