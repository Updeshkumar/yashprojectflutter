import 'package:flutter/material.dart';

import '../utils/colour_resource.dart';
import '../utils/text_styles.dart';

class BlankData extends StatelessWidget {
  const BlankData({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      width: double.infinity,
      child: Center(
        child: Text(
          "NO DATA",
          style:
              TextStyles.ktext32(context).copyWith(color: Colours.PRIMARY_GREY),
        ),
      ),
    );
  }
}
