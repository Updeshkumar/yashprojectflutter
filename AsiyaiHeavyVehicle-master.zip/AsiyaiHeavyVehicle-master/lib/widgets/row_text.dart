import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:flutter/material.dart';

class Rowtext extends StatelessWidget {
  String title1, title2;
  Rowtext({required this.title1, required this.title2});

  @override
  Widget build(BuildContext context) {
    Size _size = MediaQuery.of(context).size;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: _size.width * 0.4,
            child: Text(
              title1,
              style: TextStyles.ktext16(context),
            ),
          ),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  title2.toUpperCase(),
                  style: TextStyles.ktext16(context)
                      .copyWith(color: Colours.SKY_BLUE_LIGHT),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
