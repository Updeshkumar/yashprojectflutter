import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:flutter/material.dart';

import '../utils/size_config.dart';
import '../utils/text_styles.dart';

class LogoText extends StatelessWidget {
  const LogoText({super.key});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Stack(
      children: [
        Padding(
          padding: EdgeInsets.symmetric(
            horizontal: getHorizontalSize(25),
          ),
          child: Container(
            height: size.height / 6.4,
            width: size.width / 1.38,
            child: Image.asset(
              Images.splash_logo,
            ),
          ),
        ),
        Positioned(
          bottom: size.height / 60,
          left: getHorizontalSize(-40),
          right: getHorizontalSize(40),
          child: RichText(
            textAlign: TextAlign.center,
            text: TextSpan(
              style: TextStyles.ktext12(context)
                  .copyWith(color: Colours.YELLOW_DARK),
              children: [
                const TextSpan(
                  text: " ASIYAI ",
                ),
                TextSpan(
                  text: "HEAVY ",
                  style: TextStyles.ktext12(context)
                      .copyWith(color: Colours.WHITE_COLOR),
                ),
                const TextSpan(
                  text: "VEHICLE",
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
