import 'package:another_flushbar/flushbar.dart';

import '../utils/colour_resource.dart';

class AppSnackBar {
  static appSnackBar({
    required context,
    required String message,
    required String title,
    bool isError = false,
  }) {
    return Flushbar(
      duration: Duration(seconds: isError ? 3 : 2),
      isDismissible: true,
      title: title,
      message: message,
      backgroundColor: isError ? Colours.RED_COLOR : Colours.YELLOW_DARK,
      flushbarPosition: FlushbarPosition.TOP,
    ).show(context);
  }
}
