import 'package:flutter/material.dart';

import '../utils/colour_resource.dart';

class ImageUploader {
  Widget defaultImageContainer(String defaultImage, BuildContext context,
      {String? title}) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height * 0.2,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colours.PRIMARY_BLUE_MILD,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colours.PRIMARY_GREY_LIGHT, width: 2),
        // image: DecorationImage(
        //   image: AssetImage(defaultImage.toString()),
        // ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image(
            image: AssetImage(defaultImage),
            color: Colors.white30,
            height: 50,
          ),
          SizedBox(
            height: 20,
          ),
          Text(
            title.toString(),
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w500,
              color: Colors.white30,
            ),
          )
        ],
      ),
    );
  }

  //
}
