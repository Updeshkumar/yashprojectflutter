import 'dart:io';

import 'package:flutter/material.dart';

import '../utils/colour_resource.dart';

class ResuableImageContainer extends StatelessWidget {
  File image;
  VoidCallback photoIconTap;
  VoidCallback uploadIconTap;

  ResuableImageContainer(
      {required this.image,
      required this.photoIconTap,
      required this.uploadIconTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
          color: Colours.PRIMARY_BLUE_MILD,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colours.PRIMARY_GREY_LIGHT, width: 2),
          image: DecorationImage(
            image: FileImage(image),
            fit: BoxFit.fill,
            opacity: 0.4,
          )),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colours.PRIMARY_GREY_LIGHT.withOpacity(0.5),
            ),
            child: GestureDetector(
              //
              onTap: photoIconTap,
              child: const Icon(
                Icons.photo_library_sharp,
                color: Colours.PRIMARY_BLUE,
              ),
            ),
          ),
          const SizedBox(
            width: 40,
          ),
          Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colours.PRIMARY_GREY_LIGHT.withOpacity(0.5),
            ),
            child: GestureDetector(
              onTap: uploadIconTap,
              child: const Icon(
                Icons.upload,
                color: Colours.PRIMARY_BLUE,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
