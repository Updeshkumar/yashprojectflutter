import '../data/respnse/base/response.dart';
import '../widgets/app_snack_bar.dart';

bool handelAPI(ResponceModel responceModel, context) {
  if (responceModel.status == "success") {
    print(responceModel);
    print(responceModel.message);
    print(responceModel.data);
    return true;
  } else {
    AppSnackBar.appSnackBar(
      context: context,
      message: responceModel.message.toString(),
      title: "Try Again",
      isError: true,
    );
    return false;
  }
}
