import 'package:shared_preferences/shared_preferences.dart';

class LocalStorage {
  // save signup number
  static Future<void> saveSignUp(String signupPhone) async {
    var sharedPreference = await SharedPreferences.getInstance();
    final signuUpNumber =
        sharedPreference.setString("signUpNumber", signupPhone);
    print(signuUpNumber);
  }

  //
  static getSaveToken(String key) async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    final value = sharedPreferences.getString(key);
  }
}
