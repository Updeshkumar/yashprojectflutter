class Validation {
  static bool phoneNumberValidation(String name) {
    if (name.isEmpty) return false;
    return name.contains(RegExp(r"[6-9]{1}[0-9]{9}$"));
  }
}
