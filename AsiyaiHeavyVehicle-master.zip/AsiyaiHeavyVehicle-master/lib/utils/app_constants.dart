import 'package:shared_preferences/shared_preferences.dart';

class AppConstants {
  //
  static const String actionType = "REGISTRATION";
  static const int countryCode = 91;

  // URL for Api >>>>>> authentication

  /// home data api

  // ignore: constant_identifier_names
  static const String BASE_URL = "http://asiyaiheavyvehicle.com/en";
  static const String SEND_OTP_URL = BASE_URL + "/send-otp/";
  static const String VERIFY_OTP = BASE_URL + "/verify-mobile-otp/";

  static const String ADD_PROFILE = BASE_URL + "/add-profile/";

  static const String HOME_DATA_API = BASE_URL + "/home-api/";

  // URL for API >>>>>>Registration
  static const String HEAVY_VEHICLE_URL = BASE_URL + "/add-vehicle/";
  static const String DRIVER_URL = BASE_URL + "/driver-registration/";
  static const String LABOUR_CONTR_URL = BASE_URL + "/labour-registration/";
  static const String SUB_CONTR_URL = BASE_URL + "/subcontructor-registration/";
  static const String NORMAL_USER_URL = BASE_URL + "/dfuser-registration/";

  // URL for API >>>>>> for upload image
  static const String IMAGE_UPLOAD_URL = BASE_URL + "/v1/uploadFile";

  // URL for API >>>>> address

  static const String STATE_URL = BASE_URL + "/states/";
  static const String Post_Vehicel_address = BASE_URL + "/add-address/";
  static const String Post_Driver_address = BASE_URL + "/driver_add_address/";
  static const String Post_Labour_address = BASE_URL + "/labour-address/";
  static const String Post_SUBCONTR_address =
      BASE_URL + "/subcontructor_Address/";
  static const String Post_NOrmal_address = BASE_URL + "/dfuser_Address/";

  ///// Payment API
  static const String SUB_MAKE_PAYMENT =
      BASE_URL + "/subcontructor-payment-api/";
  static const String SUB_PAYMENT_HANDLER =
      BASE_URL + "/subcontructor-paymenthandller/";
  static const String HEAVY_MAKE_PAYMENT = BASE_URL + "/makepayment-api/";
  static const String HEAVY_PAYMENT_HANDLER = BASE_URL + "/paymenthandller";
  static const String LABOUR_MAKE_PAYMENT = BASE_URL + "/labour-payment/";
  static const String LABOUR_PAYMENT_HANDLER =
      BASE_URL + "/labour-paymenthandller/";
  static const String DRIVER_MAKE_PAYMENT = BASE_URL + "/driver-payment-api/";
  static const String DRIVER_PAYMENT_HANDLER =
      BASE_URL + "/driver-paymenthandller/";
  static const String NORMAL_MAKE_PAYMENT = BASE_URL + "/dfuser-payment-api/";
  static const String NORMAL_PAYMENT_HANDLLER =
      BASE_URL + "/dfuser-paymenthandller/";

  //URL for API >>>>>>> getData
  static const String VEHICLE_DATA = BASE_URL + "/vehicle-user-data/";

  static const String DRIVER_DATA = BASE_URL + "/driver-dashboard/";
  static const String LABOUR_DATA = BASE_URL + "/labour-dashboard/";
  static const String SUBCONTR_DATA = BASE_URL + "/subcontructor-dashboard/";

  // URL for API >>>>> requiremet
  static const String REQUIREMENT_URL = BASE_URL + "/requirement-api/";

  // URL for API >>>>>>>> requests

  static const String DRIVER_REQUEST = BASE_URL + "/request-driver/";

  static const String LABOUR_REQUEST = BASE_URL + "/request-labour/";
  static const String HEAVY_VEHICLE_REQUEST = BASE_URL + "/request-vehicle/";
  static const String SUBCONST_REQUEST = BASE_URL + "/request-subcontructor/";
  static const String REQ_REQUEST = BASE_URL + "/requirement-accepted-api/";

  //// filter API
  static const String SEARCH_API = BASE_URL + "/serach_api/";

  // edit api's
  static const String EDIT_DRIVER = BASE_URL + "/driver-update-api/";
  static const String EDIT_VEHICLE = BASE_URL + "/update-vehicle-api/";
  static const String EDIT_LABOUR = BASE_URL + "/labour-update-api/";
  static const String EDIT_SUBCONT = BASE_URL + "/subcontructor_update_api/";

  //
  static const String PHONE_PAY_API = "https://api.phonepe.com/apis/hermes/pg/v1/pay";

  ///
  static String FILTER_API({String? type}) {
    return BASE_URL +
        "/v1/filter_data?type=" +
        type! +
        "&pageLimit=10&pageOffset=1";
  }

  static String USER_TOKEN = "user_token";
  static String USER_NAME = "user_name";
  static String USER_ID = "user_id";
  static String USER_PHONE = "user_phone";
  static String USER_TYPE = "user_type";
  static String IS_PAID = "is_paid";
  static String product_id = "prd_id";

  static saveStringValue(String key, String value) async {
    await SharedPreferences.getInstance().then((val) {
      val.setString(key, value);
    });
  }

  static getStringValue(String value) async {
    await SharedPreferences.getInstance().then((val) {
      val.getString(value);
    });
  }
}
