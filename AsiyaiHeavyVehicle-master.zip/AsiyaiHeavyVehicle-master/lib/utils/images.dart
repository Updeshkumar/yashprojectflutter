class Images {
  static const String splash_logo = "assets/images/logos/AppLogo.png";
  static const String onboard_bg1 = "assets/images/backgrounds/Onboard1.png";
  static const String onboard_bg2 = "assets/images/backgrounds/Onboard2.png";
  static const String app_bg = "assets/images/backgrounds/Background.png";

  // icons
  static const String phone_icon = "assets/images/icons/phone.png";
  static const String docs_icon = "assets/images/icons/docs.png";
  static const String person_icon = "assets/images/icons/person.png";
  static const String another_person_icon =
      "assets/images/another/PersonImage.png";
  static const String faq_icon = "assets/images/icons/faq.png";
  static const String number_icon = "assets/images/icons/number.png";
  static const String location_icon = "assets/images/icons/location.png";

  static const String vehicle_icon = "assets/images/icons/vehicle.png";
  static const String firm_icon = "assets/images/icons/firm.png";
  static const String aadhar_icon = "assets/images/icons/aadhar.png";

  static const String success_icon = "assets/images/icons/check.png";

  //
  static const String category_vehicle = "assets/images/Category/vehicle.png";
  static const String category_labour = "assets/images/Category/labour.png";
  static const String category_driver = "assets/images/Category/driver.png";
  static const String category_subcontr = "assets/images/Category/subcontr.png";

  //
  static const String full_person = "assets/images/another/PersonImage.png";
}
