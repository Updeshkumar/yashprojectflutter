import 'package:flutter/material.dart';

class FontSizes {
  static kText40(BuildContext context) =>
      MediaQuery.of(context).size.height / 20;

//
  static kText32(BuildContext context) =>
      MediaQuery.of(context).size.height / 25;
  //
  static kText24(BuildContext context) =>
      MediaQuery.of(context).size.height / 33.33;

  //
  static kText14(BuildContext context) =>
      MediaQuery.of(context).size.height / 50;

  //
  static kText16(BuildContext context) =>
      MediaQuery.of(context).size.height / 45;

  //
  static kText20(BuildContext context) =>
      MediaQuery.of(context).size.height / 37;

  //
  static kText18(BuildContext context) =>
      MediaQuery.of(context).size.height / 40;

  //
  static kText12(BuildContext context) =>
      MediaQuery.of(context).size.height / 55;

  //
  static kText10(BuildContext context) =>
      MediaQuery.of(context).size.height / 80;

  static kbutton50(BuildContext context) =>
      MediaQuery.of(context).size.height / 16;
}
