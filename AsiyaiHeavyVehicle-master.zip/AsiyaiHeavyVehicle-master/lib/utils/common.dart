import 'package:fluttertoast/fluttertoast.dart';
import 'package:url_launcher/url_launcher.dart';

showTostMsg(String text) {
  return Fluttertoast.showToast(msg: text.toString());
}

Future<void> launchUrlstr(url) async {
  if (!await launchUrl(Uri.parse(url))) {
    throw Exception('Could not launch $url');
  }
}
