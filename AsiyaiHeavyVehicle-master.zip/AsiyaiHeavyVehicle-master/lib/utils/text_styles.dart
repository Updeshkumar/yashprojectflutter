import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'font_size.dart';

class TextStyles {
  //

  static TextStyle ktext40pop(BuildContext context) => GoogleFonts.righteous(
        fontWeight: FontWeight.w400,
        color: Colours.YELLOW_DARK,
        fontSize: FontSizes.kText40(context),
        letterSpacing: 4,
      );
  static TextStyle ktext10pop(BuildContext context) => GoogleFonts.righteous(
        fontWeight: FontWeight.w400,
        color: Colours.WHITE_COLOR,
        fontSize: FontSizes.kText10(context),
        letterSpacing: 1,
      );

  static TextStyle ktext24(BuildContext context) => GoogleFonts.roboto(
        fontWeight: FontWeight.w800,
        color: Colours.WHITE_COLOR,
        fontSize: FontSizes.kText24(context),
      );

  static TextStyle ktext32(BuildContext context) => GoogleFonts.roboto(
        fontWeight: FontWeight.w800,
        color: Colours.WHITE_COLOR,
        fontSize: FontSizes.kText32(context),
      );

  static TextStyle ktext14(BuildContext context) => TextStyle(
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w500,
        letterSpacing: 0.8,
        color: Colours.WHITE_COLOR,
        fontSize: FontSizes.kText14(context),
      );

  /// for Buttons

  static TextStyle ktext20(BuildContext context) => GoogleFonts.roboto(
        fontWeight: FontWeight.w700,
        color: Colours.WHITE_COLOR,
        letterSpacing: 1,
        fontSize: FontSizes.kText20(context),
      );

  static TextStyle ktext16(BuildContext context) => TextStyle(
        fontFamily: 'Poppins',
        fontStyle: FontStyle.normal,
        color: Colours.WHITE_COLOR,
        fontWeight: FontWeight.w700,
        fontSize: FontSizes.kText16(context),
      );

  static TextStyle ktext18(BuildContext context) => GoogleFonts.roboto(
        fontWeight: FontWeight.w800,
        color: Colours.WHITE_COLOR,
        fontSize: FontSizes.kText18(context),
      );

  //
  static TextStyle ktext12(BuildContext context) => TextStyle(
        fontFamily: 'Poppins',
        fontStyle: FontStyle.normal,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.8,
        color: Colours.WHITE_COLOR,
        fontSize: FontSizes.kText12(context),
      );
  //

}
