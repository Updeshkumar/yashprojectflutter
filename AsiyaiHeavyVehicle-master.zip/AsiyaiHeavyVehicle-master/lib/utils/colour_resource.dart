import 'package:flutter/material.dart';

class Colours {
  static const WHITE_COLOR = Color(0xffffffff);
  static const PRIMARY_BLACK = Color(0xFF313232);
  static const PRIMARY_BLACK_LIGHT = Color(0xff696969);
  static const PRIMARY_BLUE = Color(0xFF20272D);
  static const PRIMARY_BLUE_MILD = Color(0xFF353F4B);
  static const PRIMARY_GREY = Color(0xFF4A5760);
  static const PRIMARY_GREY_MILD = Color(0xFF8F939C);
  static const PRIMARY_GREY_LIGHT = Color(0xFF919DA2);
  static const YELLOW_DARK = Color(0xffFAB720);
  static const YELLOW_MILD = Color(0xffFCCC0A);
  static const YELLOW_LIGHT = Color(0xffFFDB48);

  //
  static const RED_COLOR = Color(0xFFEA4335);
  static const BLUE_COLOR = Color(0xFF3B5998);
  static const GREEN_LIGHT = Color(0xff96E8B9);
  static const SKY_BLUE_LIGHT = Color(0xFFDEF7FE);
  static const SKY_BLUE_DARK = Color(0xFF2D9CDB);
  static const SKY_BLUE_MIX = Color(0xff92CCEC);
  static const SKY_BLUE_MID = Color.fromARGB(255, 184, 221, 232);
  static const ORANGE_LIGHT = Color(0xFFF6BC88);
}
