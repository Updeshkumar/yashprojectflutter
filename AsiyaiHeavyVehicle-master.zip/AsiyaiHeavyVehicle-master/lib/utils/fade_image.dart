import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:flutter/material.dart';

class FadeImageWithError extends StatelessWidget {
  String? imgPath;
  BoxFit? fit;
  double? height;
  String? placeImage;
  FadeImageWithError({this.imgPath, this.fit, this.height, this.placeImage});
  @override
  Widget build(BuildContext context) {
    return FadeInImage.assetNetwork(
        placeholder: placeImage.toString(),
        placeholderFit: BoxFit.none,
        image: imgPath!,
        fit: fit != null ? fit : BoxFit.cover,
        height: height != null ? height : null,
        imageErrorBuilder:
            (BuildContext? context, Object? exception, StackTrace? stackTrace) {
          return Image.asset(placeImage.toString(), fit: BoxFit.none);
        });
  }
}
