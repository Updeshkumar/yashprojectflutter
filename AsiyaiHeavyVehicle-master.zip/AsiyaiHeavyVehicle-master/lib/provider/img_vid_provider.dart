// import 'dart:convert';

// import 'package:asiayai_heavy_vehicle_app/data/respnse/img_vid_model.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:http/http.dart' as http;

// class ImgVideoProvider with ChangeNotifier {
//   bool ialoading = false;

//   List<Imgvedio> imgVidUrl = [];

//   Future<void> getImgVid() async {
//     String url = "http://devapi.asiyaiheavyvehicle.com/v1/images/";
//     ialoading = true;
//     try {
//       var response = await http.get(
//         Uri.parse(url),
//         headers: {},
//       );
//       var jsonData = jsonDecode(response.body);
//       if (response.statusCode == 200) {
//         ialoading = false;
//         jsonData["imgvedio"].forEach((element) {
//           Imgvedio imgvedio = Imgvedio.fromJson(element);
//           imgVidUrl.add(imgvedio);
//         });
//       } else {
//         ialoading = false;
//         print(response.body);
//       }
//       notifyListeners();
//     } catch (e) {
//       print(e);
//     }
//   }
// }
