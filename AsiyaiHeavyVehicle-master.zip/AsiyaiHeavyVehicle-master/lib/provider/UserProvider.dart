import 'dart:convert';
import 'dart:io';
import 'dart:math' show Random;

import 'package:asiayai_heavy_vehicle_app/data/datamodel/heavy_vehicle_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/new_model/driver_pay_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/new_model/make_payment_Model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/address_model.dart';
import 'package:asiayai_heavy_vehicle_app/view/Add_Address.dart/add_address.dart';
import 'package:asiayai_heavy_vehicle_app/view/Payment/call_razorpay_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/Payment/pay_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/Payment/payment_sucess.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:asiayai_heavy_vehicle_app/data/datamodel/post_addre_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/new_model/otp_verify.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/driver_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/labour_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/requirement_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/sub_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/vehicel_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/utils/app_constants.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/bottoms_nav_bar.dart';
import 'package:asiayai_heavy_vehicle_app/view/Payment/payment_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/SigunUp/otp_page.dart';
import 'package:asiayai_heavy_vehicle_app/view/check_screen.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/show_dialog.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:random_string/random_string.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timer_count_down/timer_controller.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../data/datamodel/driver_model.dart';
import '../data/datamodel/labour_cont_model.dart';
import '../data/datamodel/sub_cont_model.dart';

class UserProvider extends ChangeNotifier {
  bool? isLoading = false;
  String? userPhone;
  String? userName;
  String? userToken;
  String? userID;
  String? userType;
  String? isPaid;

  SharedPreferences? sp;

  UserProvider() {
    loadSPDATA();
    notifyListeners();
  }

  loadSPDATA() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    if (![null, ""]
        .contains(sharedPreferences.getString(AppConstants.USER_PHONE))) {
      userPhone = sharedPreferences.getString(AppConstants.USER_PHONE);
    }
    if (![null, ""]
        .contains(sharedPreferences.getString(AppConstants.USER_TOKEN))) {
      userToken = sharedPreferences.getString(AppConstants.USER_TOKEN);
    }
    if (![null, ""]
        .contains(sharedPreferences.getString(AppConstants.USER_ID))) {
      userID = sharedPreferences.getString(AppConstants.USER_ID);
    }
    if (![null, ""]
        .contains(sharedPreferences.getString(AppConstants.USER_NAME))) {
      userName = sharedPreferences.getString(AppConstants.USER_NAME);
    }
    if (![null, ""]
        .contains(sharedPreferences.getString(AppConstants.USER_TYPE))) {
      userType = sharedPreferences.getString(AppConstants.USER_TYPE);
    }
    if (![null, ""]
        .contains(sharedPreferences.getString(AppConstants.IS_PAID))) {
      isPaid = sharedPreferences.getString(AppConstants.IS_PAID);
    }
    print("PHONE NUMBER >>>>" + userPhone.toString());
    print("USER ID >>>>>" + userID.toString());
    print("USER NAME >>>>>>" + userName.toString());
    print("USER TOKEN >>>>>>" + userToken.toString());

    notifyListeners();
  }

  String? otpValue = '';
  loginAPI(BuildContext context, {String? phone_number}) async {
    try {
      isLoading = true;
      ShowDialogsss().showDialogContainer(context);
      notifyListeners();
      print(AppConstants.SEND_OTP_URL);
      Map map = {
        "mobileNo": phone_number.toString(),
      };

      final response = await http.post(Uri.parse(AppConstants.SEND_OTP_URL),
          body: jsonEncode(map),
          headers: {'Content-Type': 'application/json', 'Accept': '*/*'});
      print(map);
      print("response :" + response.body);
      if (response.statusCode == 200) {
        print(response.body);
        var data = jsonDecode(response.body);
        if (data['status'] == true) {
          if (data['data'] != null) {
            otpValue = data['data']['otp'].toString();
            print(otpValue);
            showTostMsg(data['data']['message']);
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => SignUpOTP(
                          phone_number: phone_number,
                        )));
          }
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  otpVerify(BuildContext context, {String? otp, String? phoneNumber}) async {
    try {
      ShowDialogsss().showDialogContainer(context);
      isLoading = true;
      notifyListeners();
      print(AppConstants.VERIFY_OTP);
      Map map = {
        "mobileNo": phoneNumber,
        "otp": otp,
      };
      print(map);
      final response = await http.post(Uri.parse(AppConstants.VERIFY_OTP),
          body: jsonEncode(map),
          headers: {'Content-Type': 'application/json', 'Accept': '*/*'});
      if (response.statusCode == 200) {
        print(response.body);
        var data = OtpVerifyModelData.fromJson(jsonDecode(response.body));
        if (data.data!.otpMatched!.toLowerCase().contains("true")) {
          if (otp == otpValue) {
            showTostMsg("Successfully LoggedIn !!");
            SharedPreferences sharedPreferences =
                await SharedPreferences.getInstance();
            sharedPreferences.setString(
                AppConstants.USER_PHONE, data.data!.mobileNo!);
            sharedPreferences.setString(
                AppConstants.USER_TOKEN, data.data!.accessToken!);
            // sharedPreferences.setString(
            //   AppConstants.USER_TYPE,
            //   ![null, ""].contains(data.data!.userType)
            //       ? data.data!.userType!
            //       : "",
            // );
            // sharedPreferences.setString(
            //     AppConstants.IS_PAID, data.data!.isPaid!);

            loadSPDATA();

            if (data.data!.isType! == false) {
              Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (context) => CheckScreen()));
            } else {
              if (data.data!.isPaid! == false) {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => PayPaymentScreen()));
              } else {
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (context) => BottomNavBar(0)));
              }
            }
          }
        } else {
          showTostMsg("Please Enter Valid OTP");
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //add profile
  bool? isprofileSet = false;
  postProfile(BuildContext context, {String? title}) async {
    try {
      notifyListeners();
      ShowDialogsss().showDialogContainer(context);
      print(AppConstants.ADD_PROFILE);
      Map map = {
        "role": title,
      };
      final response = await http.post(Uri.parse(AppConstants.ADD_PROFILE),
          body: jsonEncode(map),
          headers: {
            "Authorization": "Token " + userToken!,
            'Content-Type': 'application/json',
          });
      print(map);
      print(userToken);
      print(response.body);
      if (response.statusCode == 200) {
        print(response.body);
        var data = jsonDecode(response.body);
        if (data['status'] == true) {
          isprofileSet = true;
          showTostMsg(data['data']['message']);
        } else {
          showTostMsg("try Again");
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  //

  // vehicle registration

  heavyVehiclePost(
    BuildContext context, {
    HeavyVehicleModel? model,
  }) async {
    try {
      SharedPreferences mypref = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.HEAVY_VEHICLE_URL);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.HEAVY_VEHICLE_URL));
      request.fields['vehical_name'] = model!.vehicalName!;
      request.fields['company_name'] = model.companyName!;
      request.fields['emailId'] = model.emailId!;
      request.fields['ownername'] = model.ownername!;
      request.fields['vehicleregistrationnumber'] =
          model.vehicleregistrationnumber!;
      request.fields['manufacture_date'] = model.manufectoringDate!;
      request.fields['alternativemobilenumber'] =
          model.alternativemobileNumber!;
      request.fields['vehiclemodelnumber'] = model.vehiclemodelnumber!;

      if (![null, ""].contains(model.aadharImage1)) {
        List<int> bytes = File(model.aadharImage1!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberbackimage',
            await new http.ByteStream(
                File(model.aadharImage1!.path).openRead()),
            await File(model.aadharImage1!.path).length(),
            filename: model.aadharImage1!.path.split("/").last));
      }
      if (![null, ""].contains(model.aadharImage2)) {
        List<int> bytes = File(model.aadharImage2!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberfrontimage',
            await new http.ByteStream(
                File(model.aadharImage2!.path).openRead()),
            await File(model.aadharImage2!.path).length(),
            filename: model.aadharImage2!.path.split("/").last));
      }
      if (![null, ""].contains(model.vehicleImage)) {
        List<int> bytes = File(model.vehicleImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'vehicle_image',
            await new http.ByteStream(
                File(model.vehicleImage!.path).openRead()),
            await File(model.vehicleImage!.path).length(),
            filename: model.vehicleImage!.path.split("/").last));
      }
      if (![null, ""].contains(model.vehicle_image_right)) {
        List<int> bytes =
            File(model.vehicle_image_right!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'vehicle_image_right',
            await new http.ByteStream(
                File(model.vehicle_image_right!.path).openRead()),
            await File(model.vehicle_image_right!.path).length(),
            filename: model.vehicle_image_right!.path.split("/").last));
      }
      if (![null, ""].contains(model.vehicle_image_left)) {
        List<int> bytes =
            File(model.vehicle_image_left!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'vehicle_image_left',
            await new http.ByteStream(
                File(model.vehicle_image_left!.path).openRead()),
            await File(model.vehicle_image_left!.path).length(),
            filename: model.vehicle_image_left!.path.split("/").last));
      }
      if (![null, ""].contains(model.vehicle_image_back)) {
        List<int> bytes =
            File(model.vehicle_image_back!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'vehicle_image_back',
            await new http.ByteStream(
                File(model.vehicle_image_back!.path).openRead()),
            await File(model.vehicle_image_back!.path).length(),
            filename: model.vehicle_image_back!.path.split("/").last));
      }
      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg("Saved Successfully");
            mypref.setString(AppConstants.USER_TYPE, "vehicle");
            mypref.setString(AppConstants.USER_NAME, model.ownername!);
            // mypref.setString(AppConstants.product_id, model.Id!);
            loadSPDATA();
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => AddAddress(
                          from: "1",
                          id: data['data']['obj']['id'].toString(),
                        )));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // driver registration

  driverDataPost(
    BuildContext context, {
    DriverModel? model,
  }) async {
    try {
      SharedPreferences mypref = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.DRIVER_URL);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request =
          http.MultipartRequest("POST", Uri.parse(AppConstants.DRIVER_URL));
      request.fields['vehicalname'] = model!.vehicalname!;
      request.fields['expriencesinyear'] = model.expriencesinyear!;
      request.fields['driveroperatorname'] = model.driveroperatorname!;
      request.fields['heavy_license'] = model.license_check!;
      request.fields['mobilenumber'] = model.mobileNumber!;

      if (![null, ""].contains(model.aadharBack)) {
        List<int> bytes = File(model.aadharBack!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberbackimage',
            await new http.ByteStream(File(model.aadharBack!.path).openRead()),
            await File(model.aadharBack!.path).length(),
            filename: model.aadharBack!.path.split("/").last));
      }
      if (![null, ""].contains(model.aadharFront)) {
        List<int> bytes = File(model.aadharFront!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberfrontimage',
            await new http.ByteStream(File(model.aadharFront!.path).openRead()),
            await File(model.aadharFront!.path).length(),
            filename: model.aadharFront!.path.split("/").last));
      }
      if (![null, ""].contains(model.licenseImage)) {
        List<int> bytes = File(model.licenseImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'license_image',
            await new http.ByteStream(
                File(model.licenseImage!.path).openRead()),
            await File(model.licenseImage!.path).length(),
            filename: model.licenseImage!.path.split("/").last));
      }
      if (![null, ""].contains(model.driverImage)) {
        List<int> bytes = File(model.driverImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'driver_image',
            await new http.ByteStream(File(model.driverImage!.path).openRead()),
            await File(model.driverImage!.path).length(),
            filename: model.driverImage!.path.split("/").last));
      }

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            mypref.setString(AppConstants.USER_TYPE, "driver");
            mypref.setString(AppConstants.USER_NAME, model.driveroperatorname!);

            loadSPDATA();
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => AddAddress(
                          from: "2",
                        )));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // labour
  labourDataPost(
    BuildContext context, {
    LabourContModel? model,
  }) async {
    try {
      SharedPreferences mypref = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.LABOUR_CONTR_URL);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.LABOUR_CONTR_URL));
      request.fields['name'] = model!.labourcontractorname!;
      request.fields['mobile_number'] = model.mobileNumber!;
      request.fields['labourwork'] = model.labourwork!;
      request.fields['skilledlabour'] = model.skilledLabour!;
      request.fields['unskilledlabour'] = model.unskiledLabour!;
      request.fields['professionallabour'] = model.proffesionalLabour!;
      request.fields['lobourinnumber'] = model.lobourinnumber!;

      if (![null, ""].contains(model.aadharback)) {
        List<int> bytes = File(model.aadharback!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberbackimage',
            await new http.ByteStream(File(model.aadharback!.path).openRead()),
            await File(model.aadharback!.path).length(),
            filename: model.aadharback!.path.split("/").last));
      }
      if (![null, ""].contains(model.aadharfront)) {
        List<int> bytes = File(model.aadharfront!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberfrontimage',
            await new http.ByteStream(File(model.aadharfront!.path).openRead()),
            await File(model.aadharfront!.path).length(),
            filename: model.aadharfront!.path.split("/").last));
      }
      if (![null, ""].contains(model.labourImage)) {
        List<int> bytes = File(model.labourImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'labour_image',
            await new http.ByteStream(File(model.labourImage!.path).openRead()),
            await File(model.labourImage!.path).length(),
            filename: model.labourImage!.path.split("/").last));
      }

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            mypref.setString(AppConstants.USER_TYPE, "labour");
            mypref.setString(
                AppConstants.USER_NAME, model.labourcontractorname!);
            loadSPDATA();
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => AddAddress(
                          from: "4",
                        )));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // sub-contructor
  sunContDataPost(
    BuildContext context, {
    SubContModel? model,
  }) async {
    try {
      SharedPreferences mypref = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.SUB_CONTR_URL);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      print(userToken);
      var request =
          http.MultipartRequest("POST", Uri.parse(AppConstants.SUB_CONTR_URL));
      request.fields['contractorname'] = model!.contractorname!;
      request.fields['emailId'] = model.emailId!;
      request.fields['mobilenumber'] = model.mobileNumber!;
      request.fields['firmname'] = model.firmname!;
      request.fields['typeofwork'] = model.typeofWork!;
      request.fields['expriencesinyear'] = model.expriencesinyear!;
      request.fields['license_number'] = model.licenseNumber!;
      // request.fields['expired_at'] = model.expiredAt!;

      if (![null, ""].contains(model.aadharBack)) {
        List<int> bytes = File(model.aadharBack!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberbackimage',
            await new http.ByteStream(File(model.aadharBack!.path).openRead()),
            await File(model.aadharBack!.path).length(),
            filename: model.aadharBack!.path.split("/").last));
      }
      if (![null, ""].contains(model.aadharFront)) {
        List<int> bytes = File(model.aadharFront!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberfrontimage',
            await new http.ByteStream(File(model.aadharFront!.path).openRead()),
            await File(model.aadharFront!.path).length(),
            filename: model.aadharFront!.path.split("/").last));
      }
      if (![null, ""].contains(model.subcontractorImage)) {
        List<int> bytes =
            File(model.subcontractorImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'subcontractor_image',
            await new http.ByteStream(
                File(model.subcontractorImage!.path).openRead()),
            await File(model.subcontractorImage!.path).length(),
            filename: model.subcontractorImage!.path.split("/").last));
      }
      if (![null, ""].contains(model.subcontractor_image_right)) {
        List<int> bytes =
            File(model.subcontractor_image_right!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'subcontractor_image_right',
            await new http.ByteStream(
                File(model.subcontractor_image_right!.path).openRead()),
            await File(model.subcontractor_image_right!.path).length(),
            filename: model.subcontractor_image_right!.path.split("/").last));
      }
      if (![null, ""].contains(model.subcontractor_image_left)) {
        List<int> bytes =
            File(model.subcontractor_image_left!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'subcontractor_image_left',
            await new http.ByteStream(
                File(model.subcontractor_image_left!.path).openRead()),
            await File(model.subcontractor_image_left!.path).length(),
            filename: model.subcontractor_image_left!.path.split("/").last));
      }
      if (![null, ""].contains(model.subcontractor_image_back)) {
        List<int> bytes =
            File(model.subcontractor_image_back!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'subcontractor_image_back',
            await new http.ByteStream(
                File(model.subcontractor_image_back!.path).openRead()),
            await File(model.subcontractor_image_back!.path).length(),
            filename: model.subcontractor_image_back!.path.split("/").last));
      }
      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg("Saved Successfully");
            mypref.setString(AppConstants.USER_TYPE, "sub");
            mypref.setString(AppConstants.USER_NAME, model.contractorname!);
            loadSPDATA();
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => AddAddress(
                          from: "3",
                          //id: data['data']['obj']['id'].toString(),
                        )));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //

  //
  postNormalUser(BuildContext context, {String? name}) async {
    try {
      SharedPreferences mypref = await SharedPreferences.getInstance();
      isLoading = true;
      makePayObj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.NORMAL_USER_URL);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.NORMAL_USER_URL));

      request.fields['name'] = name!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            print("enter");
            mypref.setString(AppConstants.USER_TYPE, "normal");
            mypref.setString(AppConstants.USER_NAME, name);
            loadSPDATA();

            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => AddAddress(
                          from: "5",
                          //id: data['data']['obj']['id'].toString(),
                        )));
          } else {
            showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // get heavy vehicle
  DriverData? drivers_data;

  getDriverData() async {
    try {
      EasyLoading.show(status: "PLease Wait..");

      drivers_data = null;

      notifyListeners();
      print(AppConstants.DRIVER_DATA);
      final response =
          await http.get(Uri.parse(AppConstants.DRIVER_DATA), headers: {
        "Authorization": "Token $userToken",
      });
      print(response.body);
      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        // print(response.body);
        //var data = DriverResponseModel.fromJson(jsonDecode(response.body));
        print("FINE");
        var data = DriverDataModel.fromJson(jsonDecode(response.body));
        if (data.status == true) {
          if (data.data != null && data.data!.driver != null) {
            drivers_data = data.data!.driver;
            print(jsonEncode(drivers_data));
          }
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // get subc
  Subcontructor? sub_data;

  getSubContructorData() async {
    try {
      EasyLoading.show(status: "Please Wait...");
      notifyListeners();
      sub_data = null;

      print(AppConstants.SUBCONTR_DATA);
      final response =
          await http.get(Uri.parse(AppConstants.SUBCONTR_DATA), headers: {
        "Authorization": "Token $userToken",
      });
      print(response.body);
      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        print(response.body);
        var data = SubContructorData.fromJson(jsonDecode(response.body));
        if (data.status == true) {
          if (data.data != null) {
            sub_data = data.data!.subcontructor;
          }
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      EasyLoading.dismiss(animation: true);
      notifyListeners();
    }
  }

  //
  Labour? labour_data;

  getLabourData() async {
    try {
      EasyLoading.show(status: "Please Wait...");
      notifyListeners();
      labour_data = null;

      print(AppConstants.LABOUR_DATA);
      final response =
          await http.get(Uri.parse(AppConstants.LABOUR_DATA), headers: {
        "Authorization": "Token $userToken",
      });
      print(response.body);
      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        print(response.body);
        var data = LabourDataModel.fromJson(jsonDecode(response.body));
        print("FINE");
        if (data.status == true) {
          if (data.data != null) {
            labour_data = data.data!.labour;
          }
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      EasyLoading.dismiss(animation: true);
      notifyListeners();
    }
  }

  //
  List<Vehiclelist> vehcileDashList = [];
  getVehicleData() async {
    try {
      EasyLoading.show(status: "Please Wait...");
      notifyListeners();
      vehcileDashList.clear();
      print(AppConstants.VEHICLE_DATA);
      print("enter");
      final response =
          await http.post(Uri.parse(AppConstants.VEHICLE_DATA), headers: {
        "Authorization": "Token $userToken",
      });
      print(response.statusCode);
      print(response.body);
      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        var data = HeavyVehicleDataModel.fromJson(jsonDecode(response.body));
        print("FINE");
        if (data.status == true) {
          if (data.data != null && data.data!.vehiclelist != null) {
            vehcileDashList.addAll(data.data!.vehiclelist!);
            print("vehcileDashList" + vehcileDashList.length.toString());
          }
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      EasyLoading.dismiss(animation: true);
      notifyListeners();
    }
  }

  // heavy request
  postVehicleRequest(BuildContext context, {String? Id}) async {
    try {
      isLoading = true;
      makePayObj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.HEAVY_VEHICLE_REQUEST);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.HEAVY_VEHICLE_REQUEST));

      request.fields['heavyvehivalregistration'] = Id!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data['status'] == true) {
            print("enter");
            showTostMsg("Request Successfully !!");
            Navigator.pop(context);
            homeDataShow();
          } else {
            showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // driver request
  postDriverRequest(BuildContext context, {String? Id}) async {
    try {
      isLoading = true;
      makePayObj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.DRIVER_REQUEST);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request =
          http.MultipartRequest("POST", Uri.parse(AppConstants.DRIVER_REQUEST));

      request.fields['driver_profile'] = Id!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data['status'] == true) {
            print("enter");
            showTostMsg("Request Successfully !!");
            Navigator.pop(context);
            homeDataShow();
          } else {
            showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  postSUBRequest(BuildContext context, {String? Id}) async {
    try {
      isLoading = true;
      makePayObj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.SUBCONST_REQUEST);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.SUBCONST_REQUEST));

      request.fields['subcontractorregistration'] = Id!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data['status'] == true) {
            print("enter");
            showTostMsg("Request Successfully !!");
            Navigator.pop(context);
            homeDataShow();
          } else {
            showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  postLabourRequest(BuildContext context, {String? Id}) async {
    try {
      isLoading = true;
      makePayObj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.LABOUR_REQUEST);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request =
          http.MultipartRequest("POST", Uri.parse(AppConstants.LABOUR_REQUEST));

      request.fields['labour_contructor'] = Id!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data['status'] == true) {
            print("enter");
            showTostMsg("Request Successfully !!");
            Navigator.pop(context);
            homeDataShow();
          } else {
            showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  RequiementDataModel? myRequirements;

  getRequirement() async {
    try {
      notifyListeners();
      EasyLoading.show(status: "Please Wait...");

      print(AppConstants.REQUIREMENT_URL);
      myRequirements = null;

      var response = await http.get(
        Uri.parse(AppConstants.REQUIREMENT_URL),
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "Token $userToken",
        },
      );

      print(response.body);

      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        print("fine");
        var data = RequiementDataModel.fromJson(jsonDecode(response.body));
        if (data.status == true) {
          if (data.data != null) {
            myRequirements = data;
          }
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      EasyLoading.dismiss(animation: true);
      notifyListeners();
    }
  }

  //
  postRequirementRequest(BuildContext context, {String? Id}) async {
    try {
      ShowDialogsss().showDialogContainer(context);
      isLoading = true;
      notifyListeners();
      // Map map = {
      //   "contractorname": obj!.contractorname,
      //   "firmname": obj.firmname,
      //   "expriencesinyear": obj.expriencesinyear,
      //   "license_number": obj.licenseNumber,
      //   "Aadhar_number": obj.aadharNumber,
      //   "subcontractor_image": obj.subcontractorImage,
      //   "mobilenumber": obj.mobileNumber,
      //   "typeofwork": obj.typeofWork
      // };
      print(AppConstants.REQ_REQUEST);
      final response = await http
          .post(Uri.parse(AppConstants.REQ_REQUEST + "/$Id"), headers: {
        "Authorization": userToken!,
        'Content-Type': 'application/json',
        'Accept': '*/*'
      });
      print(response.body);
      if (response.statusCode == 200) {
        showTostMsg("Request successfully");
        print("Success >>>" + response.body);
        var data = jsonDecode(response.body);
        Navigator.pop(context);
        // if (data["message"] == "Sub Contractor request successful") {
        //   showTostMsg("Request successfully");
        //   Navigator.pop(context);
        //   getSubContructorData();
        // }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  List<StateModel>? states = [];
  getState(BuildContext context) async {
    try {
      // ShowDialogsss().showDialogContainer(context);
      EasyLoading.show(status: "Please Wait...");
      notifyListeners();
      states!.clear();
      print(AppConstants.STATE_URL);
      final response = await http.get(Uri.parse(AppConstants.STATE_URL));
      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        print(response.body);
        var data = jsonDecode(response.body);
        if (data != null) {
          data!.forEach((element) {
            StateModel stateModel = StateModel.fromJson(element);
            states!.add(stateModel);
          });
          print(states!.length);
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      EasyLoading.dismiss(animation: true);
      notifyListeners();
    }
  }

  //
  List<DistrictModel>? distict = [];
  getDistict(BuildContext context, {String? state_id}) async {
    try {
      // ShowDialogsss().showDialogContainer(context);
      EasyLoading.show(status: "Please Wait...");
      notifyListeners();
      distict!.clear();
      print(AppConstants.STATE_URL + "/$state_id" + "/districts/");
      final response = await http.get(
          Uri.parse(AppConstants.STATE_URL + "/$state_id" + "/districts/"));
      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        print(response.body);
        var data = jsonDecode(response.body);
        if (data != null) {
          data!.forEach((element) {
            DistrictModel districtModel = DistrictModel.fromJson(element);
            distict!.add(districtModel);
          });
          print(distict!.length);
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      EasyLoading.dismiss(animation: true);
      notifyListeners();
    }
  }

  //
  List<TehsilModel>? tehsils = [];
  getTehsil(BuildContext context, {String? district_id}) async {
    try {
      // ShowDialogsss().showDialogContainer(context);
      EasyLoading.show(status: "Please Wait...");
      notifyListeners();
      tehsils!.clear();
      print(AppConstants.BASE_URL + "/districts/$district_id" + "/tahseel/");
      final response = await http.get(Uri.parse(
          AppConstants.BASE_URL + "/districts/$district_id" + "/tahseel/"));
      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        print(response.body);
        var data = jsonDecode(response.body);
        if (data != null) {
          data!.forEach((element) {
            TehsilModel tehsilModel = TehsilModel.fromJson(element);
            tehsils!.add(tehsilModel);
          });
          print(tehsils!.length);
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      EasyLoading.dismiss(animation: true);
      notifyListeners();
    }
  }

  addAddress(BuildContext context,
      {int? state_id, int? dis_id, int? teh_id, int? heavy_id}) async {
    try {
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.Post_Vehicel_address);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.Post_Vehicel_address));
      request.fields['heavyvehivalregistration'] = heavy_id.toString();
      request.fields['state_id'] = state_id.toString();
      request.fields['district_id'] = dis_id.toString();
      request.fields['tahseel_id'] = teh_id.toString();

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => PayPaymentScreen(
                          id: heavy_id.toString(),
                          from: "vehicle",
                        )));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // driver address
  addDriverAddress(BuildContext context,
      {int? state_id, int? dis_id, int? teh_id}) async {
    try {
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.Post_Driver_address);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.Post_Driver_address));

      request.fields['state_id'] = state_id.toString();
      request.fields['district_id'] = dis_id.toString();
      request.fields['tahseel_id'] = teh_id.toString();

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => PayPaymentScreen(
                          from: "driver",
                        )));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  addLabourAddress(BuildContext context,
      {int? state_id, int? dis_id, int? teh_id}) async {
    try {
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.Post_Labour_address);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.Post_Labour_address));

      request.fields['state_id'] = state_id.toString();
      request.fields['district_id'] = dis_id.toString();
      request.fields['tahseel_id'] = teh_id.toString();

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => PayPaymentScreen(
                          from: "labour",
                        )));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  addSubContructorAddress(BuildContext context,
      {int? state_id, int? dis_id, int? teh_id}) async {
    try {
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.Post_SUBCONTR_address);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.Post_SUBCONTR_address));

      request.fields['state_id'] = state_id.toString();
      request.fields['district_id'] = dis_id.toString();
      request.fields['tahseel_id'] = teh_id.toString();

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => PayPaymentScreen(
                          from: "sub",
                        )));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  addNormalUserAddress(BuildContext context,
      {int? state_id, int? dis_id, int? teh_id}) async {
    try {
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.Post_NOrmal_address);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.Post_NOrmal_address));

      request.fields['state_id'] = state_id.toString();
      request.fields['district_id'] = dis_id.toString();
      request.fields['tahseel_id'] = teh_id.toString();

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => PayPaymentScreen(
                          from: "normal",
                        )));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // make payment api
  DriverPaymentModel? driverpaymeoj;
  // bool? isMakePay = false;
  driverMakePayment(
    BuildContext context,
  ) async {
    try {
      isLoading = true;
      driverpaymeoj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");

      print("url driver" + AppConstants.DRIVER_MAKE_PAYMENT);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.DRIVER_MAKE_PAYMENT));

      request.fields['amount'] = "1000";

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();

      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print("DAta >>>>" + value);
        var data = DriverPaymentModel.fromJson(jsonDecode(value));
        print("DAtasss >>>>" + data.toString());
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          print("status  " + data.status.toString());
          if (data.status == true) {
            driverpaymeoj = data;
            print("enter" + jsonEncode(driverpaymeoj));
            showTostMsg(data.data!.msg!);

            if (data.data!.url != null && data.data!.url != "") {
              print("URL>>>>" + data.data!.url!);
              launchUrlstr(data.data!.url);
            }

            // Navigator.pushReplacement(
            //     context,
            //     MaterialPageRoute(
            //         builder: (context) => PayWithRazorPay(
            //               obj: makePayObj,
            //               from: "driver",
            //             )));
          } else {
            showTostMsg(data.data!.msg!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //

  driverPaymentHandller(BuildContext context,
      {String? order_id, String? payment_id, String? pay_signature}) async {
    try {
      SharedPreferences myprefs = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.DRIVER_PAYMENT_HANDLER);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.DRIVER_PAYMENT_HANDLER));

      request.fields['order_id'] = order_id!;
      request.fields['payment_id'] = payment_id!;
      request.fields['signature'] = pay_signature!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            myprefs.setString(AppConstants.IS_PAID, "true");
            loadSPDATA();
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => BottomNavBar(0)));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  /// sub contructor
  MakePaymnetDataModel? makePayObj;
  subContruMakePayment(
    BuildContext context,
  ) async {
    try {
      isLoading = true;
      makePayObj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.SUB_MAKE_PAYMENT);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.SUB_MAKE_PAYMENT));

      request.fields['amount'] = "1000";

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = MakePaymnetDataModel.fromJson(jsonDecode(value));
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data.status == true) {
            print("enter");

            makePayObj = data;
            print("enter" + jsonEncode(makePayObj));
            showTostMsg(data.data!.message!);

            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => PayWithRazorPay(
                          obj: makePayObj,
                          from: "sub",
                        )));
          } else {
            showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //

  subContrPaymentHandller(BuildContext context,
      {String? order_id, String? payment_id, String? pay_signature}) async {
    try {
      SharedPreferences myprefs = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.SUB_PAYMENT_HANDLER);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.SUB_PAYMENT_HANDLER));

      request.fields['order_id'] = order_id!;
      request.fields['payment_id'] = payment_id!;
      request.fields['signature'] = pay_signature!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            myprefs.setString(AppConstants.IS_PAID, "true");
            loadSPDATA();
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => BottomNavBar(0)));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // labour
  labourContruMakePayment(
    BuildContext context,
  ) async {
    try {
      isLoading = true;
      makePayObj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.LABOUR_MAKE_PAYMENT);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.LABOUR_MAKE_PAYMENT));

      request.fields['amount'] = "1000";

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = MakePaymnetDataModel.fromJson(jsonDecode(value));
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data.status == true) {
            print("enter");

            makePayObj = data;
            print("enter" + jsonEncode(makePayObj));
            showTostMsg(data.data!.message!);

            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => PayWithRazorPay(
                          obj: makePayObj,
                          from: "labour",
                        )));
          } else {
            showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //

  labourPaymentHandller(BuildContext context,
      {String? order_id, String? payment_id, String? pay_signature}) async {
    try {
      SharedPreferences myprefs = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.LABOUR_PAYMENT_HANDLER);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.LABOUR_PAYMENT_HANDLER));

      request.fields['order_id'] = order_id!;
      request.fields['payment_id'] = payment_id!;
      request.fields['signature'] = pay_signature!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            myprefs.setString(AppConstants.IS_PAID, "true");
            loadSPDATA();
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => BottomNavBar(0)));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  vehicleContruMakePayment(BuildContext context, {String? id}) async {
    try {
      isLoading = true;
      makePayObj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.HEAVY_MAKE_PAYMENT);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.HEAVY_MAKE_PAYMENT));

      request.fields['amount'] = "1000";
      request.fields['vehicle_id'] = id!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = MakePaymnetDataModel.fromJson(jsonDecode(value));
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data.status == true) {
            print("enter");

            makePayObj = data;
            print("enter" + jsonEncode(makePayObj));
            showTostMsg(data.data!.message!);

            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => PayWithRazorPay(
                          obj: makePayObj,
                          from: "vehicle",
                        )));
          } else {
            showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  vehiclePaymentHandller(BuildContext context,
      {String? order_id, String? payment_id, String? pay_signature}) async {
    try {
      SharedPreferences myprefs = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.HEAVY_PAYMENT_HANDLER);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.HEAVY_PAYMENT_HANDLER));

      request.fields['order_id'] = order_id!;
      request.fields['payment_id'] = payment_id!;
      request.fields['signature'] = pay_signature!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            myprefs.setString(AppConstants.IS_PAID, "true");
            loadSPDATA();
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => BottomNavBar(0)));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  normalMakePayment(
    BuildContext context,
  ) async {
    try {
      isLoading = true;
      makePayObj = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.NORMAL_MAKE_PAYMENT);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.NORMAL_MAKE_PAYMENT));

      request.fields['amount'] = "1000";

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = MakePaymnetDataModel.fromJson(jsonDecode(value));
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data.status == true) {
            print("enter");

            makePayObj = data;
            print("enter" + jsonEncode(makePayObj));
            showTostMsg(data.data!.message!);

            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => PayWithRazorPay(
                          obj: makePayObj,
                          from: "normal",
                        )));
          } else {
            showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  normalPaymentHandller(BuildContext context,
      {String? order_id, String? payment_id, String? pay_signature}) async {
    try {
      SharedPreferences myprefs = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.NORMAL_PAYMENT_HANDLLER);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request = http.MultipartRequest(
          "POST", Uri.parse(AppConstants.NORMAL_PAYMENT_HANDLLER));

      request.fields['order_id'] = order_id!;
      request.fields['payment_id'] = payment_id!;
      request.fields['signature'] = pay_signature!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg(data['data']['message']);
            myprefs.setString(AppConstants.IS_PAID, "true");
            loadSPDATA();
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => BottomNavBar(0)));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // HOME DATA
  HomeDataModel? myHomeData;
  homeDataShow() async {
    try {
      EasyLoading.show(status: "Please Wait...");
      notifyListeners();
      myHomeData = null;
      print(AppConstants.HOME_DATA_API);
      final response =
          await http.get(Uri.parse(AppConstants.HOME_DATA_API), headers: {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      });
      print(response.body);
      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        print(response.body);
        var data = HomeDataModel.fromJson(jsonDecode(response.body));
        if (data.status == true) {
          if (data.data != null) {
            myHomeData = data;
          }
        }
      }
    } catch (e) {
      print(e.toString());
    } finally {
      EasyLoading.dismiss(animation: true);
      notifyListeners();
    }
  }

  //
  HomeDataModel? mySearchData;
  searchDataApi(BuildContext context, {String? query}) async {
    try {
      isLoading = true;
      mySearchData = null;
      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.SEARCH_API);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request =
          http.MultipartRequest("POST", Uri.parse(AppConstants.SEARCH_API));

      request.fields['query'] = query!;

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = HomeDataModel.fromJson(jsonDecode(value));
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          mySearchData = null;

          if (data.status == true) {
            if (data.data != null) {
              print("enter");

              mySearchData = data;
            }
          } else {
            //showTostMsg(data.data!.message!);
          }
          // print("true==" + jsonEncode(value));
        } else {
          // showTostMsg("Something went wrong");
          // print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  postRequirementAPI(BuildContext context, {String? req_id}) async {
    try {
      isLoading = true;

      notifyListeners();
      print(userToken);
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.REQ_REQUEST);
      Map map = {
        "requirement": req_id,
        "status": true.toString(),
      };
      final response = await http
          .post(Uri.parse(AppConstants.REQ_REQUEST), body: map, headers: {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      });
      print(map);
      print(response.body);
      if (response.statusCode == 200) {
        EasyLoading.dismiss(animation: true);
        print(response.body);
        var data = jsonDecode(response.body);
        if (data["status"] == true) {
          showTostMsg("Reqest Succesfully");
        } else {
          showTostMsg(data["data"]['message']);
        }
      }
    } catch (ex) {
      print(ex);
    } finally {
      EasyLoading.dismiss(animation: true);
      notifyListeners();
    }
  }

  // edit api's
  UpdateSuBContDataPost(
    BuildContext context, {
    SubContModel? model,
  }) async {
    try {
      SharedPreferences mypref = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.EDIT_SUBCONT);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      print(userToken);
      var request =
          http.MultipartRequest("POST", Uri.parse(AppConstants.EDIT_SUBCONT));
      request.fields['contractorname'] = model!.contractorname!;
      request.fields['emailId'] = model.emailId!;
      request.fields['mobilenumber'] = model.mobileNumber!;
      request.fields['firmname'] = model.firmname!;
      request.fields['typeofwork'] = model.typeofWork!;
      request.fields['expriencesinyear'] = model.expriencesinyear!;
      request.fields['license_number'] = model.licenseNumber!;
      // request.fields['expired_at'] = model.expiredAt!;

      if (![null, ""].contains(model.aadharBack)) {
        List<int> bytes = File(model.aadharBack!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberbackimage',
            await new http.ByteStream(File(model.aadharBack!.path).openRead()),
            await File(model.aadharBack!.path).length(),
            filename: model.aadharBack!.path.split("/").last));
      }
      if (![null, ""].contains(model.aadharFront)) {
        List<int> bytes = File(model.aadharFront!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberfrontimage',
            await new http.ByteStream(File(model.aadharFront!.path).openRead()),
            await File(model.aadharFront!.path).length(),
            filename: model.aadharFront!.path.split("/").last));
      }
      if (![null, ""].contains(model.subcontractorImage)) {
        List<int> bytes =
            File(model.subcontractorImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'subcontractor_image',
            await new http.ByteStream(
                File(model.subcontractorImage!.path).openRead()),
            await File(model.subcontractorImage!.path).length(),
            filename: model.subcontractorImage!.path.split("/").last));
      }
      if (![null, ""].contains(model.subcontractor_image_right)) {
        List<int> bytes =
            File(model.subcontractor_image_right!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'subcontractor_image_right',
            await new http.ByteStream(
                File(model.subcontractor_image_right!.path).openRead()),
            await File(model.subcontractor_image_right!.path).length(),
            filename: model.subcontractor_image_right!.path.split("/").last));
      }
      if (![null, ""].contains(model.subcontractor_image_left)) {
        List<int> bytes =
            File(model.subcontractor_image_left!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'subcontractor_image_left',
            await new http.ByteStream(
                File(model.subcontractor_image_left!.path).openRead()),
            await File(model.subcontractor_image_left!.path).length(),
            filename: model.subcontractor_image_left!.path.split("/").last));
      }
      if (![null, ""].contains(model.subcontractor_image_back)) {
        List<int> bytes =
            File(model.subcontractor_image_back!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'subcontractor_image_back',
            await new http.ByteStream(
                File(model.subcontractor_image_back!.path).openRead()),
            await File(model.subcontractor_image_back!.path).length(),
            filename: model.subcontractor_image_back!.path.split("/").last));
      }
      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            mypref.setString(AppConstants.USER_TYPE, "sub");
            mypref.setString(AppConstants.USER_NAME, model.contractorname!);
            loadSPDATA();
            showTostMsg("Updated Successfully");
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => BottomNavBar(0)));
            getSubContructorData();
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  UpdateLabourDataPost(
    BuildContext context, {
    LabourContModel? model,
  }) async {
    try {
      SharedPreferences mypref = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.EDIT_LABOUR);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request =
          http.MultipartRequest("POST", Uri.parse(AppConstants.EDIT_LABOUR));
      request.fields['name'] = model!.labourcontractorname!;
      request.fields['mobile_number'] = model.mobileNumber!;
      request.fields['labourwork'] = model.labourwork!;
      request.fields['skilledlabour'] = model.skilledLabour!;
      request.fields['unskilledlabour'] = model.unskiledLabour!;
      request.fields['professionallabour'] = model.proffesionalLabour!;
      request.fields['lobourinnumber'] = model.lobourinnumber!;

      if (![null, ""].contains(model.aadharback)) {
        List<int> bytes = File(model.aadharback!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberbackimage',
            await new http.ByteStream(File(model.aadharback!.path).openRead()),
            await File(model.aadharback!.path).length(),
            filename: model.aadharback!.path.split("/").last));
      }
      if (![null, ""].contains(model.aadharfront)) {
        List<int> bytes = File(model.aadharfront!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberfrontimage',
            await new http.ByteStream(File(model.aadharfront!.path).openRead()),
            await File(model.aadharfront!.path).length(),
            filename: model.aadharfront!.path.split("/").last));
      }
      if (![null, ""].contains(model.labourImage)) {
        List<int> bytes = File(model.labourImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'labour_image',
            await new http.ByteStream(File(model.labourImage!.path).openRead()),
            await File(model.labourImage!.path).length(),
            filename: model.labourImage!.path.split("/").last));
      }

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg("Update Successfully!!");
            mypref.setString(AppConstants.USER_TYPE, "labour");
            mypref.setString(
                AppConstants.USER_NAME, model.labourcontractorname!);
            loadSPDATA();
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => BottomNavBar(0)));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  UpdateDriverDataPost(
    BuildContext context, {
    DriverModel? model,
  }) async {
    try {
      SharedPreferences mypref = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.EDIT_DRIVER);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request =
          http.MultipartRequest("POST", Uri.parse(AppConstants.EDIT_DRIVER));
      request.fields['vehicalname'] = model!.vehicalname!;
      request.fields['expriencesinyear'] = model.expriencesinyear!;
      request.fields['driveroperatorname'] = model.driveroperatorname!;
      request.fields['heavy_license'] = model.license_check!;
      request.fields['mobilenumber'] = model.mobileNumber!;

      if (![null, ""].contains(model.aadharBack)) {
        List<int> bytes = File(model.aadharBack!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberbackimage',
            await new http.ByteStream(File(model.aadharBack!.path).openRead()),
            await File(model.aadharBack!.path).length(),
            filename: model.aadharBack!.path.split("/").last));
      }
      if (![null, ""].contains(model.aadharFront)) {
        List<int> bytes = File(model.aadharFront!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberfrontimage',
            await new http.ByteStream(File(model.aadharFront!.path).openRead()),
            await File(model.aadharFront!.path).length(),
            filename: model.aadharFront!.path.split("/").last));
      }
      if (![null, ""].contains(model.licenseImage)) {
        List<int> bytes = File(model.licenseImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'license_image',
            await new http.ByteStream(
                File(model.licenseImage!.path).openRead()),
            await File(model.licenseImage!.path).length(),
            filename: model.licenseImage!.path.split("/").last));
      }
      if (![null, ""].contains(model.driverImage)) {
        List<int> bytes = File(model.driverImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'driver_image',
            await new http.ByteStream(File(model.driverImage!.path).openRead()),
            await File(model.driverImage!.path).length(),
            filename: model.driverImage!.path.split("/").last));
      }

      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg("Update Successfully!!");
            mypref.setString(AppConstants.USER_TYPE, "driver");
            mypref.setString(AppConstants.USER_NAME, model.driveroperatorname!);

            loadSPDATA();
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => BottomNavBar(0)));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //
  UpdateHeavyVehiclePost(
    BuildContext context, {
    HeavyVehicleModel? model,
  }) async {
    try {
      SharedPreferences mypref = await SharedPreferences.getInstance();
      isLoading = true;
      notifyListeners();
      EasyLoading.show(status: "Please Wait");
      //print("ATTACHTED FILE >>> " + model!.attachedFilePath!.length.toString());
      print(AppConstants.EDIT_VEHICLE);
      var headers = {
        'Accept': 'application/json',
        "Authorization": "Token $userToken",
      };
      var request =
          http.MultipartRequest("POST", Uri.parse(AppConstants.EDIT_VEHICLE));
      request.fields['id'] = model!.Id!;
      request.fields['vehical_name'] = model.vehicalName!;
      request.fields['company_name'] = model.companyName!;
      request.fields['emailId'] = model.emailId!;
      request.fields['ownername'] = model.ownername!;
      request.fields['vehicleregistrationnumber'] =
          model.vehicleregistrationnumber!;
      request.fields['manufacture_date'] = model.manufectoringDate!;
      request.fields['alternativemobilenumber'] =
          model.alternativemobileNumber!;
      request.fields['vehiclemodelnumber'] = model.vehiclemodelnumber!;

      if (![null, ""].contains(model.aadharImage1)) {
        List<int> bytes = File(model.aadharImage1!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberbackimage',
            await new http.ByteStream(
                File(model.aadharImage1!.path).openRead()),
            await File(model.aadharImage1!.path).length(),
            filename: model.aadharImage1!.path.split("/").last));
      }
      if (![null, ""].contains(model.aadharImage2)) {
        List<int> bytes = File(model.aadharImage2!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'Aadharnumberfrontimage',
            await new http.ByteStream(
                File(model.aadharImage2!.path).openRead()),
            await File(model.aadharImage2!.path).length(),
            filename: model.aadharImage2!.path.split("/").last));
      }
      if (![null, ""].contains(model.vehicleImage)) {
        List<int> bytes = File(model.vehicleImage!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'vehicle_image',
            await new http.ByteStream(
                File(model.vehicleImage!.path).openRead()),
            await File(model.vehicleImage!.path).length(),
            filename: model.vehicleImage!.path.split("/").last));
      }
      if (![null, ""].contains(model.vehicle_image_right)) {
        List<int> bytes =
            File(model.vehicle_image_right!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'vehicle_image_right',
            await new http.ByteStream(
                File(model.vehicle_image_right!.path).openRead()),
            await File(model.vehicle_image_right!.path).length(),
            filename: model.vehicle_image_right!.path.split("/").last));
      }
      if (![null, ""].contains(model.vehicle_image_left)) {
        List<int> bytes =
            File(model.vehicle_image_left!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'vehicle_image_left',
            await new http.ByteStream(
                File(model.vehicle_image_left!.path).openRead()),
            await File(model.vehicle_image_left!.path).length(),
            filename: model.vehicle_image_left!.path.split("/").last));
      }
      if (![null, ""].contains(model.vehicle_image_back)) {
        List<int> bytes =
            File(model.vehicle_image_back!.path).readAsBytesSync();
        String img64 = base64Encode(bytes);

        request.files.add(await http.MultipartFile(
            'vehicle_image_back',
            await new http.ByteStream(
                File(model.vehicle_image_back!.path).openRead()),
            await File(model.vehicle_image_back!.path).length(),
            filename: model.vehicle_image_back!.path.split("/").last));
      }
      // print(jsonEncode(model));
      request.headers.addAll(headers);
      var responseData = await request.send();
      print(responseData);
      if (responseData.statusCode == 200) {
      } else if (responseData.statusCode == 422 /*&& data!=null*/) {
        // showTostMsg(data["message"]);
      } else {
        showTostMsg("Something went wrong");
      }
      responseData.stream.transform(utf8.decoder).listen((value) {
        print(value);
        var data = jsonDecode(value);
        print(data);
        if (responseData.statusCode == 200) {
          EasyLoading.dismiss(animation: true);
          if (data["status"].toString().toLowerCase().contains('true')) {
            showTostMsg("Saved Successfully");
            mypref.setString(AppConstants.USER_TYPE, "vehicle");
            mypref.setString(AppConstants.USER_NAME, model.ownername!);
            // mypref.setString(AppConstants.product_id, model.Id!);
            loadSPDATA();
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => BottomNavBar(0)));
          } else {
            showTostMsg(data['data']['message']);
          }
          print("true==" + jsonEncode(value));
        } else {
          showTostMsg("Something went wrong");
          print("else==" + jsonEncode(value));
        }
      });
    } catch (ex) {
      print(ex);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  //PHOE PAY API
  String sha256Hash(String input) {
    var bytes = utf8.encode(input); // Encode the input string as UTF-8 bytes
    var digest = sha256.convert(bytes); // Compute the SHA256 hash
    return digest.toString(); // Return the hash as a hex string
  }

  phone_pay() async {
    try {
      notifyListeners();
      print(AppConstants.PHONE_PAY_API);
      String merTranId = randomNumeric(13);

      Map map = {
        "merchantId": "ASIYAIHEAVYONLINE",
        "merchantTransactionId": "MT" + merTranId,
        "merchantUserId": "MU933037302229373",
        "amount": 10000,
        "callbackUrl": "https://webhook.site/callback-url",
        "mobileNumber": "9660856339",
        "deviceContext": {"deviceOS": "ANDROID"},
        "paymentInstrument": {
          "type": "UPI_INTENT",
          "targetApp": "com.phonepe.app"
        }
      };
      var baseCode = base64.encode(utf8.encode(jsonEncode(map)));
      var sha256Code = sha256Hash(
          baseCode + "/pg/v1/pay" + "a30df923-b5a8-46c2-b8d7-662fea5e0b14");

      Map requestMap = {"request": baseCode};

      print(jsonEncode(requestMap));

      final response = await http.post(Uri.parse(AppConstants.PHONE_PAY_API),
          body: jsonEncode(requestMap),
          headers: {
            "Content-Type": "application/json",
            "X-VERIFY": sha256Code + "###" + randomNumeric(1)
          });

      print(baseCode);
      print(sha256Code);
      print(map);
      print(sha256Code + "###" + randomNumeric(1));
      print(response.body);
      if (response.statusCode == 200) {
        print(response.body);
      }
    } catch (e) {
      print(e);
    }
  }
}
