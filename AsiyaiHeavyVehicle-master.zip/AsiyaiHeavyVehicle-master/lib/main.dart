import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/provider/img_vid_provider.dart';
import 'package:asiayai_heavy_vehicle_app/view/Add_Address.dart/add_address.dart';

import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Dashboard/body.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/bottoms_nav_bar.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/DriverNew/driver.post.dart';
import 'package:asiayai_heavy_vehicle_app/view/Payment/pay_screen.dart';

import 'package:asiayai_heavy_vehicle_app/view/Payment/payment_screen.dart';

import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/heavy_vehicle.dart';

import 'package:asiayai_heavy_vehicle_app/view/SigunUp/otp_page.dart';
import 'package:asiayai_heavy_vehicle_app/view/SigunUp/signup_page.dart';
import 'package:asiayai_heavy_vehicle_app/view/Splash/splash_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/VehicleDetails/vehicle_details.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:provider/provider.dart';
import 'get_it_container.dart' as g_it;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await EasyLocalization.ensureInitialized();
  runApp(EasyLocalization(
    supportedLocales: const [
      Locale('hi', 'IN'),
      Locale('en', 'US'),
      Locale('hi', 'HI'),
      Locale('kn', 'KN'),
      Locale('mr', 'MR'),
    ],
    path: "assets/translations",
    saveLocale: true,
    fallbackLocale: const Locale('en', 'US'),
    child: const MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // ChangeNotifierProvider(create: (context) => g_it.gi<AuthProvider>()),
        // ChangeNotifierProvider(create: (context) => g_it.gi<AddressProvider>()),
        // // ChangeNotifierProvider(
        // //     create: (context) => g_it.gi<RegisterProvider>()),
        // ChangeNotifierProvider(
        //     create: (context) => g_it.gi<MasterDataProvider>()),

        // ChangeNotifierProvider(create: (context) => g_it.gi<RequestProvider>()),
        // ChangeNotifierProvider(
        //     create: (context) => g_it.gi<PostAddressProvider>()),

        ChangeNotifierProvider(create: (context) => UserProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        builder: EasyLoading.init(),
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        localizationsDelegates: context.localizationDelegates,
        supportedLocales: context.supportedLocales,
        locale: context.locale,
        home: SplashScreen(),
      ),
    );
  }
}
