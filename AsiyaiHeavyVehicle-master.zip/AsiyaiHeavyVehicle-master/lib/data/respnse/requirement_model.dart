class RequiementDataModel {
  bool? status;
  RequiementData? data;

  RequiementDataModel({this.status, this.data});

  RequiementDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data =
        json['data'] != null ? new RequiementData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class RequiementData {
  String? message;
  int? user;
  List<Requiremnts>? requiremnts;

  RequiementData({this.message, this.user, this.requiremnts});

  RequiementData.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    user = json['user'];
    if (json['requiremnts'] != null) {
      requiremnts = <Requiremnts>[];
      json['requiremnts'].forEach((v) {
        requiremnts!.add(new Requiremnts.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['user'] = this.user;
    if (this.requiremnts != null) {
      data['requiremnts'] = this.requiremnts!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Requiremnts {
  int? id;
  AcceptedRequirement? acceptedRequirement;
  String? title;
  String? description;
  String? requirementImage;
  bool? isActive;

  Requiremnts(
      {this.id,
      this.acceptedRequirement,
      this.title,
      this.description,
      this.requirementImage,
      this.isActive});

  Requiremnts.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    acceptedRequirement = json['accepted_requirement'] != null
        ? new AcceptedRequirement.fromJson(json['accepted_requirement'])
        : null;
    title = json['title'] != null ? json['title'].toString() : "";
    description =
        json['description'] != null ? json['description'].toString() : "";
    requirementImage = json['requirement_image'] != null
        ? json['requirement_image'].toString()
        : "";
    isActive = json['is_active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.acceptedRequirement != null) {
      data['accepted_requirement'] = this.acceptedRequirement!.toJson();
    }
    data['title'] = this.title;
    data['description'] = this.description;
    data['requirement_image'] = this.requirementImage;
    data['is_active'] = this.isActive;
    return data;
  }
}

class AcceptedRequirement {
  int? id;
  bool? status;
  int? requirement;

  AcceptedRequirement({this.id, this.status, this.requirement});

  AcceptedRequirement.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    status = json['status'];
    requirement = json['requirement'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['status'] = this.status;
    data['requirement'] = this.requirement;
    return data;
  }
}
