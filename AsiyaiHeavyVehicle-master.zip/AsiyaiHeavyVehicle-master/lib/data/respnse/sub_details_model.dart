class SubContructorData {
  bool? status;
  Data? data;

  SubContructorData({this.status, this.data});

  SubContructorData.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  Subcontructor? subcontructor;

  Data({this.subcontructor});

  Data.fromJson(Map<String, dynamic> json) {
    subcontructor = json['subcontructor'] != null
        ? new Subcontructor.fromJson(json['subcontructor'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.subcontructor != null) {
      data['subcontructor'] = this.subcontructor!.toJson();
    }
    return data;
  }
}

class Subcontructor {
  String? id;
  String? contractorname;
  String? firmname;
  String? typeofwork;
  String? emailId;
  String? expriencesinyear;
  String? licenseNumber;
  String? aadharnumberfrontimage;
  String? aadharnumberbackimage;
  String? mobilenumber;
  String? subcontractorImage;
  String? subcontractorImageBack;
  String? subcontractorImageLeft;
  String? subcontractorImageRight;
  String? expiredAt;
  bool? isActive;
  Address? address;
  bool? isReserved;
  bool? myRequest;

  Subcontructor(
      {this.id,
      this.contractorname,
      this.firmname,
      this.typeofwork,
      this.emailId,
      this.expriencesinyear,
      this.licenseNumber,
      this.aadharnumberfrontimage,
      this.aadharnumberbackimage,
      this.mobilenumber,
      this.subcontractorImage,
      this.subcontractorImageBack,
      this.subcontractorImageLeft,
      this.subcontractorImageRight,
      this.expiredAt,
      this.isActive,
      this.address,
      this.isReserved,
      this.myRequest});

  Subcontructor.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString() : "";
    contractorname =
        json['contractorname'] != null ? json['contractorname'].toString() : "";
    firmname = json['firmname'] != null ? json['firmname'].toString() : "";
    typeofwork =
        json['typeofwork'] != null ? json['typeofwork'].toString() : "";
    emailId = json['emailId'] != null ? json['emailId'].toString() : "";
    expriencesinyear = json['expriencesinyear'] != null
        ? json['expriencesinyear'].toString()
        : "";
    licenseNumber =
        json['license_number'] != null ? json['license_number'].toString() : "";
    aadharnumberfrontimage = json['Aadharnumberfrontimage'] != null
        ? json['Aadharnumberfrontimage'].toString()
        : "";
    aadharnumberbackimage = json['Aadharnumberbackimage'] != null
        ? json['Aadharnumberbackimage'].toString()
        : "";
    mobilenumber =
        json['mobilenumber'] != null ? json['mobilenumber'].toString() : "";
    subcontractorImage = json['subcontractor_image'] != null
        ? json['subcontractor_image'].toString()
        : "";
    subcontractorImageBack = json['subcontractor_image_back'] != null
        ? json['subcontractor_image_back'].toString()
        : "";
    subcontractorImageLeft = json['subcontractor_image_left'] != null
        ? json['subcontractor_image_left'].toString()
        : "";
    subcontractorImageRight = json['subcontractor_image_right'] != null
        ? json['subcontractor_image_right'].toString()
        : "";
    expiredAt = json['expired_at'];
    isActive = json['is_active'];
    address =
        json['address'] != null ? new Address.fromJson(json['address']) : null;
    isReserved = json['is_reserved'];
    myRequest = json['my_request'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['contractorname'] = this.contractorname;
    data['firmname'] = this.firmname;
    data['typeofwork'] = this.typeofwork;
    data['emailId'] = this.emailId;
    data['expriencesinyear'] = this.expriencesinyear;
    data['license_number'] = this.licenseNumber;
    data['Aadharnumberfrontimage'] = this.aadharnumberfrontimage;
    data['Aadharnumberbackimage'] = this.aadharnumberbackimage;
    data['mobilenumber'] = this.mobilenumber;
    data['subcontractor_image'] = this.subcontractorImage;
    data['subcontractor_image_back'] = this.subcontractorImageBack;
    data['subcontractor_image_left'] = this.subcontractorImageLeft;
    data['subcontractor_image_right'] = this.subcontractorImageRight;
    data['expired_at'] = this.expiredAt;
    data['is_active'] = this.isActive;
    if (this.address != null) {
      data['address'] = this.address!.toJson();
    }
    data['is_reserved'] = this.isReserved;
    data['my_request'] = this.myRequest;
    return data;
  }
}

class Address {
  int? id;
  bool? isActive;
  StateId? stateId;
  DistrictId? districtId;
  TahseelId? tahseelId;

  Address(
      {this.id, this.isActive, this.stateId, this.districtId, this.tahseelId});

  Address.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    isActive = json['is_active'];
    stateId = json['state_id'] != null
        ? new StateId.fromJson(json['state_id'])
        : null;
    districtId = json['district_id'] != null
        ? new DistrictId.fromJson(json['district_id'])
        : null;
    tahseelId = json['tahseel_id'] != null
        ? new TahseelId.fromJson(json['tahseel_id'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['is_active'] = this.isActive;
    if (this.stateId != null) {
      data['state_id'] = this.stateId!.toJson();
    }
    if (this.districtId != null) {
      data['district_id'] = this.districtId!.toJson();
    }
    if (this.tahseelId != null) {
      data['tahseel_id'] = this.tahseelId!.toJson();
    }
    return data;
  }
}

class StateId {
  int? id;
  String? stateName;

  StateId({this.id, this.stateName});

  StateId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    stateName = json['state_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['state_name'] = this.stateName;
    return data;
  }
}

class DistrictId {
  int? id;
  String? districtName;
  int? stateId;

  DistrictId({this.id, this.districtName, this.stateId});

  DistrictId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    districtName = json['district_name'];
    stateId = json['state_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['district_name'] = this.districtName;
    data['state_id'] = this.stateId;
    return data;
  }
}

class TahseelId {
  int? id;
  String? tahseelName;
  int? districtId;

  TahseelId({this.id, this.tahseelName, this.districtId});

  TahseelId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    tahseelName = json['tahseel_name'];
    districtId = json['district_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['tahseel_name'] = this.tahseelName;
    data['district_id'] = this.districtId;
    return data;
  }
}
