class ResponceModel {
  String? message;
  String? status;
  String? accessToken;
  dynamic data;
  dynamic error;

  ResponceModel(
      {required this.data,
      required this.message,
      required this.status,
      this.accessToken});

  ResponceModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    status = json['status'].toString();
    accessToken = json['accessToken'].toString();
    data = json['data'];
    error = json['error'];
  }
}
