class ImgVidModel {
  String? status;
  List<Imgvedio>? imgvedio;

  ImgVidModel({this.status, this.imgvedio});

  ImgVidModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['imgvedio'] != null) {
      imgvedio = <Imgvedio>[];
      json['imgvedio'].forEach((v) {
        imgvedio!.add(new Imgvedio.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.imgvedio != null) {
      data['imgvedio'] = this.imgvedio!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Imgvedio {
  int? id;
  String? imageUplaod;
  String? vediourl;

  Imgvedio({this.id, this.imageUplaod, this.vediourl});

  Imgvedio.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    imageUplaod = json['image_uplaod'];
    vediourl = json['vediourl'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.id;
    data['image_uplaod'] = this.imageUplaod;
    data['vediourl'] = this.vediourl;
    return data;
  }
}
