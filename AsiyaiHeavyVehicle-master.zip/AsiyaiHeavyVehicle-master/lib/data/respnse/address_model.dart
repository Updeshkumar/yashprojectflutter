class StateModel {
  int? id;
  String? stateName;

  StateModel({this.id, this.stateName});

  StateModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    stateName = json['state_name'] != null ? json['state_name'].toString() : "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['state_name'] = this.stateName;
    return data;
  }
}

class DistrictModel {
  int? id;
  String? districtName;
  String? stateId;

  DistrictModel({this.id, this.districtName, this.stateId});

  DistrictModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    districtName =
        json['district_name'] != null ? json['district_name'].toString() : "";
    stateId = json['state_id'] != null ? json['state_id'].toString() : "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['district_name'] = this.districtName;
    data['state_id'] = this.stateId;
    return data;
  }
}

class TehsilModel {
  int? id;
  String? tahseelName;
  String? districtId;

  TehsilModel({this.id, this.tahseelName, this.districtId});

  TehsilModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    tahseelName =
        json['tahseel_name'] != null ? json['tahseel_name'].toString() : "";
    districtId =
        json['district_id'] != null ? json['district_id'].toString() : "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['tahseel_name'] = this.tahseelName;
    data['district_id'] = this.districtId;
    return data;
  }
}
