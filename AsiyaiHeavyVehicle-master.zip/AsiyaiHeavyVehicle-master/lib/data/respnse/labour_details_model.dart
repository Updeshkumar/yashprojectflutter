class LabourDataModel {
  bool? status;
  Data? data;

  LabourDataModel({this.status, this.data});

  LabourDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  Labour? labour;

  Data({this.labour});

  Data.fromJson(Map<String, dynamic> json) {
    labour =
        json['labour'] != null ? new Labour.fromJson(json['labour']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.labour != null) {
      data['labour'] = this.labour!.toJson();
    }
    return data;
  }
}

class Labour {
  String? id;
  String? name;
  String? labourwork;
  String? emailId;
  String? lobourinnumber;
  String? mobileNumber;
  String? skilledlabour;
  String? unskilledlabour;
  String? professionallabour;
  String? aadharnumberfrontimage;
  String? aadharnumberbackimage;
  String? alternativemobilenumber;
  String? labourImage;
  bool? labourPaid;
  String? expiredAt;
  bool? isActive;

  Labour(
      {this.id,
      this.name,
      this.labourwork,
      this.emailId,
      this.lobourinnumber,
      this.mobileNumber,
      this.skilledlabour,
      this.unskilledlabour,
      this.professionallabour,
      this.aadharnumberfrontimage,
      this.aadharnumberbackimage,
      this.alternativemobilenumber,
      this.labourImage,
      this.labourPaid,
      this.expiredAt,
      this.isActive});

  Labour.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString() : "";
    name = json['name'] != null ? json['name'].toString() : "";
    labourwork =
        json['labourwork'] != null ? json['labourwork'].toString() : "";
    emailId = json['emailId'] != null ? json['emailId'].toString() : "";
    lobourinnumber =
        json['lobourinnumber'] != null ? json['lobourinnumber'].toString() : "";
    mobileNumber =
        json['mobile_number'] != null ? json['mobile_number'].toString() : "";
    skilledlabour =
        json['skilledlabour'] != null ? json['skilledlabour'].toString() : "";
    unskilledlabour = json['unskilledlabour'] != null
        ? json['unskilledlabour'].toString()
        : "";
    professionallabour = json['professionallabour'] != null
        ? json['professionallabour'].toString()
        : "";
    aadharnumberfrontimage = json['Aadharnumberfrontimage'] != null
        ? json['Aadharnumberfrontimage'].toString()
        : "";
    aadharnumberbackimage = json['Aadharnumberbackimage'] != null
        ? json['Aadharnumberbackimage'].toString()
        : "";
    alternativemobilenumber = json['alternativemobilenumber'] != null
        ? json['alternativemobilenumber'].toString()
        : "";
    labourImage =
        json['labour_image'] != null ? json['labour_image'].toString() : "";
    labourPaid = json['labour_paid'];
    expiredAt = json['expired_at'];
    isActive = json['is_active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['labourwork'] = this.labourwork;
    data['emailId'] = this.emailId;
    data['lobourinnumber'] = this.lobourinnumber;
    data['mobile_number'] = this.mobileNumber;
    data['skilledlabour'] = this.skilledlabour;
    data['unskilledlabour'] = this.unskilledlabour;
    data['professionallabour'] = this.professionallabour;
    data['Aadharnumberfrontimage'] = this.aadharnumberfrontimage;
    data['Aadharnumberbackimage'] = this.aadharnumberbackimage;
    data['alternativemobilenumber'] = this.alternativemobilenumber;
    data['labour_image'] = this.labourImage;
    data['labour_paid'] = this.labourPaid;
    data['expired_at'] = this.expiredAt;
    data['is_active'] = this.isActive;
    return data;
  }
}
