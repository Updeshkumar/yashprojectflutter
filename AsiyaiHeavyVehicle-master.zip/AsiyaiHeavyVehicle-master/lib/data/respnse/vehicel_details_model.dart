class HeavyVehicleDataModel {
  bool? status;
  HeavyVehicleData? data;

  HeavyVehicleDataModel({this.status, this.data});

  HeavyVehicleDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null
        ? new HeavyVehicleData.fromJson(json['data'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class HeavyVehicleData {
  String? message;
  List<Vehiclelist>? vehiclelist;

  HeavyVehicleData({this.message, this.vehiclelist});

  HeavyVehicleData.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    if (json['vehiclelist'] != null) {
      vehiclelist = <Vehiclelist>[];
      json['vehiclelist'].forEach((v) {
        vehiclelist!.add(new Vehiclelist.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    if (this.vehiclelist != null) {
      data['vehiclelist'] = this.vehiclelist!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Vehiclelist {
  String? id;
  String? user;
  String? vehicalName;
  String? companyName;
  String? emailId;
  String? ownername;
  String? vehicleregistrationnumber;
  String? aadharnumberfrontimage;
  String? aadharnumberbackimage;
  String? vehicleImage;
  String? vehicleImageBack;
  String? vehicleImageLeft;
  String? vehicleImageRight;
  String? manufactureDate;
  String? alternativemobilenumber;
  String? vehiclemodelnumber;
  bool? isActive;
  String? expiredAt;
  bool? isReserved;
  bool? isPaid;
  int? amount;
  Address? address;

  Vehiclelist(
      {this.id,
      this.user,
      this.vehicalName,
      this.companyName,
      this.emailId,
      this.ownername,
      this.vehicleregistrationnumber,
      this.aadharnumberfrontimage,
      this.aadharnumberbackimage,
      this.vehicleImage,
      this.vehicleImageBack,
      this.vehicleImageLeft,
      this.vehicleImageRight,
      this.manufactureDate,
      this.alternativemobilenumber,
      this.vehiclemodelnumber,
      this.isActive,
      this.expiredAt,
      this.isReserved,
      this.isPaid,
      this.amount,
      this.address});

  Vehiclelist.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString() : "";
    user = json['user'] != null ? json['user'].toString() : "";
    vehicalName =
        json['vehical_name'] != null ? json['vehical_name'].toString() : "";
    companyName =
        json['company_name'] != null ? json['company_name'].toString() : "";
    emailId = json['emailId'] != null ? json['emailId'].toString() : "";
    ownername = json['ownername'] != null ? json['ownername'].toString() : "";
    vehicleregistrationnumber = json['vehicleregistrationnumber'] != null
        ? json['vehicleregistrationnumber'].toString()
        : "";
    aadharnumberfrontimage = json['Aadharnumberfrontimage'] != null
        ? json['Aadharnumberfrontimage'].toString()
        : "";
    aadharnumberbackimage = json['Aadharnumberbackimage'] != null
        ? json['Aadharnumberbackimage'].toString()
        : "";
    vehicleImage =
        json['vehicle_image'] != null ? json['vehicle_image'].toString() : "";
    vehicleImageBack = json['vehicle_image_back'] != null
        ? json['vehicle_image_back'].toString()
        : "";
    vehicleImageLeft = json['vehicle_image_left'] != null
        ? json['vehicle_image_left'].toString()
        : "";
    vehicleImageRight = json['vehicle_image_right'] != null
        ? json['vehicle_image_right'].toString()
        : "";
    manufactureDate = json['manufacture_date'] != null
        ? json['manufacture_date'].toString()
        : "";
    alternativemobilenumber = json['alternativemobilenumber'] != null
        ? json['alternativemobilenumber'].toString()
        : "";
    vehiclemodelnumber = json['vehiclemodelnumber'] != null
        ? json['vehiclemodelnumber'].toString()
        : "";
    isActive = json['is_active'];
    expiredAt = json['expired_at'];
    isReserved = json['is_reserved'];
    isPaid = json['is_paid'];
    amount = json['amount'];
    address =
        json['address'] != null ? new Address.fromJson(json['address']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user'] = this.user;
    data['vehical_name'] = this.vehicalName;
    data['company_name'] = this.companyName;
    data['emailId'] = this.emailId;
    data['ownername'] = this.ownername;
    data['vehicleregistrationnumber'] = this.vehicleregistrationnumber;
    data['Aadharnumberfrontimage'] = this.aadharnumberfrontimage;
    data['Aadharnumberbackimage'] = this.aadharnumberbackimage;
    data['vehicle_image'] = this.vehicleImage;
    data['vehicle_image_back'] = this.vehicleImageBack;
    data['vehicle_image_left'] = this.vehicleImageLeft;
    data['vehicle_image_right'] = this.vehicleImageRight;
    data['manufacture_date'] = this.manufactureDate;
    data['alternativemobilenumber'] = this.alternativemobilenumber;
    data['vehiclemodelnumber'] = this.vehiclemodelnumber;
    data['is_active'] = this.isActive;
    data['expired_at'] = this.expiredAt;
    data['is_reserved'] = this.isReserved;
    data['is_paid'] = this.isPaid;
    data['amount'] = this.amount;
    if (this.address != null) {
      data['address'] = this.address!.toJson();
    }
    return data;
  }
}

class Address {
  int? id;
  bool? isActive;
  int? heavyvehivalregistration;
  int? stateId;
  int? districtId;
  int? tahseelId;

  Address(
      {this.id,
      this.isActive,
      this.heavyvehivalregistration,
      this.stateId,
      this.districtId,
      this.tahseelId});

  Address.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    isActive = json['is_active'];
    heavyvehivalregistration = json['heavyvehivalregistration'];
    stateId = json['state_id'];
    districtId = json['district_id'];
    tahseelId = json['tahseel_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['is_active'] = this.isActive;
    data['heavyvehivalregistration'] = this.heavyvehivalregistration;
    data['state_id'] = this.stateId;
    data['district_id'] = this.districtId;
    data['tahseel_id'] = this.tahseelId;
    return data;
  }
}
