class DriverDataModel {
  bool? status;
  Data? data;

  DriverDataModel({this.status, this.data});

  DriverDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  DriverData? driver;

  Data({this.driver});

  Data.fromJson(Map<String, dynamic> json) {
    driver =
        json['driver'] != null ? new DriverData.fromJson(json['driver']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.driver != null) {
      data['driver'] = this.driver!.toJson();
    }
    return data;
  }
}

class DriverData {
  String? id;
  String? user;
  String? vehicalname;
  String? expriencesinyear;
  String? driveroperatorname;
  String? aadharnumberfrontimage;
  String? aadharnumberbackimage;
  String? alternetMobilenumber;
  String? heavyLicense;
  String? emailId;
  String? mobilenumber;
  String? licenseImage;
  String? driverImage;
  bool? isActive;
  bool? driverPaid;
  String? expiredAt;
  Address? address;
  bool? isReserved;
  bool? myRequest;

  DriverData(
      {this.id,
      this.user,
      this.vehicalname,
      this.expriencesinyear,
      this.driveroperatorname,
      this.aadharnumberfrontimage,
      this.aadharnumberbackimage,
      this.alternetMobilenumber,
      this.heavyLicense,
      this.emailId,
      this.mobilenumber,
      this.licenseImage,
      this.driverImage,
      this.isActive,
      this.driverPaid,
      this.expiredAt,
      this.address,
      this.isReserved,
      this.myRequest});

  DriverData.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString() : "";
    user = json['user'] != null ? json['user'].toString() : "";
    vehicalname =
        json['vehicalname'] != null ? json['vehicalname'].toString() : "";
    expriencesinyear = json['expriencesinyear'] != null
        ? json['expriencesinyear'].toString()
        : "";
    driveroperatorname = json['driveroperatorname'] != null
        ? json['driveroperatorname'].toString()
        : "";
    aadharnumberfrontimage = json['Aadharnumberfrontimage'] != null
        ? json['Aadharnumberfrontimage'].toString()
        : "";
    aadharnumberbackimage = json['Aadharnumberbackimage'] != null
        ? json['Aadharnumberbackimage'].toString()
        : "";
    alternetMobilenumber = json['alternet_mobilenumber'] != null
        ? json['alternet_mobilenumber'].toString()
        : "";
    heavyLicense =
        json['heavy_license'] != null ? json['heavy_license'].toString() : "";
    emailId = json['emailId'] != null ? json['emailId'].toString() : "";
    mobilenumber =
        json['mobilenumber'] != null ? json['mobilenumber'].toString() : "";
    licenseImage =
        json['license_image'] != null ? json['license_image'].toString() : "";
    driverImage =
        json['driver_image'] != null ? json['driver_image'].toString() : "";
    isActive = json['is_active'];
    driverPaid = json['driver_paid'];
    expiredAt = json['expired_at'];
    address =
        json['address'] != null ? new Address.fromJson(json['address']) : null;
    isReserved = json['is_reserved'];
    myRequest = json['my_request'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user'] = this.user;
    data['vehicalname'] =
        this.vehicalname != null ? this.vehicalname.toString() : "";
    data['expriencesinyear'] = this.expriencesinyear;
    data['driveroperatorname'] = this.driveroperatorname;
    data['Aadharnumberfrontimage'] = this.aadharnumberfrontimage;
    data['Aadharnumberbackimage'] = this.aadharnumberbackimage;
    data['alternet_mobilenumber'] = this.alternetMobilenumber;
    data['heavy_license'] = this.heavyLicense;
    data['emailId'] = this.emailId;
    data['mobilenumber'] = this.mobilenumber;
    data['license_image'] = this.licenseImage;
    data['driver_image'] = this.driverImage;
    data['is_active'] = this.isActive;
    data['driver_paid'] = this.driverPaid;
    data['expired_at'] = this.expiredAt;
    if (this.address != null) {
      data['address'] = this.address!.toJson();
    }
    data['is_reserved'] = this.isReserved;
    data['my_request'] = this.myRequest;
    return data;
  }
}

class Address {
  int? id;
  bool? isActive;
  StateId? stateId;
  DistrictId? districtId;
  TahseelId? tahseelId;

  Address(
      {this.id, this.isActive, this.stateId, this.districtId, this.tahseelId});

  Address.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    isActive = json['is_active'];
    stateId = json['state_id'] != null
        ? new StateId.fromJson(json['state_id'])
        : null;
    districtId = json['district_id'] != null
        ? new DistrictId.fromJson(json['district_id'])
        : null;
    tahseelId = json['tahseel_id'] != null
        ? new TahseelId.fromJson(json['tahseel_id'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['is_active'] = this.isActive;
    if (this.stateId != null) {
      data['state_id'] = this.stateId!.toJson();
    }
    if (this.districtId != null) {
      data['district_id'] = this.districtId!.toJson();
    }
    if (this.tahseelId != null) {
      data['tahseel_id'] = this.tahseelId!.toJson();
    }
    return data;
  }
}

class StateId {
  int? id;
  String? stateName;

  StateId({this.id, this.stateName});

  StateId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    stateName = json['state_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['state_name'] = this.stateName;
    return data;
  }
}

class DistrictId {
  int? id;
  String? districtName;
  int? stateId;

  DistrictId({this.id, this.districtName, this.stateId});

  DistrictId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    districtName = json['district_name'];
    stateId = json['state_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['district_name'] = this.districtName;
    data['state_id'] = this.stateId;
    return data;
  }
}

class TahseelId {
  int? id;
  String? tahseelName;
  int? districtId;

  TahseelId({this.id, this.tahseelName, this.districtId});

  TahseelId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    tahseelName = json['tahseel_name'];
    districtId = json['district_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['tahseel_name'] = this.tahseelName;
    data['district_id'] = this.districtId;
    return data;
  }
}
