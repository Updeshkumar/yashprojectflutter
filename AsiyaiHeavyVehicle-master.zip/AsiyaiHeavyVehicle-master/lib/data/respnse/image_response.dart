class ImageResponse {
  String? message;
  String? status;
  String? imageUrl;

  ImageResponse({this.message, this.status, this.imageUrl});

  ImageResponse.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    status = json['status'];
    imageUrl = json['image_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['status'] = this.status;
    data['image_url'] = this.imageUrl;
    return data;
  }
}
