class AddressModel {
  int? id;
  String? keyName;
  String? valueName;
  int? relatedToId;
  String? relateToName;

  AddressModel(
      {this.id,
      this.keyName,
      this.valueName,
      this.relatedToId,
      this.relateToName});

  AddressModel.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    keyName = json['keyName'];
    valueName = json['valueName'];
    relatedToId = json['relatedToId'];
    relateToName = json['relateToName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.id;
    data['keyName'] = this.keyName;
    data['valueName'] = this.valueName;
    data['relatedToId'] = this.relatedToId;
    data['relateToName'] = this.relateToName;
    return data;
  }
}
