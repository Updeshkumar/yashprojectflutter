class PostAddressModel {
  int? cityId;
  int? countryId;
  int? districtId;
  int? stateId;

  PostAddressModel(
      {this.cityId, this.countryId, this.districtId, this.stateId});

  PostAddressModel.fromJson(Map<String, dynamic> json) {
    cityId = json['city_id'];
    countryId = json['country_id'];
    districtId = json['district_id'];
    stateId = json['state_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['city_id'] = this.cityId;
    data['country_id'] = this.countryId;
    data['district_id'] = this.districtId;
    data['state_id'] = this.stateId;
    return data;
  }
}
