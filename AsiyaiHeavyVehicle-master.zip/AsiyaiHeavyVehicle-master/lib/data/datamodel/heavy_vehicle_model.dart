import 'dart:io';

class HeavyVehicleModel {
  String? Id;
  String? vehicalName;
  String? companyName;
  String? vehicalNumber;
  String? vehiclemodelnumber;
  String? vehicleregistrationnumber;
  String? ownername;
  int? aadharNumber;
  String? alternativemobileNumber;
  File? vehicleImage;
  String? manufectoringDate;
  File? aadharImage1;
  File? aadharImage2;
  String? emailId;
  File? vehicle_image_back;
  File? vehicle_image_left;
  File? vehicle_image_right;

  HeavyVehicleModel({
    this.vehicalName,
    this.companyName,
    this.vehicalNumber,
    this.ownername,
    this.aadharNumber,
    this.vehicleImage,
    this.manufectoringDate,
    this.alternativemobileNumber,
    this.vehiclemodelnumber,
    this.vehicleregistrationnumber,
    this.aadharImage1,
    this.aadharImage2,
    this.emailId,
    this.Id,
    this.vehicle_image_back,
    this.vehicle_image_left,
    this.vehicle_image_right,
  });

  HeavyVehicleModel.fromJson(Map<String, dynamic> json) {
    Id = json['Id'];
    vehicalName = json['vehical_name'];
    companyName = json['company_name'];
    vehicalNumber = json['vehical_number'];

    ownername = json['ownername'];
    aadharNumber = json['Aadhar_number'];
    vehicleImage = json['vehicle_image'];
    manufectoringDate = json['manufacture_date'];
    alternativemobileNumber = json['alternativemobilenumber'];
    vehiclemodelnumber = json['vehiclemodelnumber'];
    vehicleregistrationnumber = json['vehicleregistrationnumber'];
    aadharImage1 = json['Aadharnumberfrontimage'];
    aadharImage2 = json['Aadharnumberbackimage'];
    emailId = json['emailId'];
    vehicle_image_back = json['vehicle_image_back'];
    vehicle_image_left = json['vehicle_image_left'];
    vehicle_image_right = json['vehicle_image_right'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.Id;
    data['vehical_name'] = this.vehicalName;
    data['company_name'] = this.companyName;
    data['vehical_number'] = this.vehicalNumber;

    data['ownername'] = this.ownername;
    data['Aadhar_number'] = this.aadharNumber;
    data['vehicle_image'] = this.vehicleImage;
    data['manufacture_date'] = this.manufectoringDate;
    data['alternativemobilenumber'] = this.alternativemobileNumber;
    data['vehicleregistrationnumber'] = this.vehicleregistrationnumber;
    data['vehiclemodelnumber'] = this.vehiclemodelnumber;
    data['Aadharnumberfrontimage'] = this.aadharImage1;
    data['Aadharnumberbackimage'] = this.aadharImage2;
    data['emailId'] = this.emailId;
    data['vehicle_image_back'] = this.vehicle_image_back;
    data['vehicle_image_left'] = this.vehicle_image_left;
    data['vehicle_image_right'] = this.vehicle_image_right;

    return data;
  }
}
