import 'dart:io';

class DriverModel {
  String? vehicalname;
  String? expriencesinyear;
  String? driveroperatorname;
  String? aadharNumber;
  String? alternetMobilenumber;
  String? licenseNumber;
  File? driverImage;
  String? mobileNumber;
  File? licenseImage;
  String? emailId;
  File? aadharFront;
  File? aadharBack;
  String? license_check;

  DriverModel(
      {this.vehicalname,
      this.expriencesinyear,
      this.driveroperatorname,
      this.aadharNumber,
      this.alternetMobilenumber,
      this.licenseNumber,
      this.driverImage,
      this.mobileNumber,
      this.licenseImage,
      this.aadharBack,
      this.aadharFront,
      this.emailId,
      this.license_check});

  DriverModel.fromJson(Map<String, dynamic> json) {
    vehicalname = json['vehicalname'];
    expriencesinyear = json['expriencesinyear'];
    driveroperatorname = json['driveroperatorname'];
    aadharNumber = json['Aadhar_number'];
    alternetMobilenumber = json['alternet_mobilenumber'];
    licenseNumber = json['license_number'];
    driverImage = json['driver_image'];
    licenseImage = json['license_image'];
    aadharBack = json['Aadharnumberbackimage'];
    aadharFront = json['Aadharnumberfrontimage'];
    emailId = json['emailId'];
    license_check = json['heavy_license'];
    mobileNumber =
        json['mobilenumber'] != null ? json['mobilenumber'].toString() : "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['vehicalname'] = this.vehicalname;
    data['expriencesinyear'] = this.expriencesinyear;
    data['driveroperatorname'] = this.driveroperatorname;
    data['Aadhar_number'] = this.aadharNumber;
    data['alternet_mobilenumber'] = this.alternetMobilenumber;
    data['license_number'] = this.licenseNumber;
    data['driver_image'] = this.driverImage;
    data['mobilenumber'] = this.mobileNumber;
    data['license_image'] = this.licenseImage;
    data['Aadharnumberbackimage'] = this.aadharBack;
    data['Aadharnumberfrontimage'] = this.aadharFront;
    data['emailId'] = this.emailId;
    data['heavy_license'] = this.license_check;

    return data;
  }
}
