import 'dart:io';

class SubContModel {
  String? contractorname;
  String? firmname;
  String? expriencesinyear;
  String? licenseNumber;
  int? aadharNumber;
  File? subcontractorImage;
  String? mobileNumber;
  String? typeofWork;
  String? emailId;
  File? aadharFront;
  File? aadharBack;
  File? subcontractor_image_back;
  File? subcontractor_image_left;
  File? subcontractor_image_right;
  String? expiredAt;

  SubContModel({
    this.contractorname,
    this.firmname,
    this.expriencesinyear,
    this.licenseNumber,
    this.aadharNumber,
    this.subcontractorImage,
    this.mobileNumber,
    this.typeofWork,
    this.aadharBack,
    this.aadharFront,
    this.emailId,
    this.subcontractor_image_back,
    this.subcontractor_image_left,
    this.subcontractor_image_right,
    this.expiredAt,
  });

  SubContModel.fromJson(Map<String, dynamic> json) {
    contractorname = json['contractorname'];
    firmname = json['firmname'];
    expriencesinyear = json['expriencesinyear'];
    licenseNumber = json['license_number'];
    aadharNumber = json['Aadhar_number'];
    subcontractorImage = json['subcontractor_image'];
    mobileNumber = json['mobilenumber'];
    typeofWork = json['typeofwork'];
    aadharBack = json['Aadharnumberbackimage'];
    aadharFront = json['Aadharnumberfrontimage'];
    emailId = json['emailId'];
    subcontractor_image_back = json['subcontractor_image_back'];
    subcontractor_image_left = json['subcontractor_image_left'];
    subcontractor_image_right = json['subcontractor_image_right'];
    expiredAt = json['expiredAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['contractorname'] = this.contractorname;
    data['firmname'] = this.firmname;
    data['expriencesinyear'] = this.expriencesinyear;
    data['license_number'] = this.licenseNumber;
    data['Aadhar_number'] = this.aadharNumber;
    data['subcontractor_image'] = this.subcontractorImage;
    data['typeofwork'] = this.typeofWork;
    data['mobilenumber'] = this.mobileNumber;
    data['Aadharnumberbackimage'] = this.aadharBack;
    data['Aadharnumberfrontimage'] = this.aadharFront;
    data['emailId'] = this.emailId;
    data['subcontractor_image_back'] = this.subcontractor_image_back;
    data['subcontractor_image_left'] = this.subcontractor_image_left;
    data['subcontractor_image_right'] = this.subcontractor_image_right;

    return data;
  }
}
