import 'dart:io';

class LabourContModel {
  String? labourcontractorname;
  String? labourwork;
  String? lobourinnumber;
  int? contractorAadharNumber;
  String? mobileNumber;
  File? labourImage;
  String? alternativemobilenumber;
  File? aadharfront;
  File? aadharback;
  String? emailId;
  String? skilledLabour;
  String? unskiledLabour;
  String? proffesionalLabour;

  LabourContModel(
      {this.labourcontractorname,
      this.labourwork,
      this.lobourinnumber,
      this.contractorAadharNumber,
      this.mobileNumber,
      this.labourImage,
      this.alternativemobilenumber,
      this.aadharback,
      this.aadharfront,
      this.emailId,
      this.proffesionalLabour,
      this.skilledLabour,
      this.unskiledLabour});

  LabourContModel.fromJson(Map<String, dynamic> json) {
    labourcontractorname = json['labourcontractorname'];
    labourwork = json['labourwork'];
    lobourinnumber = json['lobourinnumber'];
    contractorAadharNumber = json['contractorAadhar_number'];
    mobileNumber = json['mobile_number'];
    labourImage = json['labour_image'];
    alternativemobilenumber = json['alternativemobilenumber'];
    aadharback = json['Aadharnumberbackimage'];
    aadharfront = json['Aadharnumberfrontimage'];
    emailId = json['emailId'];
    skilledLabour = json['skilledlabour'];
    unskiledLabour = json['unskilledlabour'];
    proffesionalLabour = json['professionallabour'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['labourcontractorname'] = this.labourcontractorname;
    data['labourwork'] = this.labourwork;
    data['lobourinnumber'] = this.lobourinnumber;
    data['contractorAadhar_number'] = this.contractorAadharNumber;
    data['mobile_number'] = this.mobileNumber;
    data['labour_image'] = this.labourImage;
    data['alternativemobilenumber'] = this.alternativemobilenumber;
    data['Aadharnumberfrontimage'] = this.aadharfront;
    data['Aadharnumberbackimage'] = this.aadharback;
    data['emailId'] = this.emailId;
    data['skilledlabour'] = this.skilledLabour;
    data['unskilledlabour'] = this.unskiledLabour;
    data['professionallabour'] = this.proffesionalLabour;

    return data;
  }
}
