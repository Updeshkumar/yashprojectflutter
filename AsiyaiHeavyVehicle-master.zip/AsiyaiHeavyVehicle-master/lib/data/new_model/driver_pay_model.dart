class DriverPaymentModel {
  bool? status;
  Data? data;

  DriverPaymentModel({this.status, this.data});

  DriverPaymentModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? msg;
  String? url;
  String? amount;

  Data({this.msg, this.url, this.amount});

  Data.fromJson(Map<String, dynamic> json) {
    msg = json['msg'] != null ? json['msg'] : "";
    url = json['url'] != null ? json['url'] : "";
    amount = json['amount'] != null ? json['amount'].toString() : "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['msg'] = this.msg;
    data['url'] = this.url;
    data['amount'] = this.amount;
    return data;
  }
}
