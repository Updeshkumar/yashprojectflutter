class HomeDataModel {
  bool? status;
  HomeData? data;

  HomeDataModel({this.status, this.data});

  HomeDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null ? new HomeData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class HomeData {
  String? message;
  int? user;
  List<HomeVehiclelist>? vehiclelist;
  List<HomeDriverList>? driverList;
  List<LabourList>? labourList;
  List<SubcontructorList>? subcontructorList;

  HomeData(
      {this.message,
      this.user,
      this.vehiclelist,
      this.driverList,
      this.labourList,
      this.subcontructorList});

  HomeData.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    user = json['user'];
    if (json['vehiclelist'] != null) {
      vehiclelist = <HomeVehiclelist>[];
      json['vehiclelist'].forEach((v) {
        vehiclelist!.add(new HomeVehiclelist.fromJson(v));
      });
    }
    if (json['driver_list'] != null) {
      driverList = <HomeDriverList>[];
      json['driver_list'].forEach((v) {
        driverList!.add(new HomeDriverList.fromJson(v));
      });
    }
    if (json['labour_list'] != null) {
      labourList = <LabourList>[];
      json['labour_list'].forEach((v) {
        labourList!.add(new LabourList.fromJson(v));
      });
    }
    if (json['subcontructor_list'] != null) {
      subcontructorList = <SubcontructorList>[];
      json['subcontructor_list'].forEach((v) {
        subcontructorList!.add(new SubcontructorList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['user'] = this.user;
    if (this.vehiclelist != null) {
      data['vehiclelist'] = this.vehiclelist!.map((v) => v.toJson()).toList();
    }
    if (this.driverList != null) {
      data['driver_list'] = this.driverList!.map((v) => v.toJson()).toList();
    }
    if (this.labourList != null) {
      data['labour_list'] = this.labourList!.map((v) => v.toJson()).toList();
    }
    if (this.subcontructorList != null) {
      data['subcontructor_list'] =
          this.subcontructorList!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class HomeVehiclelist {
  String? id;
  String? user;
  String? vehicalName;
  String? companyName;
  String? emailId;
  String? ownername;
  String? vehicleregistrationnumber;
  String? aadharnumberfrontimage;
  String? aadharnumberbackimage;
  String? vehicleImage;
  String? vehicleImageBack;
  String? vehicleImageLeft;
  String? vehicleImageRight;
  String? manufactureDate;
  String? alternativemobilenumber;
  String? vehiclemodelnumber;
  bool? isActive;
  String? expiredAt;
  bool? isReserved;
  VehicleAddress? address;
  bool? myRequest;

  HomeVehiclelist(
      {this.id,
      this.user,
      this.vehicalName,
      this.companyName,
      this.emailId,
      this.ownername,
      this.vehicleregistrationnumber,
      this.aadharnumberfrontimage,
      this.aadharnumberbackimage,
      this.vehicleImage,
      this.vehicleImageBack,
      this.vehicleImageLeft,
      this.vehicleImageRight,
      this.manufactureDate,
      this.alternativemobilenumber,
      this.vehiclemodelnumber,
      this.isActive,
      this.expiredAt,
      this.isReserved,
      this.address,
      this.myRequest});

  HomeVehiclelist.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString() : "";
    user = json['user'] != null ? json['user'].toString() : "";
    vehicalName =
        json['vehical_name'] != null ? json['vehical_name'].toString() : "";
    companyName =
        json['company_name'] != null ? json['company_name'].toString() : "";
    emailId = json['emailId'] != null ? json['emailId'].toString() : "";
    ownername = json['ownername'] != null ? json['ownername'].toString() : "";
    vehicleregistrationnumber = json['vehicleregistrationnumber'] != null
        ? json['vehicleregistrationnumber'].toString()
        : "";
    aadharnumberfrontimage = json['Aadharnumberfrontimage'] != null
        ? json['Aadharnumberfrontimage'].toString()
        : "";
    aadharnumberbackimage = json['Aadharnumberbackimage'] != null
        ? json['Aadharnumberbackimage'].toString()
        : "";
    vehicleImage =
        json['vehicle_image'] != null ? json['vehicle_image'].toString() : "";
    vehicleImageBack = json['vehicle_image_back'] != null
        ? json['vehicle_image_back'].toString()
        : "";
    vehicleImageLeft = json['vehicle_image_left'] != null
        ? json['vehicle_image_left'].toString()
        : "";
    vehicleImageRight = json['vehicle_image_right'] != null
        ? json['vehicle_image_right'].toString()
        : "";
    manufactureDate = json['manufacture_date'] != null
        ? json['manufacture_date'].toString()
        : "";
    alternativemobilenumber = json['alternativemobilenumber'] != null
        ? json['alternativemobilenumber'].toString()
        : "";
    vehiclemodelnumber = json['vehiclemodelnumber'] != null
        ? json['vehiclemodelnumber'].toString()
        : "";
    isActive = json['is_active'];
    expiredAt = json['expired_at'];
    isReserved = json['is_reserved'];
    address = json['address'] != null
        ? new VehicleAddress.fromJson(json['address'])
        : null;
    myRequest = json['my_request'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user'] = this.user;
    data['vehical_name'] = this.vehicalName;
    data['company_name'] = this.companyName;
    data['emailId'] = this.emailId;
    data['ownername'] = this.ownername;
    data['vehicleregistrationnumber'] = this.vehicleregistrationnumber;
    data['Aadharnumberfrontimage'] = this.aadharnumberfrontimage;
    data['Aadharnumberbackimage'] = this.aadharnumberbackimage;
    data['vehicle_image'] = this.vehicleImage;
    data['vehicle_image_back'] = this.vehicleImageBack;
    data['vehicle_image_left'] = this.vehicleImageLeft;
    data['vehicle_image_right'] = this.vehicleImageRight;
    data['manufacture_date'] = this.manufactureDate;
    data['alternativemobilenumber'] = this.alternativemobilenumber;
    data['vehiclemodelnumber'] = this.vehiclemodelnumber;
    data['is_active'] = this.isActive;
    data['expired_at'] = this.expiredAt;
    data['is_reserved'] = this.isReserved;
    if (this.address != null) {
      data['address'] = this.address!.toJson();
    }
    data['my_request'] = this.myRequest;
    return data;
  }
}

class VehicleAddress {
  int? id;
  bool? isActive;
  Heavyvehivalregistration? heavyvehivalregistration;
  StateId? stateId;
  DistrictId? districtId;
  TahseelId? tahseelId;

  VehicleAddress(
      {this.id,
      this.isActive,
      this.heavyvehivalregistration,
      this.stateId,
      this.districtId,
      this.tahseelId});

  VehicleAddress.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    isActive = json['is_active'];
    heavyvehivalregistration = json['heavyvehivalregistration'] != null
        ? new Heavyvehivalregistration.fromJson(
            json['heavyvehivalregistration'])
        : null;
    stateId = json['state_id'] != null
        ? new StateId.fromJson(json['state_id'])
        : null;
    districtId = json['district_id'] != null
        ? new DistrictId.fromJson(json['district_id'])
        : null;
    tahseelId = json['tahseel_id'] != null
        ? new TahseelId.fromJson(json['tahseel_id'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['is_active'] = this.isActive;
    if (this.heavyvehivalregistration != null) {
      data['heavyvehivalregistration'] =
          this.heavyvehivalregistration!.toJson();
    }
    if (this.stateId != null) {
      data['state_id'] = this.stateId!.toJson();
    }
    if (this.districtId != null) {
      data['district_id'] = this.districtId!.toJson();
    }
    if (this.tahseelId != null) {
      data['tahseel_id'] = this.tahseelId!.toJson();
    }
    return data;
  }
}

class Heavyvehivalregistration {
  int? id;
  String? vehicalName;
  String? companyName;
  String? emailId;
  String? ownername;
  String? vehicleregistrationnumber;
  String? aadharnumberfrontimage;
  String? aadharnumberbackimage;
  String? vehicleImage;
  String? vehicleImageBack;
  String? vehicleImageLeft;
  String? vehicleImageRight;
  String? manufactureDate;
  String? alternativemobilenumber;
  String? vehiclemodelnumber;
  String? expiredAt;
  bool? isPaid;
  bool? isActive;
  String? createdAt;
  String? updatedAt;
  int? user;

  Heavyvehivalregistration(
      {this.id,
      this.vehicalName,
      this.companyName,
      this.emailId,
      this.ownername,
      this.vehicleregistrationnumber,
      this.aadharnumberfrontimage,
      this.aadharnumberbackimage,
      this.vehicleImage,
      this.vehicleImageBack,
      this.vehicleImageLeft,
      this.vehicleImageRight,
      this.manufactureDate,
      this.alternativemobilenumber,
      this.vehiclemodelnumber,
      this.expiredAt,
      this.isPaid,
      this.isActive,
      this.createdAt,
      this.updatedAt,
      this.user});

  Heavyvehivalregistration.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    vehicalName = json['vehical_name'];
    companyName = json['company_name'];
    emailId = json['emailId'];
    ownername = json['ownername'];
    vehicleregistrationnumber = json['vehicleregistrationnumber'];
    aadharnumberfrontimage = json['Aadharnumberfrontimage'];
    aadharnumberbackimage = json['Aadharnumberbackimage'];
    vehicleImage = json['vehicle_image'];
    vehicleImageBack = json['vehicle_image_back'];
    vehicleImageLeft = json['vehicle_image_left'];
    vehicleImageRight = json['vehicle_image_right'];
    manufactureDate = json['manufacture_date'];
    alternativemobilenumber = json['alternativemobilenumber'];
    vehiclemodelnumber = json['vehiclemodelnumber'];
    expiredAt = json['expired_at'];
    isPaid = json['is_paid'];
    isActive = json['is_active'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    user = json['user'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['vehical_name'] = this.vehicalName;
    data['company_name'] = this.companyName;
    data['emailId'] = this.emailId;
    data['ownername'] = this.ownername;
    data['vehicleregistrationnumber'] = this.vehicleregistrationnumber;
    data['Aadharnumberfrontimage'] = this.aadharnumberfrontimage;
    data['Aadharnumberbackimage'] = this.aadharnumberbackimage;
    data['vehicle_image'] = this.vehicleImage;
    data['vehicle_image_back'] = this.vehicleImageBack;
    data['vehicle_image_left'] = this.vehicleImageLeft;
    data['vehicle_image_right'] = this.vehicleImageRight;
    data['manufacture_date'] = this.manufactureDate;
    data['alternativemobilenumber'] = this.alternativemobilenumber;
    data['vehiclemodelnumber'] = this.vehiclemodelnumber;
    data['expired_at'] = this.expiredAt;
    data['is_paid'] = this.isPaid;
    data['is_active'] = this.isActive;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['user'] = this.user;
    return data;
  }
}

class StateId {
  int? id;
  String? stateName;

  StateId({this.id, this.stateName});

  StateId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    stateName = json['state_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['state_name'] = this.stateName;
    return data;
  }
}

class DistrictId {
  int? id;
  String? districtName;
  int? stateId;

  DistrictId({this.id, this.districtName, this.stateId});

  DistrictId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    districtName = json['district_name'];
    stateId = json['state_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['district_name'] = this.districtName;
    data['state_id'] = this.stateId;
    return data;
  }
}

class TahseelId {
  int? id;
  String? tahseelName;
  int? districtId;

  TahseelId({this.id, this.tahseelName, this.districtId});

  TahseelId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    tahseelName = json['tahseel_name'];
    districtId = json['district_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['tahseel_name'] = this.tahseelName;
    data['district_id'] = this.districtId;
    return data;
  }
}

class HomeDriverList {
  String? id;
  String? user;
  String? vehicalname;
  String? expriencesinyear;
  String? driveroperatorname;
  String? aadharnumberfrontimage;
  String? aadharnumberbackimage;
  String? alternetMobilenumber;
  String? heavyLicense;
  String? emailId;
  String? mobilenumber;
  String? licenseImage;
  String? driverImage;
  bool? isActive;
  bool? driverPaid;
  String? expiredAt;
  HomeAddress? address;
  bool? isReserved;
  bool? myRequest;

  HomeDriverList(
      {this.id,
      this.user,
      this.vehicalname,
      this.expriencesinyear,
      this.driveroperatorname,
      this.aadharnumberfrontimage,
      this.aadharnumberbackimage,
      this.alternetMobilenumber,
      this.heavyLicense,
      this.emailId,
      this.mobilenumber,
      this.licenseImage,
      this.driverImage,
      this.isActive,
      this.driverPaid,
      this.expiredAt,
      this.address,
      this.isReserved,
      this.myRequest});

  HomeDriverList.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString() : "";
    user = json['user'] != null ? json['user'].toString() : "";
    vehicalname =
        json['vehicalname'] != null ? json['vehicalname'].toString() : "";
    expriencesinyear = json['expriencesinyear'] != null
        ? json['expriencesinyear'].toString()
        : "";
    driveroperatorname = json['driveroperatorname'] != null
        ? json['driveroperatorname'].toString()
        : "";
    aadharnumberfrontimage = json['Aadharnumberfrontimage'] != null
        ? json['Aadharnumberfrontimage'].toString()
        : "";
    aadharnumberbackimage = json['Aadharnumberbackimage'] != null
        ? json['Aadharnumberbackimage'].toString()
        : "";
    alternetMobilenumber = json['alternet_mobilenumber'] != null
        ? json['alternet_mobilenumber'].toString()
        : "";
    heavyLicense =
        json['heavy_license'] != null ? json['heavy_license'].toString() : "";
    emailId = json['emailId'] != null ? json['emailId'].toString() : "";
    mobilenumber =
        json['mobilenumber'] != null ? json['mobilenumber'].toString() : "";
    licenseImage =
        json['license_image'] != null ? json['license_image'].toString() : "";
    driverImage =
        json['driver_image'] != null ? json['driver_image'].toString() : "";
    isActive = json['is_active'];
    driverPaid = json['driver_paid'];
    expiredAt = json['expired_at'];
    address = json['address'] != null
        ? new HomeAddress.fromJson(json['address'])
        : null;
    isReserved = json['is_reserved'];
    myRequest = json['my_request'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user'] = this.user;
    data['vehicalname'] = this.vehicalname;
    data['expriencesinyear'] = this.expriencesinyear;
    data['driveroperatorname'] = this.driveroperatorname;
    data['Aadharnumberfrontimage'] = this.aadharnumberfrontimage;
    data['Aadharnumberbackimage'] = this.aadharnumberbackimage;
    data['alternet_mobilenumber'] = this.alternetMobilenumber;
    data['heavy_license'] = this.heavyLicense;
    data['emailId'] = this.emailId;
    data['mobilenumber'] = this.mobilenumber;
    data['license_image'] = this.licenseImage;
    data['driver_image'] = this.driverImage;
    data['is_active'] = this.isActive;
    data['driver_paid'] = this.driverPaid;
    data['expired_at'] = this.expiredAt;
    if (this.address != null) {
      data['address'] = this.address!.toJson();
    }
    data['is_reserved'] = this.isReserved;
    data['my_request'] = this.myRequest;
    return data;
  }
}

class HomeAddress {
  int? id;
  bool? isActive;
  StateId? stateId;
  DistrictId? districtId;
  TahseelId? tahseelId;

  HomeAddress(
      {this.id, this.isActive, this.stateId, this.districtId, this.tahseelId});

  HomeAddress.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    isActive = json['is_active'];
    stateId = json['state_id'] != null
        ? new StateId.fromJson(json['state_id'])
        : null;
    districtId = json['district_id'] != null
        ? new DistrictId.fromJson(json['district_id'])
        : null;
    tahseelId = json['tahseel_id'] != null
        ? new TahseelId.fromJson(json['tahseel_id'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['is_active'] = this.isActive;
    if (this.stateId != null) {
      data['state_id'] = this.stateId!.toJson();
    }
    if (this.districtId != null) {
      data['district_id'] = this.districtId!.toJson();
    }
    if (this.tahseelId != null) {
      data['tahseel_id'] = this.tahseelId!.toJson();
    }
    return data;
  }
}

class LabourList {
  String? id;
  String? user;
  String? name;
  String? labourwork;
  String? emailId;
  String? lobourinnumber;
  String? mobileNumber;
  String? skilledlabour;
  String? unskilledlabour;
  String? professionallabour;
  String? aadharnumberfrontimage;
  String? aadharnumberbackimage;
  String? alternativemobilenumber;
  String? labourImage;
  bool? labourPaid;
  String? expiredAt;
  bool? isActive;
  HomeAddress? address;
  bool? isReserved;
  bool? myRequest;

  LabourList(
      {this.id,
      this.user,
      this.name,
      this.labourwork,
      this.emailId,
      this.lobourinnumber,
      this.mobileNumber,
      this.skilledlabour,
      this.unskilledlabour,
      this.professionallabour,
      this.aadharnumberfrontimage,
      this.aadharnumberbackimage,
      this.alternativemobilenumber,
      this.labourImage,
      this.labourPaid,
      this.expiredAt,
      this.isActive,
      this.address,
      this.isReserved,
      this.myRequest});

  LabourList.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString() : "";
    user = json['user'] != null ? json['user'].toString() : "";
    name = json['name'] != null ? json['name'].toString() : "";
    labourwork =
        json['labourwork'] != null ? json['labourwork'].toString() : "";
    emailId = json['emailId'] != null ? json['emailId'].toString() : "";
    lobourinnumber =
        json['lobourinnumber'] != null ? json['lobourinnumber'].toString() : "";
    mobileNumber =
        json['mobile_number'] != null ? json['mobile_number'].toString() : "";
    skilledlabour =
        json['skilledlabour'] != null ? json['skilledlabour'].toString() : "";
    unskilledlabour = json['unskilledlabour'] != null
        ? json['unskilledlabour'].toString()
        : "";
    professionallabour = json['professionallabour'] != null
        ? json['professionallabour'].toString()
        : "";
    aadharnumberfrontimage = json['Aadharnumberfrontimage'] != null
        ? json['Aadharnumberfrontimage'].toString()
        : "";
    aadharnumberbackimage = json['Aadharnumberbackimage'] != null
        ? json['Aadharnumberbackimage'].toString()
        : "";
    alternativemobilenumber = json['alternativemobilenumber'] != null
        ? json['alternativemobilenumber'].toString()
        : "";
    labourImage =
        json['labour_image'] != null ? json['labour_image'].toString() : "";
    labourPaid = json['labour_paid'] != null ? json['labour_paid'] : "";
    expiredAt = json['expired_at'] != null ? json['expired_at'] : "";
    isActive = json['is_active'] != null ? json['is_active'] : "";
    address = json['address'] != null
        ? new HomeAddress.fromJson(json['address'])
        : null;
    isReserved = json['is_reserved'];
    myRequest = json['my_request'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user'] = this.user;
    data['name'] = this.name;
    data['labourwork'] = this.labourwork;
    data['emailId'] = this.emailId;
    data['lobourinnumber'] = this.lobourinnumber;
    data['mobile_number'] = this.mobileNumber;
    data['skilledlabour'] = this.skilledlabour;
    data['unskilledlabour'] = this.unskilledlabour;
    data['professionallabour'] = this.professionallabour;
    data['Aadharnumberfrontimage'] = this.aadharnumberfrontimage;
    data['Aadharnumberbackimage'] = this.aadharnumberbackimage;
    data['alternativemobilenumber'] = this.alternativemobilenumber;
    data['labour_image'] = this.labourImage;
    data['labour_paid'] = this.labourPaid;
    data['expired_at'] = this.expiredAt;
    data['is_active'] = this.isActive;
    if (this.address != null) {
      data['address'] = this.address!.toJson();
    }
    data['is_reserved'] = this.isReserved;
    data['my_request'] = this.myRequest;
    return data;
  }
}

class SubcontructorList {
  String? id;
  String? contractorname;
  String? firmname;
  String? typeofwork;
  String? emailId;
  String? expriencesinyear;
  String? licenseNumber;
  String? aadharnumberfrontimage;
  String? aadharnumberbackimage;
  String? mobilenumber;
  String? subcontractorImage;
  String? subcontractorImageBack;
  String? subcontractorImageLeft;
  String? subcontractorImageRight;
  String? expiredAt;
  bool? isActive;
  HomeAddress? address;
  bool? isReserved;
  bool? myRequest;

  SubcontructorList(
      {this.id,
      this.contractorname,
      this.firmname,
      this.typeofwork,
      this.emailId,
      this.expriencesinyear,
      this.licenseNumber,
      this.aadharnumberfrontimage,
      this.aadharnumberbackimage,
      this.mobilenumber,
      this.subcontractorImage,
      this.subcontractorImageBack,
      this.subcontractorImageLeft,
      this.subcontractorImageRight,
      this.expiredAt,
      this.isActive,
      this.address,
      this.isReserved,
      this.myRequest});

  SubcontructorList.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString() : "";
    contractorname =
        json['contractorname'] != null ? json['contractorname'].toString() : "";
    firmname = json['firmname'] != null ? json['firmname'].toString() : "";
    typeofwork =
        json['typeofwork'] != null ? json['typeofwork'].toString() : "";
    emailId = json['emailId'] != null ? json['emailId'].toString() : "";
    expriencesinyear = json['expriencesinyear'] != null
        ? json['expriencesinyear'].toString()
        : "";
    licenseNumber =
        json['license_number'] != null ? json['license_number'].toString() : "";
    aadharnumberfrontimage = json['Aadharnumberfrontimage'] != null
        ? json['Aadharnumberfrontimage'].toString()
        : "";
    aadharnumberbackimage = json['Aadharnumberbackimage'] != null
        ? json['Aadharnumberbackimage'].toString()
        : "";
    mobilenumber =
        json['mobilenumber'] != null ? json['mobilenumber'].toString() : "";
    subcontractorImage = json['subcontractor_image'] != null
        ? json['subcontractor_image'].toString()
        : "";
    subcontractorImageBack = json['subcontractor_image_back'] != null
        ? json['subcontractor_image_back'].toString()
        : "";
    subcontractorImageLeft = json['subcontractor_image_left'] != null
        ? json['subcontractor_image_left'].toString()
        : "";
    subcontractorImageRight = json['subcontractor_image_right'] != null
        ? json['subcontractor_image_right'].toString()
        : "";
    expiredAt = json['expired_at'];
    isActive = json['is_active'];
    address = json['address'] != null
        ? new HomeAddress.fromJson(json['address'])
        : null;
    isReserved = json['is_reserved'];
    myRequest = json['my_request'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['contractorname'] = this.contractorname;
    data['firmname'] = this.firmname;
    data['typeofwork'] = this.typeofwork;
    data['emailId'] = this.emailId;
    data['expriencesinyear'] = this.expriencesinyear;
    data['license_number'] = this.licenseNumber;
    data['Aadharnumberfrontimage'] = this.aadharnumberfrontimage;
    data['Aadharnumberbackimage'] = this.aadharnumberbackimage;
    data['mobilenumber'] = this.mobilenumber;
    data['subcontractor_image'] = this.subcontractorImage;
    data['subcontractor_image_back'] = this.subcontractorImageBack;
    data['subcontractor_image_left'] = this.subcontractorImageLeft;
    data['subcontractor_image_right'] = this.subcontractorImageRight;
    data['expired_at'] = this.expiredAt;
    data['is_active'] = this.isActive;
    if (this.address != null) {
      data['address'] = this.address!.toJson();
    }
    data['is_reserved'] = this.isReserved;
    data['my_request'] = this.myRequest;
    return data;
  }
}
