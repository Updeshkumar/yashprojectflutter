class OtpVerifyModelData {
  bool? status;
  Data? data;

  OtpVerifyModelData({this.status, this.data});

  OtpVerifyModelData.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? message;
  String? otpMatched;
  bool? isType;
  String? userType;
  bool? isPaid;
  String? vehicleId;
  String? amount;
  String? accessToken;
  String? mobileNo;

  Data(
      {this.message,
      this.otpMatched,
      this.isType,
      this.userType,
      this.isPaid,
      this.vehicleId,
      this.amount,
      this.accessToken,
      this.mobileNo});

  Data.fromJson(Map<String, dynamic> json) {
    message =
        ![null, ""].contains(json['message']) ? json['message'].toString() : "";
    otpMatched = ![null, ""].contains(json['otp_matched'])
        ? json['otp_matched'].toString()
        : "";
    isType = ![null, ""].contains(json['is_type']) ? json['is_type'] : "";
    userType = ![null, ""].contains(json['userType'])
        ? json['userType'].toString()
        : "";
    isPaid = ![null, ""].contains(json['is_paid']) ? json['is_paid'] : "";
    vehicleId = ![null, ""].contains(json['vehicle_id'])
        ? json['vehicle_id'].toString()
        : "";
    amount =
        ![null, ""].contains(json['amount']) ? json['amount'].toString() : "";
    accessToken = ![null, ""].contains(json['accessToken'])
        ? json['accessToken'].toString()
        : "";
    mobileNo = ![null, ""].contains(json['mobileNo'])
        ? json['mobileNo'].toString()
        : "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['otp_matched'] = this.otpMatched;
    data['is_type'] = this.isType;
    data['userType'] = this.userType;
    data['is_paid'] = this.isPaid;
    data['vehicle_id'] = this.vehicleId;
    data['amount'] = this.amount;
    data['accessToken'] = this.accessToken;
    data['mobileNo'] = this.mobileNo;
    return data;
  }
}
