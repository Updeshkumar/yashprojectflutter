class MakePaymnetDataModel {
  bool? status;
  MakePaymnetData? data;

  MakePaymnetDataModel({this.status, this.data});

  MakePaymnetDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null
        ? new MakePaymnetData.fromJson(json['data'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class MakePaymnetData {
  String? message;
  MakePaymentDetails? details;

  MakePaymnetData({this.message, this.details});

  MakePaymnetData.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    details = json['details'] != null
        ? new MakePaymentDetails.fromJson(json['details'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    if (this.details != null) {
      data['details'] = this.details!.toJson();
    }
    return data;
  }
}

class MakePaymentDetails {
  String? razorpayOrderId;
  String? razorpayMerchantKey;
  String? razorpayAmount;
  String? currency;

  MakePaymentDetails(
      {this.razorpayOrderId,
      this.razorpayMerchantKey,
      this.razorpayAmount,
      this.currency});

  MakePaymentDetails.fromJson(Map<String, dynamic> json) {
    razorpayOrderId = json['razorpay_order_id'];
    razorpayMerchantKey = json['razorpay_merchant_key'];
    razorpayAmount = json['razorpay_amount'];
    currency = json['currency'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['razorpay_order_id'] = this.razorpayOrderId;
    data['razorpay_merchant_key'] = this.razorpayMerchantKey;
    data['razorpay_amount'] = this.razorpayAmount;
    data['currency'] = this.currency;
    return data;
  }
}
