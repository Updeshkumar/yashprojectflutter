import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/data/respnse/base/response.dart';
import 'package:asiayai_heavy_vehicle_app/helper/local_storage.dart';
import 'package:asiayai_heavy_vehicle_app/utils/app_constants.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DioClient {
  final String baseUrl;
  final SharedPreferences sharedPreferences;
  Dio? dio;
  String? token;

  DioClient({required this.baseUrl, required this.sharedPreferences}) {
    dio = Dio();

    // dio!
    //   ..options.baseUrl = baseUrl
    //   ..options.connectTimeout = 30000
    //   ..options.receiveTimeout = 30000
    //   ..httpClientAdapter
    //   ..options.headers = {
    //     'Content-Type': 'application/json',
    //     'Accept': '*/*',
    //     'Authorization': LocalStorage.getSaveToken('saveToken'),
    //   };
  }

  Future<ResponceModel> post(
      {required String url, required Map<String, dynamic> data}) async {
    try {
      final SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      token = sharedPreferences.getString(AppConstants.USER_TOKEN);
      var response = await dio!.post(url,
          data: data,
          options: Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: token,
            HttpHeaders.acceptHeader: '*/*',
          }));

      if (response.statusCode == 200 && response.data != null) {
        ResponceModel responceModel = ResponceModel.fromJson(response.data);
        return responceModel;
      }
    } on DioError catch (e) {
      print(e);
      return ResponceModel.fromJson(e.response!.data);
    } catch (error) {
      return ResponceModel(
          data: {},
          message: "Dio.post Error: " + error.toString(),
          status: "400");
    }
    return ResponceModel(data: {}, message: "Error:: Dio.Post", status: "400");
  }

  // get methods

  Future<ResponceModel> get({required String url}) async {
    try {
      final SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      token = sharedPreferences.getString('saveToken');
      var response = await dio!.get(url,
          options: Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: token,
            HttpHeaders.acceptHeader: '*/*',
          }));
      if (response.statusCode == 200 && response.data != null) {
        ResponceModel responceModel = ResponceModel.fromJson(response.data);
        return responceModel;
      }
    } on DioError catch (e) {
      print(e);
      return ResponceModel.fromJson(e.response!.data);
    } catch (error) {
      return ResponceModel(
          data: {},
          message: "Dio.post Error: " + error.toString(),
          status: "400");
    }
    return ResponceModel(data: {}, message: "Error:: Dio.Post", status: "400");
  }

  //  for upload image
}
