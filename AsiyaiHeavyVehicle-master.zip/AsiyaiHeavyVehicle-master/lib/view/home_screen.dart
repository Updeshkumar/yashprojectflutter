// import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Dashboard/body.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_zoom_drawer/flutter_zoom_drawer.dart';

// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});

//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }

// class _HomeScreenState extends State<HomeScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return ZoomDrawer(
//       mainScreen: DashBoardScreen(),
//       menuScreen: Drawe(),
//     );
//   }
// }
