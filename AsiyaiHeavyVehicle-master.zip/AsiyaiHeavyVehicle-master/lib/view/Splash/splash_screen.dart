import 'dart:async';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:asiayai_heavy_vehicle_app/utils/app_constants.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/bottoms_nav_bar.dart';
import 'package:asiayai_heavy_vehicle_app/view/Onboard/onboard_page.dart';
import 'package:asiayai_heavy_vehicle_app/view/Payment/pay_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/SigunUp/signup_page.dart';
import 'package:asiayai_heavy_vehicle_app/view/check_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/language/languages.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../screen_validation.dart';
import '../../utils/text_styles.dart';

String? userToken;
String? userType;
String? is_paid;
String? phone;

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  //states
  void initState() {
    // TODO: implement initState

    super.initState();
    getValidationData();
    Timer(const Duration(seconds: 3), () => checkNavigation()); //
  }

  checkNavigation() {
    if (![null, ""].contains(phone)) {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => SignUp()));
    } else {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => ChooseLanguage()));
      return;
    }

    if (![null, ""].contains(userToken)) {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => BottomAppBar()));
    } else {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => SignUp()));
      return;
    }

    if (![null, ""].contains(userType)) {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => PayPaymentScreen()));
    } else {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => CheckScreen()));
      return;
    }

    if (![null, ""].contains(is_paid)) {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => BottomNavBar(0)));
    } else {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => PayPaymentScreen()));
      return;
    }

    setState(() {});
  }

  //method
  Future getValidationData() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    userToken = sharedPreferences.getString(AppConstants.USER_TOKEN);
    userType = sharedPreferences.getString(AppConstants.USER_TYPE);
    is_paid = sharedPreferences.getString(AppConstants.IS_PAID);
    phone = sharedPreferences.getString(AppConstants.USER_PHONE);
    String? name = sharedPreferences.getString(AppConstants.USER_NAME);

    print(userToken);
    print("user phone >>>>" + phone.toString());
    print("user name >>>>" + name.toString());
    print("user type >>>>" + userType.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Image(
                    image: AssetImage(Images.splash_logo),
                  ),
                  RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: " ASIYAI",
                          style: TextStyles.ktext40pop(context),
                        ),
                        TextSpan(
                          text: "HEAVY ",
                          style: TextStyles.ktext40pop(context)
                              .copyWith(color: Colors.white),
                        ),
                        TextSpan(
                          text: "VEHICLE",
                          style: TextStyles.ktext40pop(context),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              "2022 Asiyai Heavy Vehicle. All Rights Reserved",
              style: TextStyles.ktext12(context),
            ),
          )
        ],
      ),
    );
  }
}
