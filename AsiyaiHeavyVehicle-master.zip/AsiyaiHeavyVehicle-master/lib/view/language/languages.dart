import 'package:asiayai_heavy_vehicle_app/view/Onboard/onboard_page.dart';
import 'package:asiayai_heavy_vehicle_app/view/SigunUp/signup_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../utils/app_constants.dart';
import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/app_snack_bar.dart';
import '../../widgets/customs_button.dart';

String? userphone;

class ChooseLanguage extends StatefulWidget {
  const ChooseLanguage({super.key});

  @override
  State<ChooseLanguage> createState() => _ChooseLanguageState();
}

class _ChooseLanguageState extends State<ChooseLanguage> {
  //

  @override
  void initState() {
    // TODO: implement initState

    super.initState();
  }

  static const values = <String>[
    "हिन्दी",
    "English",
    "मराठी (Marathi)",
    "भोजपुरी (Bhojpuri)",
    "ನೆರಳಿನಲ್ಲೇ (Kannad)",
  ];

  //variables
  String? screenNumber;
  String? selectedValue;
  final selectedColor = Colours.YELLOW_DARK;
  final unselectedColor = Colours.PRIMARY_BLUE_MILD;

  //methods
  changeScreen(String index) {
    switch (index) {
      case "हिन्दी":
        Fluttertoast.showToast(msg: "You Select Hindi Language");
        context.locale = Locale('hi', 'HI');
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const OnBoardPage(),
              // finalEmail == null ? OnBoardPage() : LogINPage()
            ));

        break;
      case "English":
        Fluttertoast.showToast(msg: "You Select English Language");
        context.locale = Locale('en', 'US');
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  // finalEmail == null ? OnBoardPage() : LogINPage()
                  const OnBoardPage(),
            ));
        break;
      case "मराठी (Marathi)":
        Fluttertoast.showToast(msg: "You Select Marathi Language");
        context.locale = Locale('mr', 'MR');
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  // finalEmail == null ? OnBoardPage() : LogINPage(),
                  const OnBoardPage(),
            ));
        break;

      case "भोजपुरी (Bhojpuri)":
        Fluttertoast.showToast(msg: "You Select Bhojpuri Language");
        context.locale = Locale('hi', 'IN');
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  // finalEmail == null ? OnBoardPage() : LogINPage()
                  const OnBoardPage(),
            ));
        break;

      case "ನೆರಳಿನಲ್ಲೇ (Kannad)":
        Fluttertoast.showToast(msg: "You Select Kannad Language");
        context.locale = Locale('kn', 'KN');
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  // finalEmail == null ? OnBoardPage() : LogINPage()
                  const OnBoardPage(),
            ));
        break;

      default:
    }
  }

  // methods
  Widget buildRadios() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18),
        child: Column(
          children: values.map((value) {
            final selected = this.selectedValue == value;
            final boxColor = selected ? selectedColor : unselectedColor;
            final textColor =
                selected ? Colours.PRIMARY_BLACK : Colours.PRIMARY_GREY_LIGHT;
            return Container(
              margin: const EdgeInsets.symmetric(vertical: 5),
              child: Theme(
                data: ThemeData(
                    radioTheme: RadioThemeData(
                        fillColor: MaterialStateColor.resolveWith((states) =>
                            selected
                                ? Colours.PRIMARY_BLACK
                                : Colours.PRIMARY_GREY_LIGHT))),
                child: RadioListTile<String>(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(100),
                  ),
                  value: value,
                  groupValue: selectedValue,
                  tileColor: boxColor,
                  title: Text(
                    value,
                    style:
                        TextStyles.ktext18(context).copyWith(color: textColor),
                  ),
                  onChanged: (value) {
                    setState(() {
                      this.selectedValue = value!;
                      screenNumber = selectedValue;
                      print(screenNumber);
                    });
                  },
                ),
              ),
            );
          }).toList(),
        ),
      );
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(50),
        child: AppBar(
          centerTitle: true,
          title: Text(
            "Choose Language",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
          automaticallyImplyLeading: false,
        ),
      ),
      body: Container(
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: size.height / 40,
            ),
            Expanded(child: buildRadios()),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        color: Colours.PRIMARY_BLUE_MILD,
        padding: EdgeInsets.symmetric(
            horizontal: size.width / 24, vertical: size.height / 80),
        height: 60,
        child: CustomButton(
          text: "CONTINUE",
          textColor: Colours.PRIMARY_BLACK,
          onTap: () {
            if (screenNumber != null) {
              changeScreen(screenNumber!);
            } else {
              AppSnackBar.appSnackBar(
                context: context,
                message: "Please Select any Language",
                title: "Select Language",
                isError: true,
              );
            }
          },
        ),
      ),
    );
  }
}
