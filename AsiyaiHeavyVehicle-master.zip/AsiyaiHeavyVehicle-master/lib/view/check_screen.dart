import 'dart:async';

import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/bottoms_nav_bar.dart';
import 'package:asiayai_heavy_vehicle_app/view/Profiles/choose_profile.dart';
import 'package:asiayai_heavy_vehicle_app/view/demo_screen/demo.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/app_constants.dart';

String? username;

class CheckScreen extends StatefulWidget {
  @override
  State<CheckScreen> createState() => _CheckScreenState();
}

class _CheckScreenState extends State<CheckScreen> {
  void initState() {
    // TODO: implement initState

    super.initState();
    getValidationData();
  }

  //method
  Future getValidationData() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    username = sharedPreferences.getString(AppConstants.USER_NAME);
    if (!["", null].contains(username)) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => BottomNavBar(0)));
    }
    if (username != null) print("username >>>> " + username!);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      body: Container(
        width: size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Material(
              elevation: 5,
              borderRadius: BorderRadius.circular(8),
              shadowColor: Colours.YELLOW_LIGHT,
              color: Colours.YELLOW_DARK,
              child: MaterialButton(
                onPressed: () {
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => DemoScreen()));
                },
                child: Text(
                  "GO FOR DEMO",
                  style: TextStyles.ktext20(context),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Material(
              elevation: 5,
              borderRadius: BorderRadius.circular(8),
              shadowColor: Colours.YELLOW_LIGHT,
              color: Colours.YELLOW_DARK,
              child: MaterialButton(
                onPressed: () {
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => ChooseProfile()));
                },
                child: Text(
                  " REGISTRATION",
                  style: TextStyles.ktext20(context),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
