import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/view/Driver/DriverDetails/driver_details.dart';
import 'package:asiayai_heavy_vehicle_app/view/Driver/DriverDetails/more_driver.dart';
import 'package:asiayai_heavy_vehicle_app/view/Driver/driver_product.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/blank_dta.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '../../data/respnse/driver_details_model.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/product_shimmer.dart';

class DriverBody extends StatefulWidget {
  const DriverBody({super.key});

  @override
  State<DriverBody> createState() => _DriverBodyState();
}

class _DriverBodyState extends State<DriverBody> {
  // state
  @override
  void initState() {
    // TODO: implement initState
    // Provider.of<UserProvider>(context, listen: false).getDriverData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Driver/Operator",
                style: TextStyles.ktext18(context),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      PageTransition(
                          child: MoreDrivers(),
                          type: PageTransitionType.bottomToTop));
                },
                child: Text(
                  "View All",
                  style: TextStyles.ktext16(context)
                      .copyWith(color: Colours.PRIMARY_GREY_MILD),
                ),
              ),
            ],
          ),
          Container(
            height: size.height / 7,
            margin: EdgeInsets.only(top: 8),
            child: Consumer<UserProvider>(
              builder: (context, model, child) {
                return model.myHomeData != null &&
                        model.myHomeData!.data != null &&
                        model.myHomeData!.data!.driverList != null &&
                        model.myHomeData!.data!.driverList!.length > 0
                    ? ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: model.myHomeData!.data!.driverList!.length,
                        itemBuilder: ((context, index) {
                          HomeDriverList obj =
                              model.myHomeData!.data!.driverList![index];
                          return DriverProduct(
                            obj: obj,
                          );
                        }))
                    : BlankData();
              },
            ),
          )
        ],
      ),
    );
  }
}
