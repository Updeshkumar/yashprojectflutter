import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/driver_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/utils/fade_image.dart';
import 'package:asiayai_heavy_vehicle_app/view/Driver/DriverDetails/driver_details.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

import '../../utils/colour_resource.dart';
import '../../utils/images.dart';

class DriverProduct extends StatelessWidget {
  HomeDriverList? obj;
  DriverProduct({this.obj});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return InkWell(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                child: DriverDetailsPage(
                  obj: obj,
                ),
                type: PageTransitionType.leftToRight));
      },
      child: Container(
        height: size.height / 8,
        width: size.width / 3.6,
        margin: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: Colours.PRIMARY_GREY_LIGHT.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: FadeImageWithError(
              placeImage: Images.person_icon,
              imgPath: obj!.driverImage != null
                  ? "http://asiyaiheavyvehicle.com" +
                      obj!.driverImage.toString()
                  : Images.person_icon,
              fit: BoxFit.fill,
            )),
      ),
    );
  }
}
