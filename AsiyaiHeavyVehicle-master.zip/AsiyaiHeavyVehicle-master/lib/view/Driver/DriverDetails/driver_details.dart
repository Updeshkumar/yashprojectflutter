import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/driver_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/view/Driver/DriverDetails/driver_request.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../utils/fade_image.dart';
import '../../../utils/images.dart';
import '../../../utils/text_styles.dart';
import '../../../widgets/important_text.dart';
import '../../../widgets/row_text.dart';

class DriverDetailsPage extends StatefulWidget {
  HomeDriverList? obj;
  DriverDetailsPage({this.obj});

  @override
  State<DriverDetailsPage> createState() => _DriverDetailsPageState();
}

class _DriverDetailsPageState extends State<DriverDetailsPage> {
  getData() {
    if (myProvider!.userType != null &&
        myProvider!.userType!.toLowerCase().contains("driver")) {
      myProvider!.getDriverData();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 100), () => getData());
  }

  UserProvider? myProvider;

  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context, listen: false);
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(size.height / 16),
          child: AppBar(
            elevation: 0.0,
            title: Text(
              "Driver Details",
              style: TextStyles.ktext20(context),
            ),
            backgroundColor: Colours.PRIMARY_GREY,
          ),
        ),
        body: Container(
          padding:
              EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Hero(
                tag: 'image',
                child: Container(
                  height: size.height / 3,
                  width: double.infinity,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: FadeImageWithError(
                        placeImage: Images.person_icon,
                        imgPath: widget.obj!.driverImage != null
                            ? "http://asiyaiheavyvehicle.com" +
                                widget.obj!.driverImage.toString()
                            : Images.person_icon,
                        fit: BoxFit.fill,
                      )),
                ),
              ),
              ImportantText(name: widget.obj!.driveroperatorname.toString()),
              // if (![null, ""].contains(widget.obj!.country) &&
              //     ![null, ""].contains(widget.obj!.distict))
              widget.obj!.address!.districtId != null &&
                      widget.obj!.address!.stateId != null
                  ? Text(
                      widget.obj!.address!.districtId!.districtName! +
                          " , " +
                          widget.obj!.address!.stateId!.stateName! +
                          "  ",
                      style: TextStyles.ktext14(context).copyWith(
                        color: Colours.PRIMARY_GREY_LIGHT,
                      ),
                    )
                  : Container(),
              SizedBox(
                height: size.height / 40,
              ),
              Container(
                padding: EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  border:
                      Border.all(color: Colours.PRIMARY_BLUE_MILD, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Container(
                      height: 50,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      margin: const EdgeInsets.only(bottom: 20),
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(12),
                          topRight: Radius.circular(12),
                        ),
                        color: Colours.PRIMARY_GREY,
                      ),
                      child: Row(
                        children: [
                          Text(
                            "Details ",
                            style: TextStyles.ktext18(context),
                          ),
                        ],
                      ),
                    ),
                    Rowtext(
                        title1: "Vehicle Name",
                        title2: widget.obj!.vehicalname.toString()),
                    Rowtext(
                        title1: "Experience ",
                        title2: widget.obj!.expriencesinyear.toString()),
                    Rowtext(
                      title1: "Heavy License",
                      title2: "Yes",
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: myProvider!.drivers_data != null &&
                myProvider!.drivers_data!.id == widget.obj!.id
            ? InkWell(
                onTap: () {
                  showTostMsg("This is Added By You !!");
                },
                child: Container(
                  height: 45,
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 15),
                  decoration: BoxDecoration(
                    color: Colours.GREEN_LIGHT,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: Text(
                      "Your Details",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black),
                    ),
                  ),
                ),
              )
            : DriverREquestButton(
                obj: widget.obj,
              ));
  }
}
