import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/driver_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '../../../utils/fade_image.dart';
import '../../../utils/images.dart';
import '../../../utils/text_styles.dart';
import 'driver_details.dart';

class MoreDrivers extends StatefulWidget {
  const MoreDrivers({super.key});

  @override
  State<MoreDrivers> createState() => _MoreDriversState();
}

class _MoreDriversState extends State<MoreDrivers> {
  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(Duration(milliseconds: 200), () => getData());
    super.initState();
  }

  getData() async {
    await Provider.of<UserProvider>(context, listen: false).getDriverData();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: AppBar(
          backgroundColor: Colours.PRIMARY_BLUE_MILD,
          title: Text("Drivers"),
        ),
        //appBar: buildBar(context, model),
        body: Padding(
            padding:
                EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
            child: Consumer<UserProvider>(
              builder: (context, model, child) {
                return model.myHomeData != null &&
                        model.myHomeData!.data != null &&
                        model.myHomeData!.data!.driverList != null &&
                        model.myHomeData!.data!.driverList!.length > 0
                    ? ListView.builder(
                        itemCount: model.myHomeData!.data!.driverList!.length,
                        itemBuilder: (context, index) {
                          HomeDriverList obj =
                              model.myHomeData!.data!.driverList![index];
                          return MoreDriverProduct(
                            obj: obj,
                          );
                        })
                    : Center(
                        child: CircularProgressIndicator(
                        color: Colours.YELLOW_DARK,
                      ));
              },
            )),
      );
    });
  }

  void _handleSearchStart() {
    setState(() {
      _IsSearching = true;
    });
  }

  serachClose() {
    setState(() {
      _IsSearching = false;
      _searchQuery.clear();
    });
  }

  void _handleSearchEnd(UserProvider model) {
    setState(() {
      this.actionIcon = new Icon(
        Icons.search,
        color: Colors.white,
      );
      this.appBarTitle = new Text(
        "Drivers",
        style: new TextStyle(color: Colors.white),
      );

      _IsSearching = false;
      _searchQuery.clear();
    });
  }

  String? hintText = "Search ...";
  buildBar(BuildContext context, UserProvider model) {
    return new AppBar(
        //centerTitle: true,
        backgroundColor: Colours.PRIMARY_BLUE,
        title: appBarTitle,
        actions: <Widget>[
          new IconButton(
            icon: actionIcon,
            onPressed: () {
              setState(() {
                if (this.actionIcon.icon == Icons.search) {
                  this.actionIcon = new Icon(
                    Icons.close,
                    color: Colors.white,
                  );
                  this.appBarTitle = new TextField(
                    controller: _searchQuery,
                    style: new TextStyle(
                      color: Colors.white,
                    ),
                    decoration: new InputDecoration(
                        prefixIcon: new Icon(Icons.search, color: Colors.white),
                        hintText: hintText,
                        hintStyle: new TextStyle(color: Colors.white)),
                    onChanged: (str) {},
                  );
                  _handleSearchStart();
                } else {
                  _handleSearchEnd(model);
                }
              });
            },
          ),
        ]);
  }

  Widget appBarTitle = new Text(
    "Drivers",
    style: new TextStyle(color: Colors.white),
  );
  Icon actionIcon = new Icon(
    Icons.search,
    color: Colors.white,
  );
  final key = new GlobalKey<ScaffoldState>();
  final TextEditingController _searchQuery = new TextEditingController();
  bool? _IsSearching = false;
  String _searchText = "";
}

class MoreDriverProduct extends StatelessWidget {
  HomeDriverList? obj;
  MoreDriverProduct({this.obj});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return InkWell(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                child: DriverDetailsPage(
                  obj: obj,
                ),
                type: PageTransitionType.rightToLeft));
      },
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Container(
                  height: size.height / 8,
                  width: size.width / 4,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: FadeImageWithError(
                        placeImage: Images.person_icon,
                        imgPath: obj!.driverImage != null
                            ? "http://asiyaiheavyvehicle.com" +
                                obj!.driverImage.toString()
                            : Images.person_icon,
                        fit: BoxFit.fill,
                      )),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          obj!.driveroperatorname.toString().toUpperCase(),
                          style: TextStyles.ktext16(context)
                              .copyWith(fontWeight: FontWeight.bold),
                        ),
                        // if (![null, ""].contains(obj!.country) &&
                        //     ![null, ""].contains(obj!.distict))
                        obj!.address!.districtId != null &&
                                obj!.address!.stateId != null
                            ? Text(
                                obj!.address!.districtId!.districtName! +
                                    " , " +
                                    obj!.address!.stateId!.stateName! +
                                    "  ",
                                style: TextStyles.ktext14(context).copyWith(
                                  color: Colours.PRIMARY_GREY_LIGHT,
                                  fontWeight: FontWeight.w400,
                                ),
                                maxLines: 2,
                              )
                            : Container(),
                        SizedBox(
                          height: size.height / 80,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Experience : ",
                              style: TextStyles.ktext16(context)
                                  .copyWith(fontWeight: FontWeight.w400),
                            ),
                            Expanded(
                              child: Text(
                                "${obj!.expriencesinyear.toString()}",
                                style: TextStyles.ktext16(context),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: Colours.PRIMARY_GREY,
          ),
        ],
      ),
    );
  }
}
