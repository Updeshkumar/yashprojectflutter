import 'package:asiayai_heavy_vehicle_app/data/datamodel/driver_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/driver_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/show_dialog.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';

import '../../../utils/common.dart';

class DriverREquestButton extends StatefulWidget {
  HomeDriverList? obj;
  DriverREquestButton({this.obj});

  @override
  State<DriverREquestButton> createState() => _DriverREquestButtonState();
}

class _DriverREquestButtonState extends State<DriverREquestButton> {
  Size? size;
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;

    return Consumer<UserProvider>(builder: (context, model, child) {
      return buildRquestButton(model);
    });
  }

  buildRquestButton(UserProvider model) {
    return widget.obj!.isReserved == true
        ? GestureDetector(
            onTap: () async {
              showTostMsg("Already Reserved!!");
            },
            child: Container(
              height: size!.height / 18,
              margin: EdgeInsets.symmetric(
                  horizontal: size!.width / 30, vertical: 20),
              decoration: BoxDecoration(
                color: Colours.GREEN_LIGHT,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  "Already Reserved",
                  style:
                      TextStyles.ktext18(context).copyWith(color: Colors.white),
                ),
              ),
            ),
          )
        : widget.obj!.myRequest == false
            ? GestureDetector(
                onTap: () async {
                  model.postDriverRequest(context,
                      Id: widget.obj!.id.toString());
                },
                child: Container(
                  height: size!.height / 18,
                  margin: EdgeInsets.symmetric(
                      horizontal: size!.width / 30, vertical: 20),
                  decoration: BoxDecoration(
                    color: Colours.YELLOW_LIGHT,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      " REQUEST",
                      style: TextStyles.ktext18(context)
                          .copyWith(color: Colours.PRIMARY_BLACK),
                    ),
                  ),
                ),
              )
            : GestureDetector(
                onTap: () async {
                  showTostMsg("Already Requested!!");
                },
                child: Container(
                  height: size!.height / 18,
                  margin: EdgeInsets.symmetric(
                      horizontal: size!.width / 30, vertical: 20),
                  decoration: BoxDecoration(
                    color: Colours.SKY_BLUE_LIGHT,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      "Already Request!!",
                      style: TextStyles.ktext18(context)
                          .copyWith(color: Colours.PRIMARY_BLACK),
                    ),
                  ),
                ),
              );
  }
}
