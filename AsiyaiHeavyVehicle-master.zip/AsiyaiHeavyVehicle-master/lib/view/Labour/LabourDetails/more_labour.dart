import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/labour_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '../../../utils/fade_image.dart';
import '../../../utils/images.dart';
import '../../../utils/text_styles.dart';
import 'labour_details.dart';

class MoreLabour extends StatefulWidget {
  const MoreLabour({super.key});

  @override
  State<MoreLabour> createState() => _MoreLabourState();
}

class _MoreLabourState extends State<MoreLabour> {
  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(Duration(milliseconds: 200), () => getData);
    super.initState();
  }

  getData() async {
    await Provider.of<UserProvider>(context, listen: false).getLabourData();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(size.height / 16),
          child: AppBar(
            backgroundColor: Colours.PRIMARY_BLUE_MILD,
            title: Text("Labour Contructors"),
          ),
          // child: buildBar(context, model),
        ),
        body: Padding(
          padding:
              EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
          child: Consumer<UserProvider>(
            builder: (context, model, child) {
              return model.myHomeData != null &&
                      model.myHomeData!.data != null &&
                      model.myHomeData!.data!.labourList != null &&
                      model.myHomeData!.data!.labourList!.length > 0
                  ? ListView.builder(
                      shrinkWrap: true,
                      itemCount: model.myHomeData!.data!.labourList!.length,
                      itemBuilder: ((context, index) {
                        LabourList obj =
                            model.myHomeData!.data!.labourList![index];
                        return MoreLabourProduct(
                          obj: obj,
                        );
                      }))
                  : Center(
                      child: CircularProgressIndicator(
                        color: Colours.YELLOW_DARK,
                      ),
                    );
            },
          ),
        ),
      );
    });
  }

  void _handleSearchStart() {
    setState(() {
      _IsSearching = true;
    });
  }

  serachClose() {
    setState(() {
      _IsSearching = false;
      _searchQuery.clear();
    });
  }

  void _handleSearchEnd(UserProvider model) {
    setState(() {
      this.actionIcon = new Icon(
        Icons.search,
        color: Colors.white,
      );
      this.appBarTitle = new Text(
        "Labours",
        style: new TextStyle(color: Colors.white),
      );

      _IsSearching = false;
      _searchQuery.clear();
    });
  }

  String? hintText = "Search ...";
  buildBar(BuildContext context, UserProvider model) {
    return new AppBar(
        //centerTitle: true,
        backgroundColor: Colours.PRIMARY_BLUE,
        title: appBarTitle,
        actions: <Widget>[
          new IconButton(
            icon: actionIcon,
            onPressed: () {
              setState(() {
                if (this.actionIcon.icon == Icons.search) {
                  this.actionIcon = new Icon(
                    Icons.close,
                    color: Colors.white,
                  );
                  this.appBarTitle = new TextField(
                    controller: _searchQuery,
                    style: new TextStyle(
                      color: Colors.white,
                    ),
                    decoration: new InputDecoration(
                        prefixIcon: new Icon(Icons.search, color: Colors.white),
                        hintText: hintText,
                        hintStyle: new TextStyle(color: Colors.white)),
                    onChanged: (str) {},
                  );
                  _handleSearchStart();
                } else {
                  _handleSearchEnd(model);
                }
              });
            },
          ),
        ]);
  }

  Widget appBarTitle = new Text(
    "Labours",
    style: new TextStyle(color: Colors.white),
  );
  Icon actionIcon = new Icon(
    Icons.search,
    color: Colors.white,
  );
  final key = new GlobalKey<ScaffoldState>();
  final TextEditingController _searchQuery = new TextEditingController();
  bool? _IsSearching = false;
  String _searchText = "";
}

class MoreLabourProduct extends StatefulWidget {
  LabourList? obj;
  MoreLabourProduct({this.obj});

  @override
  State<MoreLabourProduct> createState() => _MoreLabourProductState();
}

class _MoreLabourProductState extends State<MoreLabourProduct> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                child: LabourDetaislPage(
                  obj: widget.obj,
                ),
                type: PageTransitionType.rightToLeft));
      },
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Container(
                  height: size.height / 8,
                  width: size.width / 4,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: FadeImageWithError(
                        placeImage: Images.person_icon,
                        imgPath: widget.obj!.labourImage != null
                            ? "http://asiyaiheavyvehicle.com" +
                                widget.obj!.labourImage.toString()
                            : Images.person_icon,
                        fit: BoxFit.fill,
                      )),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.obj!.name.toString().toUpperCase(),
                          style: TextStyles.ktext16(context)
                              .copyWith(fontWeight: FontWeight.bold),
                        ),
                        // if (![null, ""].contains(widget.obj!.country) &&
                        //     ![null, ""].contains(widget.obj!.distict))
                        widget.obj!.address!.districtId != null &&
                                widget.obj!.address!.stateId != null
                            ? Text(
                                widget.obj!.address!.tahseelId!.tahseelName! +
                                    " , " +
                                    widget.obj!.address!.districtId!
                                        .districtName! +
                                    " , " +
                                    widget.obj!.address!.stateId!.stateName! +
                                    "  ",
                                style: TextStyles.ktext14(context).copyWith(
                                  color: Colours.PRIMARY_GREY_LIGHT,
                                  fontWeight: FontWeight.w400,
                                ),
                                maxLines: 2,
                              )
                            : Container(),
                        SizedBox(
                          height: size.height / 80,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Labour Work : ",
                              style: TextStyles.ktext16(context)
                                  .copyWith(fontWeight: FontWeight.w400),
                            ),
                            Expanded(
                              child: Text(
                                "${widget.obj!.labourwork.toString()}",
                                style: TextStyles.ktext16(context),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: Colours.PRIMARY_GREY,
          ),
        ],
      ),
    );
  }
}
