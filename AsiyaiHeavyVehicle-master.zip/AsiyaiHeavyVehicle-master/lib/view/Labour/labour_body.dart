import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/labour_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/view/Labour/LabourDetails/more_labour.dart';
import 'package:asiayai_heavy_vehicle_app/view/Labour/labour_product.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/blank_dta.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/product_shimmer.dart';

class LAbourBody extends StatefulWidget {
  const LAbourBody({super.key});

  @override
  State<LAbourBody> createState() => _LAbourBodyState();
}

class _LAbourBodyState extends State<LAbourBody> {
  // states
  @override
  void initState() {
    // TODO: implement initState
    //   Provider.of<UserProvider>(context, listen: false).getLabourData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Labour Contractor",
                style: TextStyles.ktext18(context),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      PageTransition(
                          child: MoreLabour(),
                          type: PageTransitionType.bottomToTop));
                },
                child: Text(
                  "View All",
                  style: TextStyles.ktext16(context)
                      .copyWith(color: Colours.PRIMARY_GREY_MILD),
                ),
              ),
            ],
          ),
          Container(
            height: size.height / 7,
            margin: EdgeInsets.only(top: 8),
            child: Consumer<UserProvider>(
              builder: (context, model, child) {
                return model.myHomeData != null &&
                        model.myHomeData!.data != null &&
                        model.myHomeData!.data!.labourList != null &&
                        model.myHomeData!.data!.labourList!.length > 0
                    ? ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: model.myHomeData!.data!.labourList!.length,
                        itemBuilder: (context, index) {
                          LabourList obj =
                              model.myHomeData!.data!.labourList![index];
                          return LabourProduct(
                            obj: obj,
                          );
                        })
                    : BlankData();
              },
            ),
          )
        ],
      ),
    );
  }
}
