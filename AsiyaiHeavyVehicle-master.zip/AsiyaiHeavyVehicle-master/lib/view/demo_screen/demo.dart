import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Dashboard/widgets/banner.dart';
import 'package:asiayai_heavy_vehicle_app/view/Profiles/choose_profile.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/show_dialog.dart';
import 'package:flutter/material.dart';

import '../../utils/colour_resource.dart';
import '../../utils/images.dart';
import '../../utils/text_styles.dart';

class DemoScreen extends StatefulWidget {
  const DemoScreen({super.key});

  @override
  State<DemoScreen> createState() => _DemoScreenState();
}

class _DemoScreenState extends State<DemoScreen> {
  //
  register() {
    return showDialog(
        context: context,
        builder: (context) {
          return Container(
            child: AlertDialog(
              title: Text("For Registration"),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text("Back"),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ChooseProfile()));
                  },
                  child: Text("Go For Registration"),
                ),
              ],
            ),
          );
        });
  }

  Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context, text: "Back");
        }));

    return request;
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: _onBackButtonPressed,
      child: Scaffold(
        // key: scaffoldKey,
        // drawer: _buildDrawer(),
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(size.height / 16),
          child: AppBar(
            centerTitle: true,
            title: Image.asset(
              Images.splash_logo,
              width: size.width / 2.4,
              height: size.height / 13.33,
            ),
            leading: IconButton(
              onPressed: () {
                // scaffoldKey.currentState!.openDrawer();
              },
              icon: const Icon(
                Icons.menu,
                color: Colors.white,
              ),
            ),
            actions: [
              IconButton(
                onPressed: () {
                  register();
                },
                icon: const Icon(
                  Icons.notifications,
                  color: Colors.white,
                ),
              ),
            ],
            backgroundColor: Colours.PRIMARY_BLUE,
            elevation: 0.0,
            automaticallyImplyLeading: false,
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              // for search field
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: size.width / 30,
                ),
                margin: EdgeInsets.only(
                  left: size.width / 30,
                  right: size.width / 30,
                  bottom: size.height / 40,
                  top: size.height / 80,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colours.PRIMARY_BLUE_MILD,
                ),
                child: TextFormField(
                  style: TextStyles.ktext18(context).copyWith(
                    color: Colours.PRIMARY_GREY_LIGHT,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.5,
                  ),
                  autofocus: false,
                  decoration: InputDecoration(
                    suffixIcon: const Icon(
                      Icons.search,
                      color: Colours.PRIMARY_GREY_LIGHT,
                    ),
                    border: InputBorder.none,
                    hintText: "Search Vehicle,Contractor,labour...",
                    hintStyle: TextStyles.ktext14(context).copyWith(
                        color: Colours.PRIMARY_GREY_LIGHT,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.5),
                  ),
                ),
              ),

              // for banner
              BannerView(),
              //

              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: size.width / 30, vertical: 8),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Heavy Vehicle",
                          style: TextStyles.ktext18(context),
                        ),
                        InkWell(
                          onTap: () {
                            register();
                          },
                          child: Text(
                            "View All",
                            style: TextStyles.ktext16(context)
                                .copyWith(color: Colours.PRIMARY_GREY_MILD),
                          ),
                        ),
                      ],
                    ),
                    Container(
                        height: size.height / 7,
                        margin: EdgeInsets.only(top: 8),
                        child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: 4,
                            itemBuilder: ((context, index) {
                              return InkWell(
                                onTap: () {
                                  register();
                                },
                                child: Container(
                                  height: size.height / 8,
                                  width: size.width / 3.6,
                                  margin: const EdgeInsets.only(right: 20),
                                  decoration: BoxDecoration(
                                    color: Colours.PRIMARY_GREY_LIGHT
                                        .withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: const Padding(
                                        padding: EdgeInsets.all(10.0),
                                        child: Image(
                                            image: AssetImage(
                                          Images.category_vehicle,
                                        )),
                                      )),
                                ),
                              );
                            })))
                  ],
                ),
              ),

              //
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: size.width / 30, vertical: 8),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Driver/Operator",
                          style: TextStyles.ktext18(context),
                        ),
                        InkWell(
                          onTap: () {
                            register();
                          },
                          child: Text(
                            "View All",
                            style: TextStyles.ktext16(context)
                                .copyWith(color: Colours.PRIMARY_GREY_MILD),
                          ),
                        ),
                      ],
                    ),
                    Container(
                        height: size.height / 7,
                        margin: EdgeInsets.only(top: 8),
                        child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: 4,
                            itemBuilder: ((context, index) {
                              return InkWell(
                                onTap: () {
                                  register();
                                },
                                child: Container(
                                  height: size.height / 8,
                                  width: size.width / 3.6,
                                  margin: const EdgeInsets.only(right: 20),
                                  decoration: BoxDecoration(
                                    color: Colours.PRIMARY_GREY_LIGHT
                                        .withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: const Padding(
                                        padding: EdgeInsets.all(10.0),
                                        child: Image(
                                            image: AssetImage(
                                          Images.category_driver,
                                        )),
                                      )),
                                ),
                              );
                            })))
                  ],
                ),
              ),

              //
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: size.width / 30, vertical: 8),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Labour Contructor",
                          style: TextStyles.ktext18(context),
                        ),
                        InkWell(
                          onTap: () {
                            register();
                          },
                          child: Text(
                            "View All",
                            style: TextStyles.ktext16(context)
                                .copyWith(color: Colours.PRIMARY_GREY_MILD),
                          ),
                        ),
                      ],
                    ),
                    Container(
                        height: size.height / 7,
                        margin: EdgeInsets.only(top: 8),
                        child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: 4,
                            itemBuilder: ((context, index) {
                              return InkWell(
                                onTap: () {
                                  register();
                                },
                                child: Container(
                                  height: size.height / 8,
                                  width: size.width / 3.6,
                                  margin: const EdgeInsets.only(right: 20),
                                  decoration: BoxDecoration(
                                    color: Colours.PRIMARY_GREY_LIGHT
                                        .withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: const Padding(
                                        padding: EdgeInsets.all(10.0),
                                        child: Image(
                                            image: AssetImage(
                                          Images.category_labour,
                                        )),
                                      )),
                                ),
                              );
                            })))
                  ],
                ),
              ),

              //
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: size.width / 30, vertical: 8),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Sub Contructor",
                          style: TextStyles.ktext18(context),
                        ),
                        InkWell(
                          onTap: () {
                            register();
                          },
                          child: Text(
                            "View All",
                            style: TextStyles.ktext16(context)
                                .copyWith(color: Colours.PRIMARY_GREY_MILD),
                          ),
                        ),
                      ],
                    ),
                    Container(
                        height: size.height / 7,
                        margin: EdgeInsets.only(top: 8),
                        child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: 4,
                            itemBuilder: ((context, index) {
                              return InkWell(
                                onTap: () {
                                  register();
                                },
                                child: Container(
                                  height: size.height / 8,
                                  width: size.width / 3.6,
                                  margin: const EdgeInsets.only(right: 20),
                                  decoration: BoxDecoration(
                                    color: Colours.PRIMARY_GREY_LIGHT
                                        .withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: const Padding(
                                        padding: EdgeInsets.all(10.0),
                                        child: Image(
                                            image: AssetImage(
                                          Images.category_subcontr,
                                        )),
                                      )),
                                ),
                              );
                            })))
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
