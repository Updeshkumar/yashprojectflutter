import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/customs_button.dart';
import '../../widgets/logo_text.dart';
import '../BottomNavBar/bottoms_nav_bar.dart';

class PaymentSuccess extends StatefulWidget {
  String? payment_id;
  String? Amount;
  String? dateTime;
  String? order_Id;
  String? from;

  PaymentSuccess(
      {this.Amount, this.dateTime, this.payment_id, this.order_Id, this.from});

  @override
  State<PaymentSuccess> createState() => _PaymentSuccessState();
}

class _PaymentSuccessState extends State<PaymentSuccess> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        bottomNavigationBar: Container(
          margin: EdgeInsets.symmetric(
              horizontal: size.width / 30, vertical: size.height / 40),
          child: CustomButton(
            text: "DONE",
            height: size.height / 16,
            textColor: Colours.PRIMARY_BLACK,
            onTap: () async {
              if (widget.from!.contains("driver")) {
                model.driverPaymentHandller(context,
                    payment_id: widget.payment_id,
                    order_id: widget.order_Id,
                    pay_signature: widget.payment_id);
              } else if (widget.from!.contains("labour")) {
                model.labourPaymentHandller(context,
                    payment_id: widget.payment_id,
                    order_id: widget.order_Id,
                    pay_signature: widget.payment_id);
              } else if (widget.from!.contains("sub")) {
                model.subContrPaymentHandller(context,
                    payment_id: widget.payment_id,
                    order_id: widget.order_Id,
                    pay_signature: widget.payment_id);
              } else if (widget.from!.contains("vehicle")) {
                model.vehiclePaymentHandller(context,
                    payment_id: widget.payment_id,
                    order_id: widget.order_Id,
                    pay_signature: widget.payment_id);
              } else if (widget.from!.contains("normal")) {
                model.normalPaymentHandller(context,
                    payment_id: widget.payment_id,
                    order_id: widget.order_Id,
                    pay_signature: widget.payment_id);
              }
            },
          ),
        ),
        body: Column(
          children: [
            SizedBox(
              height: size.height / 18,
            ),
            Container(
              alignment: Alignment.center,
              child: LogoText(),
            ),
            SizedBox(
              height: size.height / 40,
            ),
            Text(
              "Payment Confirmation",
              style: TextStyles.ktext20(context),
            ),
            Container(
              padding: EdgeInsets.symmetric(vertical: size.height / 40),
              margin: EdgeInsets.symmetric(
                  horizontal: size.width / 30, vertical: size.height / 40),
              decoration: BoxDecoration(
                color: Colours.PRIMARY_BLUE_MILD,
                borderRadius: BorderRadius.circular(8),
              ),
              alignment: Alignment.center,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    Images.success_icon,
                    height: 50,
                  ),
                  Text(
                    "Payment Successful",
                    style: TextStyles.ktext18(context).copyWith(
                      color: Colours.GREEN_LIGHT,
                    ),
                  ),
                  SizedBox(
                    height: 12,
                  ),
                  Text(
                    "Order ID :  " + widget.order_Id!,
                    style: TextStyle(fontSize: 14, color: Colours.GREEN_LIGHT),
                  )
                ],
              ),
            ),

            //
            Padding(
              padding: const EdgeInsets.only(left: 16, bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Transaction ID: ",
                    style: TextStyles.ktext16(context)
                        .copyWith(color: Colours.RED_COLOR),
                  ),
                  Text(
                    widget.payment_id!,
                    style: TextStyles.ktext16(context)
                        .copyWith(color: Colours.RED_COLOR),
                  ),
                  SizedBox(
                    width: 10,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 16, bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Amount: ",
                    style: TextStyles.ktext16(context)
                        .copyWith(color: Colours.GREEN_LIGHT),
                  ),
                  Text(
                    "1000",
                    style: TextStyles.ktext16(context)
                        .copyWith(color: Colours.GREEN_LIGHT),
                  ),
                  SizedBox(
                    width: 10,
                  )
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 16, bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Date & Time : ",
                    style: TextStyles.ktext16(context)
                        .copyWith(color: Colours.YELLOW_LIGHT),
                  ),
                  Text(
                    widget.dateTime!.toString().substring(0, 19),
                    style: TextStyles.ktext16(context)
                        .copyWith(color: Colours.YELLOW_LIGHT),
                  ),
                  SizedBox(
                    width: 10,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 16, bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Status : ",
                    style: TextStyles.ktext16(context)
                        .copyWith(color: Colours.GREEN_LIGHT),
                  ),
                  Text(
                    "DONE  ",
                    style: TextStyles.ktext16(context)
                        .copyWith(color: Colours.GREEN_LIGHT),
                  ),
                  SizedBox(
                    width: 10,
                  )
                ],
              ),
            ),
          ],
        ),
      );
    });
  }
}
