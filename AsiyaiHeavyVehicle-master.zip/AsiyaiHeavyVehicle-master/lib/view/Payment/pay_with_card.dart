import 'package:asiayai_heavy_vehicle_app/view/Payment/payment_sucess.dart';
import 'package:flutter/material.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/customs_button.dart';
import '../../widgets/textfield.dart';

class PaYWithCard extends StatelessWidget {
  const PaYWithCard({super.key});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      bottomNavigationBar: Container(
        margin: EdgeInsets.symmetric(
            horizontal: size.width / 30, vertical: size.height / 40),
        child: CustomButton(
          text: "CONTINUE",
          height: size.height / 16,
          textColor: Colours.PRIMARY_BLACK,
          onTap: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => PaymentSuccess()));
          },
        ),
      ),
      appBar: AppBar(
        backgroundColor: Colours.PRIMARY_GREY,
        title: Text(
          "Pay With Card",
          style: TextStyles.ktext20(context),
        ),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(
          horizontal: size.width / 18,
          vertical: size.height / 80,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: size.height / 40,
            ),
            Text(
              "Name on Card",
              style: TextStyles.ktext18(context).copyWith(
                  color: Colours.PRIMARY_GREY_LIGHT,
                  fontWeight: FontWeight.w500),
            ),
            SizedBox(
              height: size.height / 160,
            ),
            IconTextField(),
            SizedBox(
              height: size.height / 160,
            ),
            Text(
              "Card Number",
              style: TextStyles.ktext18(context).copyWith(
                  color: Colours.PRIMARY_GREY_LIGHT,
                  fontWeight: FontWeight.w500),
            ),
            SizedBox(
              height: size.height / 160,
            ),
            IconTextField(),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Expire Date",
                        style: TextStyles.ktext16(context).copyWith(
                            color: Colours.PRIMARY_GREY_LIGHT,
                            fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      IconTextField(),
                    ],
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "CVV",
                        style: TextStyles.ktext16(context).copyWith(
                            color: Colours.PRIMARY_GREY_LIGHT,
                            fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      IconTextField(),
                    ],
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
