import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/make_payment_Model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/view/Payment/payment_sucess.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/logo_text.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

class PayWithRazorPay extends StatefulWidget {
  MakePaymnetDataModel? obj;
  String? from;
  PayWithRazorPay({this.obj, this.from});

  @override
  State<PayWithRazorPay> createState() => _PayWithRazorPayState();
}

class _PayWithRazorPayState extends State<PayWithRazorPay> {
  @override
  void initState() {
    initiateRazorPay();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    MakePaymentDetails paymentDetails = widget.obj!.data!.details!;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: AppBar(
        backgroundColor: Colours.PRIMARY_BLUE_MILD,
        title: Text("Pay "),
      ),
      body: Container(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const LogoText(),
            const SizedBox(
              height: 60,
            ),
            InkWell(
              onTap: () async {
                if (widget.obj != null && paymentDetails != null) {
                  print(paymentDetails.razorpayMerchantKey);
                  await openRazroPayments(paymentDetails.razorpayAmount,
                      paymentDetails.razorpayMerchantKey);
                  order_Id = paymentDetails.razorpayOrderId;
                  amount = paymentDetails.razorpayAmount;
                } else {
                  showTostMsg("Sorry, Come Back Again");
                }
              },
              child: Container(
                width: 200,
                padding: EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colours.YELLOW_DARK,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    "Tap for Pay",
                    style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  String? order_Id;
  final Razorpay _razorpay = Razorpay();

  initiateRazorPay() {
    // To handle different event with previous functions
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  String? transaction_Id;
  String? amount;
  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    //print(response);
    // print("response pay" + jsonEncode(response));
    print("Sucesss " + response.paymentId!);
    showTostMsg(response.paymentId!);

    if (response.paymentId != null) {
      transaction_Id = response.paymentId;
    } else {
      transaction_Id = null;
    }
    if (transaction_Id == null) {
      showTostMsg("sorry");
      return;
    }

    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => PaymentSuccess(
                  payment_id: transaction_Id,
                  Amount: amount,
                  dateTime: DateTime.now().toString(),
                  order_Id: order_Id,
                  from: widget.from,
                )));

    // Do something when payment succeeds
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    print("FAILED");
    // Do something when payment fails
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    print("WAITING");
    // Do something when an external wallet is selected
  }

  openRazroPayments(String? amount, String? merchAntKey) {
    var options = {
      'key': 'rzp_test_93SNW3ejRJjMzM',
      'amount': double.parse(amount!),
      'name': 'AHV',
      'description': 'Registration',
      'prefill': {'contact': '', 'email': ''}
    };
    _razorpay.open(options);
  }
}
