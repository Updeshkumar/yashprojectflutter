import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/make_payment_Model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/app_constants.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/logo_text.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PayPaymentScreen extends StatefulWidget {
  String? from;
  String? id;
  PayPaymentScreen({this.from, this.id});

  @override
  State<PayPaymentScreen> createState() => _PayPaymentScreenState();
}

class _PayPaymentScreenState extends State<PayPaymentScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //   print("USER TYPE >>>> " + userType!);
  }

  String? userType;
  // getData() async {
  //   SharedPreferences myprefs = await SharedPreferences.getInstance();
  //   userType = myprefs.getString(AppConstants.USER_TYPE);
  // }

  @override
  Widget build(BuildContext context) {
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: AppBar(
          backgroundColor: Colours.PRIMARY_BLUE_MILD,
          title: Text("Pay Payment"),
        ),
        body: Container(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const LogoText(),
              const SizedBox(
                height: 20,
              ),
              Text(
                "Welcome In AHV ",
                style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w600,
                    color: Colours.YELLOW_DARK),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Please Pay ",
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colours.YELLOW_DARK),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "₹ 1000 ",
                style: TextStyle(
                  fontSize: 25,
                  color: Colours.YELLOW_DARK,
                ),
              ),
              SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
        bottomNavigationBar: InkWell(
          onTap: () async {
            await model.phone_pay();
            // SharedPreferences prefs = await SharedPreferences.getInstance();
            // userType = prefs.getString(AppConstants.USER_TYPE);
            // if (widget.from != null && widget.from != "") {
            //   if (widget.from!.contains("labour")) {
            //     await model.labourContruMakePayment(context);
            //   } else if (widget.from!.contains("driver")) {
            //     await model.driverMakePayment(context);
            //   } else if (widget.from!.contains("sub")) {
            //     await model.subContruMakePayment(context);
            //   } else if (widget.from!.contains("vehicle")) {
            //     await model.vehicleContruMakePayment(context, id: widget.id);
            //   } else if (widget.from!.contains("normal")) {
            //     await model.normalMakePayment(
            //       context,
            //     );
            //   }
            // } else {
            //   if (userType!.contains("labour")) {
            //     await model.labourContruMakePayment(context);
            //   } else if (userType!.contains("driver")) {
            //     await model.driverMakePayment(context);
            //   } else if (userType!.contains("sub")) {
            //     await model.subContruMakePayment(context);
            //   } else if (userType!.contains("vehicle")) {
            //     await model.vehicleContruMakePayment(context, id: widget.id);
            //   } else if (userType!.contains("normal")) {
            //     await model.normalMakePayment(
            //       context,
            //     );
            //   }
            // }
          },
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            height: 45,
            decoration: BoxDecoration(
                color: Colours.YELLOW_DARK,
                borderRadius: BorderRadius.circular(12)),
            child: Center(
              child: Text(
                "Pay : ₹ 1000",
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 22),
              ),
            ),
          ),
        ),
      );
    });
  }
}
