import 'dart:ui';

import 'package:asiayai_heavy_vehicle_app/view/Payment/payment_sucess.dart';
import 'package:flutter/material.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/customs_button.dart';

class PayWithUPI extends StatefulWidget {
  const PayWithUPI({super.key});

  @override
  State<PayWithUPI> createState() => _PayWithUPIState();
}

class _PayWithUPIState extends State<PayWithUPI> {
  static const values = <String>["Phone PAy", "Google PAY", "PAYTM"];
  static const secondary = <String>["images/icons/upi.png"];

  String? selectedValue;

  Widget buildRadios() {
    return Column(
      children: values.map((value) {
        final selcted = this.selectedValue == value;
        final boxcolor =
            selcted ? Colours.YELLOW_DARK : Colours.PRIMARY_BLUE_MILD;
        final textColor =
            selcted ? Colours.PRIMARY_BLACK : Colours.PRIMARY_GREY_LIGHT;
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 18, vertical: 5),
          child: Theme(
            data: ThemeData(
                radioTheme: RadioThemeData(
                    fillColor: MaterialStateColor.resolveWith((states) =>
                        selcted
                            ? Colours.PRIMARY_BLACK
                            : Colours.PRIMARY_GREY_LIGHT))),
            child: RadioListTile(
              value: value,
              groupValue: selectedValue,
              tileColor: boxcolor,
              secondary: Container(
                child: Image.asset(secondary.toString()),
              ),
              title: Text(
                value,
                style: TextStyles.ktext18(context).copyWith(color: textColor),
              ),
              onChanged: (value) {
                setState(() {
                  this.selectedValue = value;
                });
              },
            ),
          ),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: AppBar(
        backgroundColor: Colours.PRIMARY_GREY,
        title: Text(
          "Pay With UPI",
          style: TextStyles.ktext20(context),
        ),
      ),
      bottomNavigationBar: Container(
        margin: EdgeInsets.symmetric(
            horizontal: size.width / 30, vertical: size.height / 40),
        child: CustomButton(
          text: "CONTINUE",
          height: size.height / 16,
          textColor: Colours.PRIMARY_BLACK,
          onTap: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => PaymentSuccess()));
          },
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: size.height / 40,
          ),
          buildRadios(),
        ],
      ),
    );
  }
}
