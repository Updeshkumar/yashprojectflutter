import 'package:asiayai_heavy_vehicle_app/view/Payment/pay_upi.dart';
import 'package:asiayai_heavy_vehicle_app/view/Payment/pay_with_card.dart';
import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/app_snack_bar.dart';
import '../../widgets/customs_button.dart';
import '../../widgets/logo_text.dart';
import '../../widgets/show_dialog.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  //
  static const values = <String>[
    "Pay With Card",
    "Pay with UPI",
    "Net Banking"
  ];
  String? selectedValue;
  bool isFalse = false;
  String? screenNumber;

  changeScreen(String index) {
    switch (index) {
      case "Pay With Card":
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => PaYWithCard()));
        break;
      case "Pay with UPI":
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => PayWithUPI()));
        break;
      case "Net Banking":
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => PaYWithCard()));
        break;
      default:
    }
  }

  Widget buildRadios() {
    return Column(
      children: values.map((value) {
        final selected = this.selectedValue == value;
        final boxColor =
            selected ? Colours.YELLOW_DARK : Colours.PRIMARY_BLUE_MILD;
        final textColor =
            selected ? Colours.PRIMARY_BLACK : Colours.PRIMARY_GREY_LIGHT;
        return Container(
          margin: EdgeInsets.only(bottom: 10, left: 18, right: 18),
          child: Theme(
            data: ThemeData(
                radioTheme: RadioThemeData(
                    fillColor: MaterialStateColor.resolveWith((states) =>
                        selected
                            ? Colours.PRIMARY_BLACK
                            : Colours.PRIMARY_GREY_LIGHT))),
            child: RadioListTile(
                value: value,
                tileColor: boxColor,
                groupValue: selectedValue,
                title: Text(
                  value,
                  style: TextStyles.ktext18(context).copyWith(color: textColor),
                ),
                onChanged: (value) {
                  setState(() {
                    screenNumber = value;
                    this.selectedValue = value;
                  });
                }),
          ),
        );
      }).toList(),
    );
  }

  //
  ////methods
  Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context);
        }));

    return request;
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      bottomNavigationBar: Container(
        margin: EdgeInsets.symmetric(
            horizontal: size.width / 30, vertical: size.height / 40),
        child: CustomButton(
          text: "CONTINUE",
          height: size.height / 16,
          textColor: Colours.PRIMARY_BLACK,
          onTap: () {
            if (screenNumber != null) {
              changeScreen(screenNumber!);
            } else {
              AppSnackBar.appSnackBar(
                context: context,
                message: "Please Select any Methods",
                title: "For Payment",
                isError: true,
              );
            }
          },
        ),
      ),
      body: WillPopScope(
        onWillPop: _onBackButtonPressed,
        child: Column(
          children: [
            SizedBox(
              height: size.height / 20,
            ),
            Container(
              alignment: Alignment.center,
              child: LogoText(),
            ),
            SizedBox(
              height: size.height / 40,
            ),
            Text(
              "Choose Payment Method",
              style: TextStyles.ktext20(context),
            ),
            SizedBox(
              height: size.height / 40,
            ),
            Expanded(child: buildRadios()),
          ],
        ),
      ),
    );
  }
}
