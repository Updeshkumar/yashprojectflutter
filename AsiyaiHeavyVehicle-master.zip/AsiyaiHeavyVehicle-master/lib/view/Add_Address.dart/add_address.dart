import 'package:asiayai_heavy_vehicle_app/data/respnse/address_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddAddress extends StatefulWidget {
  String? from;
  String? id;
  AddAddress({this.from, this.id});

  @override
  State<AddAddress> createState() => _AddAddressState();
}

class _AddAddressState extends State<AddAddress> {
  getData() async {
    await Provider.of<UserProvider>(context, listen: false).getState(context);
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 200), () => getData());
  }

  StateModel? selectedState;
  DistrictModel? selectedDistrict;
  TehsilModel? selectedTehsil;
  Size? _size;

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: AppBar(
          backgroundColor: Colours.PRIMARY_GREY,
          title: Text("Add Address"),
        ),
        body: StatefulBuilder(builder: (context, myState) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "State",
                  style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.w700),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colours.YELLOW_DARK, width: 1),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Theme(
                    data: ThemeData(
                      textTheme: TextTheme(
                        subtitle1: TextStyle(color: Colors.white),
                      ),
                      iconTheme: IconThemeData(color: Colors.white),
                    ),
                    child: DropdownSearch<StateModel>(
                      //asyncItems: (String filter) => getData(filter),
                      itemAsString: (StateModel? u) => u!.stateName!,

                      items: model.states!,
                      dropdownButtonProps: DropdownButtonProps(),

                      dropdownDecoratorProps: DropDownDecoratorProps(
                        dropdownSearchDecoration: InputDecoration(
                            iconColor: Colors.white,
                            hintText: "Select State",
                            hintStyle: TextStyle(color: Colors.white),
                            border: InputBorder.none),
                      ),
                      popupProps: PopupProps.dialog(
                          showSearchBox: true,
                          //showSelectedItems: true,
                          title: Text(
                            "Select State",
                            style: TextStyle(color: Colors.white),
                          ),
                          dialogProps: DialogProps()),
                      selectedItem: selectedState,

                      onChanged: (StateModel? data) async {
                        myState(() {
                          selectedState = data!;
                          selectedDistrict = null;
                          selectedTehsil = null;
                        });
                        model.getDistict(
                          context,
                          state_id: data!.id!.toString(),
                        );
                      },
                      onSaved: (data) {
                        print("hi");
                      },
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  "District",
                  style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.w700),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colours.YELLOW_DARK, width: 1),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Theme(
                    data: ThemeData(
                      textTheme: TextTheme(
                        subtitle1: TextStyle(color: Colors.white),
                      ),
                      iconTheme: IconThemeData(color: Colors.white),
                    ),
                    child: DropdownSearch<DistrictModel>(
                      //asyncItems: (String filter) => getData(filter),
                      itemAsString: (DistrictModel? u) => u!.districtName!,

                      items: model.distict!,
                      dropdownButtonProps: DropdownButtonProps(),

                      dropdownDecoratorProps: DropDownDecoratorProps(
                        dropdownSearchDecoration: InputDecoration(
                            iconColor: Colors.white,
                            hintText: "Select District",
                            hintStyle: TextStyle(color: Colors.white),
                            border: InputBorder.none),
                      ),
                      popupProps: PopupProps.dialog(
                          showSearchBox: true,
                          //showSelectedItems: true,
                          title: Text(
                            "Select District",
                            style: TextStyle(color: Colors.white),
                          ),
                          dialogProps: DialogProps()),
                      selectedItem: selectedDistrict,

                      onChanged: (DistrictModel? data) async {
                        myState(() {
                          selectedDistrict = data!;
                          selectedTehsil = null;
                        });
                        model.getTehsil(
                          context,
                          district_id: data!.id.toString(),
                        );
                      },
                      onSaved: (data) {
                        print("hi");
                      },
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  "Tehsil",
                  style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.w700),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colours.YELLOW_DARK, width: 1),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Theme(
                    data: ThemeData(
                      textTheme: TextTheme(
                        subtitle1: TextStyle(color: Colors.white),
                      ),
                      iconTheme: IconThemeData(color: Colors.white),
                    ),
                    child: DropdownSearch<TehsilModel>(
                      //asyncItems: (String filter) => getData(filter),
                      itemAsString: (TehsilModel? u) => u!.tahseelName!,

                      items: model.tehsils!,
                      dropdownButtonProps: DropdownButtonProps(),

                      dropdownDecoratorProps: DropDownDecoratorProps(
                        dropdownSearchDecoration: InputDecoration(
                            iconColor: Colors.white,
                            hintText: "Select Tehsil",
                            hintStyle: TextStyle(color: Colors.white),
                            border: InputBorder.none),
                      ),
                      popupProps: PopupProps.dialog(
                          showSearchBox: true,
                          //showSelectedItems: true,
                          title: Text(
                            "Select Tehsil",
                            style: TextStyle(color: Colors.white),
                          ),
                          dialogProps: DialogProps()),
                      selectedItem: selectedTehsil,

                      onChanged: (TehsilModel? data) async {
                        myState(() {
                          selectedTehsil = data!;
                        });
                        // model.getStateList(
                        //     countryId: addressCountryCodeList!.countryId!,
                        //     context: context);
                      },
                      onSaved: (data) {
                        print("hi");
                      },
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
        bottomNavigationBar: InkWell(
          onTap: () async {
            if (selectedState != null &&
                selectedDistrict != null &&
                selectedTehsil != null) {
              if (widget.from == "1") {
                await model.addAddress(context,
                    heavy_id: int.parse(widget.id!),
                    state_id: selectedState!.id,
                    dis_id: selectedDistrict!.id,
                    teh_id: selectedTehsil!.id);
              } else if (widget.from == "2") {
                await model.addDriverAddress(context,
                    state_id: selectedState!.id,
                    dis_id: selectedDistrict!.id,
                    teh_id: selectedTehsil!.id);
              } else if (widget.from == "4") {
                await model.addLabourAddress(context,
                    state_id: selectedState!.id,
                    dis_id: selectedDistrict!.id,
                    teh_id: selectedTehsil!.id);
              } else if (widget.from == "3") {
                await model.addSubContructorAddress(context,
                    state_id: selectedState!.id,
                    dis_id: selectedDistrict!.id,
                    teh_id: selectedTehsil!.id);
              } else if (widget.from == "5") {
                await model.addNormalUserAddress(context,
                    state_id: selectedState!.id,
                    dis_id: selectedDistrict!.id,
                    teh_id: selectedTehsil!.id);
              }
            } else {
              showTostMsg("Please Select Address !!");
            }
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
            child: Container(
              height: _size!.height * 0.05,
              decoration: BoxDecoration(
                color: Colours.YELLOW_LIGHT,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Text(
                  "SUBMIT",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ),
      );
    });
  }
}
