import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/view/Payment/payment_screen.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/show_dialog.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/textfield.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../data/datamodel/address_model.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';
import '../../../widgets/app_snack_bar.dart';
import '../../../widgets/customs_button.dart';

class NormalUserRegistration extends StatefulWidget {
  const NormalUserRegistration({super.key});

  @override
  State<NormalUserRegistration> createState() => _NormalUserRegistrationState();
}

class _NormalUserRegistrationState extends State<NormalUserRegistration> {
  //
  TextEditingController nameController = TextEditingController();
  var selectedState;
  var selectDistrict;
  var selectedTehsil;
  List<AddressModel> districtTempList = <AddressModel>[];
  List<AddressModel> tehsilTempList = <AddressModel>[];
  //
  // Widget DropDownSDT() {
  //   return Consumer<AddressProvider>(
  //       builder: (context, addressProvider, child) {
  //     return Column(
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       children: [
  //         Container(
  //           margin: const EdgeInsets.only(
  //             bottom: 10,
  //           ),
  //           padding: const EdgeInsets.symmetric(horizontal: 20),
  //           decoration: BoxDecoration(
  //             borderRadius: BorderRadius.circular(8),
  //             color: Colours.PRIMARY_BLUE_MILD,
  //           ),
  //           child: DropdownButtonHideUnderline(
  //             child: DropdownButtonFormField(
  //               dropdownColor: Colors.white,
  //               hint: Text(
  //                 "Select State".tr().toString(),
  //                 style: TextStyles.ktext16(context)
  //                     .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
  //               ),
  //               icon: Container(
  //                 decoration: const BoxDecoration(
  //                   shape: BoxShape.circle,
  //                   color: Colours.PRIMARY_GREY_LIGHT,
  //                 ),
  //                 child: const Icon(
  //                   Icons.keyboard_arrow_down_rounded,
  //                   color: Colors.black,
  //                 ),
  //               ),
  //               iconSize: 20,
  //               isExpanded: true,
  //               value: selectedState,
  //               style: TextStyles.ktext20(context).copyWith(
  //                   color: Colours.PRIMARY_BLACK, fontWeight: FontWeight.bold),
  //               onChanged: (value) {
  //                 setState(() {
  //                   selectDistrict = null;
  //                   selectedState = value;

  //                   ////
  //                   districtTempList = addressProvider.districtList
  //                       .where(
  //                         (element) =>
  //                             element.relatedToId.toString() ==
  //                             selectedState.toString(),
  //                       )
  //                       .toList();
  //                 });
  //               },
  //               validator: ((value) {
  //                 if (value == null) {
  //                   return "State Required";
  //                 }
  //               }),
  //               items: addressProvider.stateList.map((sts) {
  //                 return DropdownMenuItem<String>(
  //                   value: sts.id.toString(),
  //                   child: Text(
  //                     sts.valueName.toString(),
  //                     style: TextStyles.ktext16(context).copyWith(
  //                         color: Colours.PRIMARY_GREY_LIGHT,
  //                         fontWeight: FontWeight.w500),
  //                   ),
  //                 );
  //               }).toList(),
  //             ),
  //           ),
  //         ),

  //         //
  //         Container(
  //           margin: const EdgeInsets.only(
  //             bottom: 10,
  //           ),
  //           padding: const EdgeInsets.symmetric(horizontal: 20),
  //           decoration: BoxDecoration(
  //             borderRadius: BorderRadius.circular(8),
  //             color: Colours.PRIMARY_BLUE_MILD,
  //           ),
  //           child: DropdownButtonHideUnderline(
  //             child: DropdownButtonFormField(
  //               dropdownColor: Colors.white,
  //               hint: Text(
  //                 "Select District".tr().toString(),
  //                 style: TextStyles.ktext16(context)
  //                     .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
  //               ),
  //               icon: Container(
  //                 decoration: const BoxDecoration(
  //                   shape: BoxShape.circle,
  //                   color: Colours.PRIMARY_GREY_LIGHT,
  //                 ),
  //                 child: const Icon(
  //                   Icons.keyboard_arrow_down_rounded,
  //                   color: Colors.black,
  //                 ),
  //               ),
  //               iconSize: 20,
  //               isExpanded: true,
  //               value: selectDistrict,
  //               style: TextStyles.ktext20(context).copyWith(
  //                   color: Colours.PRIMARY_BLACK, fontWeight: FontWeight.bold),
  //               onChanged: (value) {
  //                 setState(() {
  //                   selectedTehsil = null;
  //                   selectDistrict = value;
  //                   tehsilTempList = addressProvider.tehsilList
  //                       .where(
  //                         (element) =>
  //                             element.relatedToId.toString() ==
  //                             selectDistrict.toString(),
  //                       )
  //                       .toList();
  //                 });
  //               },
  //               validator: ((value) {
  //                 if (value == null) {
  //                   return "District Required";
  //                 }
  //               }),
  //               items: districtTempList.map((sts) {
  //                 return DropdownMenuItem<String>(
  //                   value: sts.id.toString(),
  //                   child: Text(
  //                     sts.valueName.toString(),
  //                     style: TextStyles.ktext16(context).copyWith(
  //                         color: Colours.PRIMARY_GREY_LIGHT,
  //                         fontWeight: FontWeight.w500),
  //                   ),
  //                 );
  //               }).toList(),
  //             ),
  //           ),
  //         ),

  //         //
  //         Container(
  //           margin: const EdgeInsets.only(
  //             bottom: 10,
  //           ),
  //           padding: const EdgeInsets.symmetric(horizontal: 20),
  //           decoration: BoxDecoration(
  //             borderRadius: BorderRadius.circular(8),
  //             color: Colours.PRIMARY_BLUE_MILD,
  //           ),
  //           child: DropdownButtonHideUnderline(
  //             child: DropdownButtonFormField(
  //               dropdownColor: Colors.white,
  //               hint: Text(
  //                 "Select Tehsil".tr().toString(),
  //                 style: TextStyles.ktext16(context)
  //                     .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
  //               ),
  //               icon: Container(
  //                 decoration: const BoxDecoration(
  //                   shape: BoxShape.circle,
  //                   color: Colours.PRIMARY_GREY_LIGHT,
  //                 ),
  //                 child: const Icon(
  //                   Icons.keyboard_arrow_down_rounded,
  //                   color: Colors.black,
  //                 ),
  //               ),
  //               iconSize: 20,
  //               isExpanded: true,
  //               value: selectedTehsil,
  //               style: TextStyles.ktext20(context).copyWith(
  //                   color: Colours.PRIMARY_BLACK, fontWeight: FontWeight.bold),
  //               onChanged: (value) {
  //                 setState(() {
  //                   selectedTehsil = value;
  //                 });
  //               },
  //               validator: ((value) {
  //                 if (value == null) {
  //                   return "Tehsil Required";
  //                 }
  //               }),
  //               items: tehsilTempList.map((sts) {
  //                 return DropdownMenuItem<String>(
  //                   value: sts.id.toString(),
  //                   child: Text(
  //                     sts.valueName.toString(),
  //                     style: TextStyles.ktext16(context).copyWith(
  //                         color: Colours.PRIMARY_GREY_LIGHT,
  //                         fontWeight: FontWeight.w500),
  //                   ),
  //                 );
  //               }).toList(),
  //             ),
  //           ),
  //         )
  //       ],
  //     );
  //   });
  // }

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    // Provider.of<AddressProvider>(context, listen: false).getStateList(context);
    // Provider.of<AddressProvider>(context, listen: false)
    //     .getDistrictList(context);
    // Provider.of<AddressProvider>(context, listen: false).getTehsilList(context);
    super.initState();
  }

  //
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(size.height / 16),
          child: AppBar(
            title: Text(
              "Normal User Register",
              style: TextStyles.ktext20(context),
            ),
            backgroundColor: Colours.PRIMARY_GREY,
          ),
        ),
        body: Form(
          key: _formKey,
          child: Container(
            padding:
                EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 20),
            child: Column(
              children: [
                IconTextField(
                  title: "Enter Your Name".tr().toString(),
                  controller: nameController,
                  onValidate: (value) {
                    if (value.isEmpty) {
                      return "Name is required";
                    }
                  },
                ),
                // DropDownSDT(),
              ],
            ),
          ),
        ),
        bottomNavigationBar: Container(
          margin: EdgeInsets.only(
            bottom: size.height / 60,
            right: size.width / 24,
            left: size.width / 24,
          ),
          child: CustomButton(
            height: size.height / 16,
            textColor: Colors.black,
            text: "Next",
            onTap: () async {
              String value = nameController.text;
              if (value.isNotEmpty) {
                model.postNormalUser(context, name: nameController.text);
                // ShowDialogsss().showDialogContainer(context);
                // registerProvider
                //     .postNormalUser(name: nameController.text, context: context)
                //     .then((value) {
                //   value
                //       ? Navigator.push(
                //           context,
                //           MaterialPageRoute(
                //               builder: (context) => PaymentScreen()))
                //       : null;
                // });
              } else {
                AppSnackBar.appSnackBar(
                    context: context,
                    message: "Enter Your Details",
                    title: "Exception",
                    isError: true);
              }
            },
          ),
        ),
      );
    });
  }
}
