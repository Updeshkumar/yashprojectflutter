import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/DriverNew/driver.post.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/heavy_vehicle.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/Labour/labour.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/SubRegister/sub_register.dart';

import 'package:asiayai_heavy_vehicle_app/view/Profiles/SubContractor/body.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/app_snack_bar.dart';
import '../../widgets/customs_button.dart';
import '../../widgets/logo_text.dart';
import '../../widgets/show_dialog.dart';
import 'LabourContractor/body.dart';
import 'NormalRegister/body.dart';

class ChooseProfile extends StatefulWidget {
  const ChooseProfile({super.key});

  @override
  State<ChooseProfile> createState() => _ChooseProfileState();
}

class _ChooseProfileState extends State<ChooseProfile> {
  //variables
  static const values = <String>[
    'Heavy Vehicle',
    'Driver/Operator',
    'Sub Contractor',
    'Labour Contractor',
    'Normal User'
  ];
  //
  String? screenNumber;

  String? selectedValue;
  final selectedColor = Colours.YELLOW_DARK;
  final unselectedColor = Colours.PRIMARY_BLUE_MILD;

  //states

  //methods
  changeScreen(String index) {
    switch (index) {
      case 'Heavy Vehicle':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => HeavyVehiclePostScreen()));

        break;
      case 'Driver/Operator':
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => DriverDataPost()));
        break;
      case 'Labour Contractor':
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => LabourRegister()));
        break;
      case 'Sub Contractor':
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => SubRegister()));
        break;
      case 'Normal User':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => NormalUserRegistration()));
        break;
      default:
    }
  }

  ////methods
  Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context, text: "Back");
        }));

    return request;
  }

  Widget buildRadios() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18),
        child: Column(
          children: values.map((value) {
            final selected = this.selectedValue == value;
            final boxColor = selected ? selectedColor : unselectedColor;
            final textColor =
                selected ? Colours.PRIMARY_BLACK : Colours.PRIMARY_GREY_LIGHT;
            return Container(
              margin: const EdgeInsets.symmetric(vertical: 5),
              child: Theme(
                data: ThemeData(
                    radioTheme: RadioThemeData(
                        fillColor: MaterialStateColor.resolveWith((states) =>
                            selected
                                ? Colours.PRIMARY_BLACK
                                : Colours.PRIMARY_GREY_LIGHT))),
                child: RadioListTile<String>(
                  value: value,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(100),
                  ),
                  groupValue: selectedValue,
                  tileColor: boxColor,
                  title: Text(
                    value,
                    style:
                        TextStyles.ktext18(context).copyWith(color: textColor),
                  ),
                  onChanged: (value) {
                    setState(() {
                      this.selectedValue = value!;
                      screenNumber = selectedValue;
                      print(screenNumber);
                    });
                  },
                ),
              ),
            );
          }).toList(),
        ),
      );

  //build method
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        bottomNavigationBar: Container(
          margin: EdgeInsets.only(
            bottom: size.height / 60,
            right: size.width / 24,
            left: size.width / 24,
          ),
          child: CustomButton(
            height: size.height / 16,
            textColor: Colors.black,
            text: "Next",
            onTap: () async {
              if (screenNumber != null) {
                // ShowDialogsss().showDialogContainer(context);
                String? title;
                if (screenNumber == "Heavy Vehicle") {
                  title = "heavy_vehicle";
                } else if (screenNumber == "Driver/Operator") {
                  title = "driver";
                } else if (screenNumber == "Sub Contractor") {
                  title = "subcontructor";
                } else if (screenNumber == "Labour Contractor") {
                  title = "labour";
                } else if (screenNumber == "Normal User") {
                  title = "user";
                }
                await model.postProfile(context, title: title);
                if (model.isprofileSet == true) {
                  changeScreen(screenNumber!);
                } //
              } else {
                AppSnackBar.appSnackBar(
                  context: context,
                  message: "Please select any Profile",
                  title: "Select Profile",
                  isError: true,
                );
              }
            },
          ),
        ),
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(size.height / 16),
          child: AppBar(
            backgroundColor: Colours.PRIMARY_GREY,
            title: Text(
              "Choose Profile",
              style: TextStyles.ktext20(context),
            ),
            centerTitle: true,
            automaticallyImplyLeading: false,
          ),
        ),
        body: WillPopScope(
          onWillPop: _onBackButtonPressed,
          child: Container(
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: size.height / 40,
                ),
                const LogoText(),
                SizedBox(
                  height: size.height / 40,
                ),
                Expanded(child: buildRadios()),
              ],
            ),
          ),
        ),
      );
    });
  }
}
