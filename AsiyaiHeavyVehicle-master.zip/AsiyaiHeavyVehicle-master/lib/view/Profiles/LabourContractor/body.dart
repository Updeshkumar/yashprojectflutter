// import 'package:asiayai_heavy_vehicle_app/view/Profiles/LabourContractor/labour_stepper.dart';
// import 'package:flutter/material.dart';

// import '../../../utils/colour_resource.dart';
// import '../../../utils/text_styles.dart';

// class LabourRegister extends StatelessWidget {
//   const LabourRegister({super.key});

//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;
//     return Scaffold(
//       backgroundColor: Colours.PRIMARY_BLUE,
//       appBar: PreferredSize(
//         preferredSize: Size.fromHeight(size.height / 16),
//         child: AppBar(
//           title: Text(
//             "Labour Register",
//             style: TextStyles.ktext20(context),
//           ),
//           backgroundColor: Colours.PRIMARY_GREY,
//         ),
//       ),
//       body: LabouurStepper(),
//     );
//   }
// }
