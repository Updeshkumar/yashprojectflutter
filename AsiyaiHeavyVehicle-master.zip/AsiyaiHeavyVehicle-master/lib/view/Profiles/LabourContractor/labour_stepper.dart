import 'dart:convert';
import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/data/datamodel/labour_cont_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/datamodel/address_model.dart';
import '../../../data/datamodel/post_addre_model.dart';
import '../../../data/datamodel/sub_cont_model.dart';
import '../../../helper/default_image.dart';

import '../../../utils/app_constants.dart';
import '../../../utils/colour_resource.dart';
import '../../../utils/dimensions.dart';
import '../../../utils/images.dart';
import '../../../utils/size_config.dart';
import '../../../utils/text_styles.dart';
import '../../../widgets/app_snack_bar.dart';
import '../../../widgets/show_dialog.dart';
import '../../../widgets/textfield.dart';
import '../../Payment/payment_screen.dart';
import 'package:http/http.dart' as http;

class LabouurStepper extends StatefulWidget {
  const LabouurStepper({super.key});

  @override
  State<LabouurStepper> createState() => _LabouurStepperState();
}

class _LabouurStepperState extends State<LabouurStepper> {
  // variables
  int _currentStep = 0;
  DateTime selectedDate = DateTime.now();
  bool showDate = false;
  File? selectedImage;
  final picker = ImagePicker();
  var globalUrl;
  var selectedState;
  var selectDistrict;
  var selectedTehsil;
  var skilledPerson;
  var unskilledPerson;
  var professionalabour;
  LabourContModel labourContModel = LabourContModel();
  List<AddressModel> districtTempList = <AddressModel>[];
  List<AddressModel> tehsilTempList = <AddressModel>[];
  TextEditingController labourContractorController = TextEditingController();
  TextEditingController labourWorkCOntroller = TextEditingController();
  TextEditingController labourNumberController = TextEditingController();
  TextEditingController aadharCardController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController alternateMobile = TextEditingController();
  TextEditingController emailControler = TextEditingController();

  List<GlobalKey<FormState>> formkey = [
    GlobalKey<FormState>(),
    GlobalKey<FormState>(),
    GlobalKey<FormState>(),
    GlobalKey<FormState>()
  ];

  final _key = GlobalKey<FormState>();
  File? aadharImage1;
  File? aadharImage2;
  String? aadharFront;
  String? aadharBack;
  File? labourFile;
  String? labourImage;
  // steps
  List<Step> getSteps() => [
        Step(
          state: _currentStep > 0 ? StepState.complete : StepState.indexed,
          isActive: _currentStep >= 0,
          title: Text(
            "",
            style: TextStyles.ktext12(context),
          ),
          content: Form(
            key: formkey[0],
            child: Column(
              children: [
                IconTextField(
                  title: "Labour Contractor Name".tr().toString(),
                  controller: labourContractorController,
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Name is Required";
                    }
                  },
                ),
                IconTextField(
                  title: "Labour(In Numbers)".tr().toString(),
                  controller: labourNumberController,
                  textInputType: TextInputType.number,
                  textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return " is Required";
                    }
                  },
                ),
                IconTextField(
                  title: "Labour Work".tr().toString(),
                  controller: labourWorkCOntroller,
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Name is Required";
                    }
                  },
                ),
                Container(
                  margin: const EdgeInsets.only(
                    bottom: 10,
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colours.PRIMARY_BLUE_MILD,
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButtonFormField(
                      dropdownColor: Colors.white,
                      hint: Text(
                        "Skilled Person".tr().toString(),
                        style: TextStyles.ktext16(context)
                            .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
                      ),
                      icon: Container(
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colours.PRIMARY_GREY_LIGHT,
                        ),
                        child: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: Colors.black,
                        ),
                      ),
                      iconSize: 20,
                      isExpanded: true,
                      value: skilledPerson,
                      style: TextStyles.ktext20(context).copyWith(
                          color: Colours.PRIMARY_BLACK,
                          fontWeight: FontWeight.bold),
                      onChanged: (value) {
                        skilledPerson = value;
                      },
                      items: [
                        "10",
                        "50",
                        "100",
                      ].map((e) {
                        return DropdownMenuItem(
                          child: Text(
                            e,
                            style: TextStyle(
                                color: Colours.PRIMARY_GREY_LIGHT,
                                fontSize: 18),
                          ),
                          value: e,
                        );
                      }).toList(),
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(
                    bottom: 10,
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colours.PRIMARY_BLUE_MILD,
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButtonFormField(
                      dropdownColor: Colors.white,
                      hint: Text(
                        "Unskilled Person".tr().toString(),
                        style: TextStyles.ktext16(context)
                            .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
                      ),
                      icon: Container(
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colours.PRIMARY_GREY_LIGHT,
                        ),
                        child: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: Colors.black,
                        ),
                      ),
                      iconSize: 20,
                      isExpanded: true,
                      value: unskilledPerson,
                      onChanged: (value) {
                        unskilledPerson = value;
                      },
                      items: [
                        "10",
                        "50",
                        "100",
                      ].map((e) {
                        return DropdownMenuItem(
                          child: Text(
                            e,
                            style: TextStyle(
                                color: Colours.PRIMARY_GREY_LIGHT,
                                fontSize: 18),
                          ),
                          value: e,
                        );
                      }).toList(),
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(
                    bottom: 10,
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colours.PRIMARY_BLUE_MILD,
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButtonFormField(
                      dropdownColor: Colors.white,
                      hint: Text(
                        "Professional Person".tr().toString(),
                        style: TextStyles.ktext16(context)
                            .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
                      ),
                      icon: Container(
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colours.PRIMARY_GREY_LIGHT,
                        ),
                        child: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: Colors.black,
                        ),
                      ),
                      iconSize: 20,
                      isExpanded: true,
                      value: professionalabour,
                      onChanged: (value) {
                        professionalabour = value;
                      },
                      items: [
                        "10",
                        "50",
                        "100",
                      ].map((e) {
                        return DropdownMenuItem(
                          child: Text(
                            e,
                            style: TextStyle(
                                color: Colours.PRIMARY_GREY_LIGHT,
                                fontSize: 18),
                          ),
                          value: e,
                        );
                      }).toList(),
                    ),
                  ),
                ),
                IconTextField(
                  title: "Mobile Number".tr().toString(),
                  controller: mobileController,
                  textInputType: TextInputType.number,
                  textInputFormatter: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(10),
                  ],
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Mobile Number is Required";
                    } else if (value.length != 10) {
                      return "Enter Valid Mobile Number";
                    }
                  },
                ),
                IconTextField(
                  title: "Alternative Mobile Number".tr().toString(),
                  controller: alternateMobile,
                  textInputType: TextInputType.number,
                  textInputFormatter: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(10),
                  ],
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Mobile Number is Required";
                    } else if (value.length != 10) {
                      return "Enter Valid Mobile Number";
                    }
                  },
                ),
                IconTextField(
                  title: "Email Id".tr().toString(),
                  controller: emailControler,
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Email is Required";
                    }
                  },
                ),
                SizedBox(
                  height: size.height * 0.03,
                )
              ],
            ),
          ),
        ),
        Step(
          state: _currentStep > 1 ? StepState.complete : StepState.indexed,
          isActive: _currentStep >= 1,
          title: Text(""),
          content: Form(
            key: formkey[1],
            child: Column(
              children: [
                // DropDownSDT(),
                SizedBox(
                  height: size.height * 0.4,
                )
              ],
            ),
          ),
        ),
        Step(
          state: _currentStep > 2 ? StepState.complete : StepState.indexed,
          isActive: _currentStep >= 2,
          title: Text(""),
          content: Form(
            key: formkey[2],
            child: Column(
              children: [
                AadharimageView(
                  title: "Aadhar Card(Front Side)",
                  file: aadharImage1 != null ? aadharImage1 : null,
                  onTap: () async {
                    selectedImage == null
                        ? {
                            await getImage(),
                            aadharImage1 = selectedImage,
                            ShowDialogsss().showDialogContainer(context),
                            uploadImage(file: aadharImage1, type: "front")
                                .then((value) {
                              Navigator.pop(context);
                              AppSnackBar.appSnackBar(
                                  context: context,
                                  message: "Image Uploaded",
                                  title: "Upload Image",
                                  isError: false);
                            }),
                            selectedImage = null,
                          }
                        : null;
                  },
                ),
                const SizedBox(
                  height: 10,
                ),
                AadharimageView(
                  title: "Aadhar Card(Back Side)",
                  file: aadharImage2 != null ? aadharImage2 : null,
                  onTap: () async {
                    selectedImage == null
                        ? {
                            await getImage(),
                            aadharImage2 = selectedImage,
                            ShowDialogsss().showDialogContainer(context),
                            uploadImage(file: aadharImage2, type: "back")
                                .then((value) {
                              Navigator.pop(context);
                              AppSnackBar.appSnackBar(
                                  context: context,
                                  message: "Image Uploaded",
                                  title: "Upload Image",
                                  isError: false);
                            }),
                            selectedImage = null,
                          }
                        : null;
                  },
                ),
                SizedBox(
                  height: size.height * 0.2,
                )
              ],
            ),

            //  SizedBox(
            //     height: size.height * 0.6, child: buildGridView(size))
          ),
        ),
        Step(
          state: _currentStep > 3 ? StepState.complete : StepState.indexed,
          isActive: _currentStep >= 3,
          title: Text(""),
          content: Form(
            key: formkey[3],
            child: Column(
              children: [
                AadharimageView(
                  title: "Labour Image",
                  file: labourFile != null ? labourFile : null,
                  onTap: () async {
                    selectedImage == null
                        ? {
                            await getImage(),
                            labourFile = selectedImage,
                            ShowDialogsss().showDialogContainer(context),
                            uploadImage(file: labourFile, type: "labour")
                                .then((value) {
                              Navigator.pop(context);
                              AppSnackBar.appSnackBar(
                                  context: context,
                                  message: "Image Uploaded",
                                  title: "Upload Image",
                                  isError: false);
                            }),
                            selectedImage = null,
                          }
                        : null;
                  },
                ),
                SizedBox(
                  height: size.height * 0.35,
                )
              ],
            ),
          ),
        )
      ];
  //
  Future getImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        selectedImage = File(pickedFile.path);
      } else {
        print("No Image selected");
      }
    });
  }

//
  List<String> imageList = [];
  Future<void> uploadImage({File? file, String? type}) async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    String? token = sharedPreferences.getString(AppConstants.USER_TOKEN);
    try {
      var request = http.MultipartRequest("POST",
          Uri.parse('http://devapi.asiyaiheavyvehicle.com/v1/uploadFile'));

      request.headers.addAll({"Authorization": token!});

      var pic = await http.MultipartFile.fromPath(
        "file",
        file!.path,
      );

      request.files.add(pic);

      var response = await request.send();

      var responsed = await http.Response.fromStream(response);
      final reponseData = json.decode(responsed.body);

      if (response.statusCode == 200) {
        print("Success");
        print(reponseData);
        if (type == "front") {
          aadharFront = reponseData["image_url"];
          print("Aadhar front >>> " + aadharFront.toString());
        } else if (type == "back") {
          aadharBack = reponseData["image_url"];
          print("Aadhar back >>> " + aadharBack.toString());
        } else if (type == "labour") {
          labourImage = reponseData["image_url"];
          print("Labour Image >>> " + labourImage.toString());
        }
        globalUrl = reponseData["image_url"];
        imageList.add(globalUrl.toString());
        print("Image List >>> " + imageList.length.toString());
        print("image path" + globalUrl);
      } else {
        print("error");
      }
    } catch (e) {
      print(e);
    }
  }

  // widgets
  // Widget DropDownSDT() {
  //   return Consumer<AddressProvider>(
  //       builder: (context, addressProvider, child) {
  //     return Column(
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       children: [
  //         Container(
  //           margin: const EdgeInsets.only(
  //             bottom: 10,
  //           ),
  //           padding: const EdgeInsets.symmetric(horizontal: 20),
  //           decoration: BoxDecoration(
  //             borderRadius: BorderRadius.circular(8),
  //             color: Colours.PRIMARY_BLUE_MILD,
  //           ),
  //           child: DropdownButtonHideUnderline(
  //             child: DropdownButtonFormField(
  //               dropdownColor: Colors.white,
  //               hint: Text(
  //                 "Select State".tr().toString(),
  //                 style: TextStyles.ktext16(context)
  //                     .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
  //               ),
  //               icon: Container(
  //                 decoration: const BoxDecoration(
  //                   shape: BoxShape.circle,
  //                   color: Colours.PRIMARY_GREY_LIGHT,
  //                 ),
  //                 child: const Icon(
  //                   Icons.keyboard_arrow_down_rounded,
  //                   color: Colors.black,
  //                 ),
  //               ),
  //               iconSize: 20,
  //               isExpanded: true,
  //               value: selectedState,
  //               style: TextStyles.ktext20(context).copyWith(
  //                   color: Colours.PRIMARY_BLACK, fontWeight: FontWeight.bold),
  //               onChanged: (value) {
  //                 setState(() {
  //                   print(value);
  //                   selectDistrict = null;
  //                   selectedState = value;

  //                   ////
  //                   districtTempList = addressProvider.districtList
  //                       .where(
  //                         (element) =>
  //                             element.relatedToId.toString() ==
  //                             selectedState.toString(),
  //                       )
  //                       .toList();
  //                 });
  //               },
  //               validator: ((value) {
  //                 if (value == null) {
  //                   return "State Required";
  //                 }
  //               }),
  //               items: addressProvider.stateList.map((sts) {
  //                 return DropdownMenuItem<String>(
  //                   value: sts.id.toString(),
  //                   child: Text(
  //                     sts.valueName.toString(),
  //                     style: TextStyles.ktext16(context).copyWith(
  //                         color: Colours.PRIMARY_GREY_LIGHT,
  //                         fontWeight: FontWeight.w500),
  //                   ),
  //                 );
  //               }).toList(),
  //             ),
  //           ),
  //         ),

  //         //
  //         Container(
  //           margin: const EdgeInsets.only(
  //             bottom: 10,
  //           ),
  //           padding: const EdgeInsets.symmetric(horizontal: 20),
  //           decoration: BoxDecoration(
  //             borderRadius: BorderRadius.circular(8),
  //             color: Colours.PRIMARY_BLUE_MILD,
  //           ),
  //           child: DropdownButtonHideUnderline(
  //             child: DropdownButtonFormField(
  //               dropdownColor: Colors.white,
  //               hint: Text(
  //                 "Select District".tr().toString(),
  //                 style: TextStyles.ktext16(context)
  //                     .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
  //               ),
  //               icon: Container(
  //                 decoration: const BoxDecoration(
  //                   shape: BoxShape.circle,
  //                   color: Colours.PRIMARY_GREY_LIGHT,
  //                 ),
  //                 child: const Icon(
  //                   Icons.keyboard_arrow_down_rounded,
  //                   color: Colors.black,
  //                 ),
  //               ),
  //               iconSize: 20,
  //               isExpanded: true,
  //               value: selectDistrict,
  //               style: TextStyles.ktext20(context).copyWith(
  //                   color: Colours.PRIMARY_BLACK, fontWeight: FontWeight.bold),
  //               onChanged: (value) {
  //                 setState(() {
  //                   print(value);
  //                   selectedTehsil = null;
  //                   selectDistrict = value;
  //                   tehsilTempList = addressProvider.tehsilList
  //                       .where(
  //                         (element) =>
  //                             element.relatedToId.toString() ==
  //                             selectDistrict.toString(),
  //                       )
  //                       .toList();
  //                 });
  //               },
  //               validator: ((value) {
  //                 if (value == null) {
  //                   return "District Required";
  //                 }
  //               }),
  //               items: districtTempList.map((sts) {
  //                 return DropdownMenuItem<String>(
  //                   value: sts.id.toString(),
  //                   child: Text(
  //                     sts.valueName.toString(),
  //                     style: TextStyles.ktext16(context).copyWith(
  //                         color: Colours.PRIMARY_GREY_LIGHT,
  //                         fontWeight: FontWeight.w500),
  //                   ),
  //                 );
  //               }).toList(),
  //             ),
  //           ),
  //         ),

  //         //
  //         Container(
  //           margin: const EdgeInsets.only(
  //             bottom: 10,
  //           ),
  //           padding: const EdgeInsets.symmetric(horizontal: 20),
  //           decoration: BoxDecoration(
  //             borderRadius: BorderRadius.circular(8),
  //             color: Colours.PRIMARY_BLUE_MILD,
  //           ),
  //           child: DropdownButtonHideUnderline(
  //             child: DropdownButtonFormField(
  //               dropdownColor: Colors.white,
  //               hint: Text(
  //                 "Select Tehsil".tr().toString(),
  //                 style: TextStyles.ktext16(context)
  //                     .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
  //               ),
  //               icon: Container(
  //                 decoration: const BoxDecoration(
  //                   shape: BoxShape.circle,
  //                   color: Colours.PRIMARY_GREY_LIGHT,
  //                 ),
  //                 child: const Icon(
  //                   Icons.keyboard_arrow_down_rounded,
  //                   color: Colors.black,
  //                 ),
  //               ),
  //               iconSize: 20,
  //               isExpanded: true,
  //               value: selectedTehsil,
  //               style: TextStyles.ktext20(context).copyWith(
  //                   color: Colours.PRIMARY_BLACK, fontWeight: FontWeight.bold),
  //               onChanged: (value) {
  //                 setState(() {
  //                   print(value);
  //                   selectedTehsil = value;
  //                 });
  //               },
  //               validator: ((value) {
  //                 if (value == null) {
  //                   return "Tehsil Required";
  //                 }
  //               }),
  //               items: tehsilTempList.map((sts) {
  //                 return DropdownMenuItem<String>(
  //                   value: sts.id.toString(),
  //                   child: Text(
  //                     sts.valueName.toString(),
  //                     style: TextStyles.ktext16(context).copyWith(
  //                         color: Colours.PRIMARY_GREY_LIGHT,
  //                         fontWeight: FontWeight.w500),
  //                   ),
  //                 );
  //               }).toList(),
  //             ),
  //           ),
  //         )
  //       ],
  //     );
  //   });
  // }

  //
  Widget AadharimageView({String? title, VoidCallback? onTap, File? file}) {
    return GestureDetector(
      onTap: onTap,
      child: file != null
          ? Container(
              height: size.height * 0.2,
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Colours.PRIMARY_BLUE_MILD,
                  borderRadius: BorderRadius.circular(12),
                  border:
                      Border.all(color: Colours.PRIMARY_GREY_LIGHT, width: 2),
                  image: DecorationImage(
                    image: FileImage(file),
                    fit: BoxFit.fill,
                    opacity: 0.4,
                  )),
            )
          : ImageUploader()
              .defaultImageContainer(Images.docs_icon, context, title: title),
    );
  }

  //
  @override
  void initState() {
    // TODO: implement initState
    // Provider.of<AddressProvider>(context, listen: false).getStateList(context);
    // Provider.of<AddressProvider>(context, listen: false)
    //     .getDistrictList(context);
    // Provider.of<AddressProvider>(context, listen: false).getTehsilList(context);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Consumer<UserProvider>(builder: (context, model, child) {
      return Form(
        key: _key,
        child: Theme(
          data: ThemeData(
            canvasColor: Colors.transparent,
            colorScheme: Theme.of(context)
                .colorScheme
                .copyWith(primary: Colours.YELLOW_LIGHT),
          ),
          child: Stepper(
            elevation: 0.0,
            currentStep: _currentStep,
            type: StepperType.horizontal,
            steps: getSteps(),
            onStepContinue: () async {
              final isLastStep = _currentStep == getSteps().length - 1;
              if (isLastStep) {
                // labourContModel = LabourContModel(
                //   labourcontractorname: labourContractorController.text,
                //   labourImage: labourImage.toString(),
                //   labourwork: labourWorkCOntroller.text,
                //   lobourinnumber: labourNumberController.text,
                //   mobileNumber: int.parse(mobileController.text),
                //   alternativemobilenumber: alternateMobile.text,
                //   aadharback: aadharBack,
                //   aadharfront: aadharFront,
                //   emailId: emailControler.text,
                //   skilledLabour: int.parse(skilledPerson),
                //   unskiledLabour: int.parse(unskilledPerson),
                //   proffesionalLabour: int.parse(professionalabour),
                // );
                if (labourImage != null) {
                  ShowDialogsss().showDialogContainer(context);
                  // model.postLabour(context, obj: labourContModel);
                  /*   registerProvider
                      .postSubContrReg(subContModel, context)
                      .then((value) {
                    value
                        ? Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PaymentScreen()))
                        : AppSnackBar.appSnackBar(
                            context: context,
                            message: "Please try again",
                            title: "Exception",
                            isError: true);
                  });*/
                } else {
                  AppSnackBar.appSnackBar(
                      context: context,
                      message: "Please Upload Image",
                      title: "Upload Image",
                      isError: true);
                }
              } else {
                switch (_currentStep) {
                  case 0:
                    if (formkey[0].currentState!.validate()) {
                      setState(() {
                        _currentStep += 1;
                      });
                    }
                    break;
                  case 1:
                    if (formkey[1].currentState!.validate()) {
                      PostAddressModel postAddressModel = PostAddressModel(
                        stateId: int.parse(selectedState),
                        districtId: int.parse(selectDistrict),
                        cityId: int.parse(selectedTehsil),
                        countryId: 1,
                      );
                      // await model
                      //     .postAddress(context, postAddressModel)
                      //     .then((value) {
                      //   value ? _currentStep += 1 : "";
                      // });
                      /*  postAddressProvider
                        .postAddress(postAddressModel, context)
                        .then((value) {
                      setState(() {
                        _currentStep += 1;
                      });
                    });*/
                    }

                    break;
                  case 2:
                    if (aadharFront != null && aadharBack != null) {
                      print("Yess");
                      setState(() {
                        _currentStep += 1;
                      });
                    } else {
                      showTostMsg("PLease Selecte Aadhar Images");
                    }
                    break;
                  default:
                }
              }
            },
            onStepTapped: (value) {
              setState(() {
                _currentStep = value;
              });
            },

            //
            controlsBuilder: (context, details) {
              return GestureDetector(
                onTap: details.onStepContinue,
                child: Container(
                  height: Dimensions.DEAFULAT_BUTTON_SIZE,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colours.YELLOW_LIGHT,
                  ),
                  child: Center(
                    child: _currentStep == 2
                        ? Text(
                            "Submit".tr().toString(),
                            style: TextStyles.ktext14(context)
                                .copyWith(color: Colors.black),
                          )
                        : Text(
                            "Next".tr().toString(),
                            style: TextStyles.ktext14(context)
                                .copyWith(color: Colors.black),
                          ),
                  ),
                ),
              );
            },
          ),
        ),
      );
    });
  }
}
