import 'dart:convert';
import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/data/datamodel/sub_cont_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/datamodel/address_model.dart';
import '../../../data/datamodel/post_addre_model.dart';
import '../../../helper/default_image.dart';

import '../../../utils/app_constants.dart';
import '../../../utils/colour_resource.dart';
import '../../../utils/dimensions.dart';
import '../../../utils/images.dart';
import '../../../utils/size_config.dart';
import '../../../utils/text_styles.dart';
import '../../../widgets/app_snack_bar.dart';
import '../../../widgets/show_dialog.dart';
import '../../../widgets/textfield.dart';
import '../../Payment/payment_screen.dart';
import 'package:http/http.dart' as http;

class SubStepper extends StatefulWidget {
  const SubStepper({super.key});

  @override
  State<SubStepper> createState() => _SubStepperState();
}

class _SubStepperState extends State<SubStepper> {
  // var
  int _currentStep = 0;
  DateTime selectedDate = DateTime.now();
  bool showDate = false;
  File? selectedImage;
  final picker = ImagePicker();
  var globalUrl;
  var selectedState;
  var selectDistrict;
  var selectedTehsil;
  SubContModel subContModel = SubContModel();
  List<AddressModel> districtTempList = <AddressModel>[];
  List<AddressModel> tehsilTempList = <AddressModel>[];
  TextEditingController nameController = TextEditingController();
  TextEditingController _firmNameController = TextEditingController();
  TextEditingController _experienceController = TextEditingController();
  TextEditingController _licenceController = TextEditingController();
  TextEditingController aadharController = TextEditingController();
  TextEditingController workType = TextEditingController();
  TextEditingController mobileNumber = TextEditingController();
  TextEditingController emailController = TextEditingController();

  List<GlobalKey<FormState>> formkey = [
    GlobalKey<FormState>(),
    GlobalKey<FormState>(),
    GlobalKey<FormState>(),
    GlobalKey<FormState>()
  ];

  final _key = GlobalKey<FormState>();
  File? selectImage1;
  File? selectImage2;
  File? selectImage3;
  File? selectImage4;
  File? aadharImage1;
  File? aadharImage2;
  String? aadharFront;
  String? aadharBack;
  //
  Future getImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        selectedImage = File(pickedFile.path);
      } else {
        print("No Image selected");
      }
    });
  }

//
  List<String> imageList = [];
  Future<void> uploadImage({File? file, String? type}) async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    String? token = sharedPreferences.getString(AppConstants.USER_TOKEN);
    try {
      var request = http.MultipartRequest("POST",
          Uri.parse('http://devapi.asiyaiheavyvehicle.com/v1/uploadFile'));

      request.headers.addAll({"Authorization": token!});

      var pic = await http.MultipartFile.fromPath(
        "file",
        file!.path,
      );

      request.files.add(pic);

      var response = await request.send();

      var responsed = await http.Response.fromStream(response);
      final reponseData = json.decode(responsed.body);

      if (response.statusCode == 200) {
        print("Success");
        print(reponseData);
        if (type == "front") {
          aadharFront = reponseData["image_url"];
          print("AAdhar Front >>> " + aadharFront.toString());
        } else if (type == "back") {
          aadharBack = reponseData["image_url"];
          print("AAdhar Back >>> " + aadharBack.toString());
        } else {
          globalUrl = reponseData["image_url"];

          imageList.add(globalUrl.toString());
          print("Images Length >>>>>>>> " + imageList.length.toString());
        }

        // print("image path" + globalUrl);

        // print("image path" + globalUrl);
      } else {
        print("error");
      }
    } catch (e) {
      print(e);
    }
  }

  //widgets

  //
  Widget AadharimageView({String? title, VoidCallback? onTap, File? file}) {
    return GestureDetector(
      onTap: onTap,
      child: file != null
          ? Container(
              height: size.height * 0.2,
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Colours.PRIMARY_BLUE_MILD,
                  borderRadius: BorderRadius.circular(12),
                  border:
                      Border.all(color: Colours.PRIMARY_GREY_LIGHT, width: 2),
                  image: DecorationImage(
                    image: FileImage(file),
                    fit: BoxFit.fill,
                    opacity: 0.4,
                  )),
            )
          : ImageUploader()
              .defaultImageContainer(Images.docs_icon, context, title: title),
    );
  }

  //steps
  List<Step> getSteps() => [
        Step(
          state: _currentStep > 0 ? StepState.complete : StepState.indexed,
          isActive: _currentStep >= 0,
          title: Text(
            "",
            style: TextStyles.ktext12(context),
          ),
          content: Form(
            key: formkey[0],
            child: Column(
              children: [
                IconTextField(
                  title: "Contractor Name".tr().toString(),
                  controller: nameController,
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Name is Required";
                    }
                  },
                ),
                IconTextField(
                  title: "Firm Name".tr().toString(),
                  controller: _firmNameController,
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return " Firm Name is Required";
                    }
                  },
                ),
                IconTextField(
                  title: "Type of Work".tr().toString(),
                  controller: workType,
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Required";
                    }
                  },
                ),
                IconTextField(
                  title: "Experience(In Year)".tr().toString(),
                  controller: _experienceController,
                  textInputType: TextInputType.number,
                  textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Experience is Required";
                    }
                  },
                ),
                IconTextField(
                  title: "License Number".tr().toString(),
                  controller: _licenceController,
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "License Number is Required";
                    }
                  },
                ),
                IconTextField(
                  title: "Mobile Number".tr().toString(),
                  controller: mobileNumber,
                  textInputType: TextInputType.number,
                  textInputFormatter: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(10),
                  ],
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Mobile Number is Required";
                    } else if (value.length != 10) {
                      return "Enter Valid Mobile Number";
                    }
                  },
                ),
                IconTextField(
                  title: "Email Id".tr().toString(),
                  controller: emailController,
                  onValidate: (value) {
                    if (value == null || value.isEmpty) {
                      return "Email is Required";
                    }
                  },
                ),
                SizedBox(
                  height: size.height / 10,
                )
              ],
            ),
          ),
        ),
        Step(
          state: _currentStep > 1 ? StepState.complete : StepState.indexed,
          isActive: _currentStep >= 1,
          title: Text(""),
          content: Form(
            key: formkey[1],
            child: Column(
              children: [
                //  DropDownSDT(),
                SizedBox(
                  height: size.height * 0.4,
                )
              ],
            ),
          ),
        ),
        Step(
          state: _currentStep > 2 ? StepState.complete : StepState.indexed,
          isActive: _currentStep >= 2,
          title: Text(""),
          content: Form(
            key: formkey[2],
            child: Column(
              children: [
                AadharimageView(
                  title: "Aadhar Card(Front Side)",
                  file: aadharImage1 != null ? aadharImage1 : null,
                  onTap: () async {
                    selectedImage == null
                        ? {
                            await getImage(),
                            aadharImage1 = selectedImage,
                            ShowDialogsss().showDialogContainer(context),
                            uploadImage(file: aadharImage1, type: "front")
                                .then((value) {
                              Navigator.pop(context);
                              AppSnackBar.appSnackBar(
                                  context: context,
                                  message: "Image Uploaded",
                                  title: "Upload Image",
                                  isError: false);
                            }),
                            selectedImage = null,
                          }
                        : null;
                  },
                ),
                const SizedBox(
                  height: 10,
                ),
                AadharimageView(
                  title: "Aadhar Card(Back Side)",
                  file: aadharImage2 != null ? aadharImage2 : null,
                  onTap: () async {
                    selectedImage == null
                        ? {
                            await getImage(),
                            aadharImage2 = selectedImage,
                            ShowDialogsss().showDialogContainer(context),
                            uploadImage(file: aadharImage2, type: "back")
                                .then((value) {
                              Navigator.pop(context);
                              AppSnackBar.appSnackBar(
                                  context: context,
                                  message: "Image Uploaded",
                                  title: "Upload Image",
                                  isError: false);
                            }),
                            selectedImage = null,
                          }
                        : null;
                  },
                ),
                SizedBox(
                  height: size.height * 0.2,
                )
              ],
            ),

            //  SizedBox(
            //     height: size.height * 0.6, child: buildGridView(size))
          ),
        ),
        Step(
          state: _currentStep > 3 ? StepState.complete : StepState.indexed,
          isActive: _currentStep >= 3,
          title: Text(""),
          content: Form(
            key: formkey[3],
            child: Column(
              children: [
                Row(children: [
                  Expanded(
                      child: AadharimageView(
                    title: "Site Image",
                    file: selectImage1 != null ? selectImage1 : null,
                    onTap: () async {
                      selectedImage == null
                          ? {
                              await getImage(),
                              selectImage1 = selectedImage,
                              ShowDialogsss().showDialogContainer(context),
                              uploadImage(file: selectImage1, type: "yes")
                                  .then((value) {
                                Navigator.pop(context);
                                AppSnackBar.appSnackBar(
                                    context: context,
                                    message: "Image Uploaded",
                                    title: "Upload Image",
                                    isError: false);
                              }),
                              selectedImage = null,
                            }
                          : null;
                    },
                  )),
                  const SizedBox(
                    width: 5,
                  ),
                  Expanded(
                      child: AadharimageView(
                    title: "Site Image",
                    file: selectImage2 != null ? selectImage2 : null,
                    onTap: () async {
                      selectedImage == null
                          ? {
                              await getImage(),
                              selectImage2 = selectedImage,
                              ShowDialogsss().showDialogContainer(context),
                              uploadImage(file: selectImage2, type: "yes")
                                  .then((value) {
                                Navigator.pop(context);
                                AppSnackBar.appSnackBar(
                                    context: context,
                                    message: "Image Uploaded",
                                    title: "Upload Image",
                                    isError: false);
                              }),
                              selectedImage = null,
                            }
                          : null;
                    },
                  )),
                ]),
                const SizedBox(
                  height: 10,
                ),
                Row(children: [
                  Expanded(
                      child: AadharimageView(
                    title: "Site Image",
                    file: selectImage3 != null ? selectImage3 : null,
                    onTap: () async {
                      selectedImage == null
                          ? {
                              await getImage(),
                              selectImage3 = selectedImage,
                              ShowDialogsss().showDialogContainer(context),
                              uploadImage(file: selectImage3, type: "yes")
                                  .then((value) {
                                Navigator.pop(context);
                                AppSnackBar.appSnackBar(
                                    context: context,
                                    message: "Image Uploaded",
                                    title: "Upload Image",
                                    isError: false);
                              }),
                              selectedImage = null,
                            }
                          : null;
                    },
                  )),
                  const SizedBox(
                    width: 5,
                  ),
                  Expanded(
                      child: AadharimageView(
                    title: "Site Image",
                    file: selectImage4 != null ? selectImage4 : null,
                    onTap: () async {
                      selectedImage == null
                          ? {
                              await getImage(),
                              selectImage4 = selectedImage,
                              ShowDialogsss().showDialogContainer(context),
                              uploadImage(file: selectImage4, type: "yes")
                                  .then((value) {
                                Navigator.pop(context);
                                AppSnackBar.appSnackBar(
                                    context: context,
                                    message: "Image Uploaded",
                                    title: "Upload Image",
                                    isError: false);
                              }),
                              selectedImage = null,
                            }
                          : null;
                    },
                  )),
                ]),
                SizedBox(
                  height: size.height * 0.3,
                )
              ],
            ),

            //  SizedBox(
            //     height: size.height * 0.6, child: buildGridView(size))
          ),
        )
      ];

  //states
  @override
  void initState() {
    // TODO: implement initState
    // Provider.of<AddressProvider>(context, listen: false).getStateList(context);
    // Provider.of<AddressProvider>(context, listen: false)
    //     .getDistrictList(context);
    // Provider.of<AddressProvider>(context, listen: false).getTehsilList(context);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Consumer<UserProvider>(builder: (context, model, child) {
      return Form(
        key: _key,
        child: Theme(
          data: ThemeData(
            canvasColor: Colors.transparent,
            colorScheme: Theme.of(context)
                .colorScheme
                .copyWith(primary: Colours.YELLOW_LIGHT),
          ),
          child: Stepper(
            elevation: 0.0,
            currentStep: _currentStep,
            type: StepperType.horizontal,
            steps: getSteps(),
            onStepContinue: () {
              final isLastStep = _currentStep == getSteps().length - 1;
              if (isLastStep) {
                // subContModel = SubContModel(
                //     contractorname: nameController.text,
                //     firmname: _firmNameController.text,
                //     expriencesinyear: int.parse(_experienceController.text),
                //     licenseNumber: _licenceController.text,
                //     subcontractorImage: imageList[0],
                //     subcontractor_image_back: imageList[1],
                //     subcontractor_image_left: imageList[2],
                //     subcontractor_image_right: imageList[3],
                //     mobileNumber: mobileNumber.text,
                //     typeofWork: workType.text,
                //     aadharBack: aadharBack,
                //     aadharFront: aadharFront,
                //     emailId: emailController.text);
                if (globalUrl != null) {
                  ShowDialogsss().showDialogContainer(context);
                  // model.postSubContructor(context, obj: subContModel);
                  /*  registerProvider
                    .postSubContrReg(subContModel, context)
                    .then((value) {
                  value
                      ? Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PaymentScreen()))
                      : AppSnackBar.appSnackBar(
                          context: context,
                          message: "Please try again",
                          title: "Exception",
                          isError: true);
                }); */
                } else {
                  AppSnackBar.appSnackBar(
                      context: context,
                      message: "Please Upload Image",
                      title: "Upload Image",
                      isError: true);
                }
              } else {
                switch (_currentStep) {
                  case 0:
                    if (formkey[0].currentState!.validate()) {
                      setState(() {
                        _currentStep += 1;
                      });
                    }
                    break;
                  case 1:
                    if (formkey[1].currentState!.validate()) {
                      PostAddressModel postAddressModel = PostAddressModel(
                        stateId: int.parse(selectedState),
                        districtId: int.parse(selectDistrict),
                        cityId: int.parse(selectedTehsil),
                        countryId: 1,
                      );
                      // model
                      //     .postAddress(context, postAddressModel)
                      //     .then((value) {
                      //   value ? _currentStep += 1 : "";
                      // });
                      /*  postAddressProvider
                          .postAddress(postAddressModel, context)
                          .then((value) {
                        setState(() {
                          _currentStep += 1;
                        });
                      }); */
                    }

                    break;
                  case 2:
                    if (aadharFront != null && aadharBack != null) {
                      print("Yess");
                      setState(() {
                        _currentStep += 1;
                      });
                    } else {
                      showTostMsg("PLease Selecte Aadhar Images");
                    }
                    break;
                  default:
                }
              }
            },
            onStepTapped: (value) {
              setState(() {
                _currentStep = value;
              });
            },

            //
            controlsBuilder: (context, details) {
              return GestureDetector(
                onTap: details.onStepContinue,
                child: Container(
                  height: Dimensions.DEAFULAT_BUTTON_SIZE,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colours.YELLOW_LIGHT,
                  ),
                  child: Center(
                    child: _currentStep == 2
                        ? Text(
                            "Submit".tr().toString(),
                            style: TextStyles.ktext14(context)
                                .copyWith(color: Colors.black),
                          )
                        : Text(
                            "Next".tr().toString(),
                            style: TextStyles.ktext14(context)
                                .copyWith(color: Colors.black),
                          ),
                  ),
                ),
              );
            },
          ),
        ),
      );
    });
  }
}
