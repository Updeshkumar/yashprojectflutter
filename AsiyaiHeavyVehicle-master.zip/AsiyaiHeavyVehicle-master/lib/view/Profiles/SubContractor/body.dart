import 'package:asiayai_heavy_vehicle_app/view/Profiles/SubContractor/sub_steeper.dart';
import 'package:flutter/material.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';

class SubContractorRegister extends StatelessWidget {
  const SubContractorRegister({super.key});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(size.height / 16),
        child: AppBar(
          title: Text(
            "SubContractor Register",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
        ),
      ),
      body: SubStepper(),
    );
  }
}
