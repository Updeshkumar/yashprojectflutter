import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/app_constants.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Account/account_information.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Category/body.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Notifications/body.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Requirement/body.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/bottoms_nav_bar.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/driver_edit_screens.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/edit_vehicle/total_vehicle.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/labour_edit_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/sub_edit_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/edit_vehicle/vehicle_edit_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/SigunUp/signup_page.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NavDrawer extends StatefulWidget {
  String? userType;
  NavDrawer({this.userType});
  _NavDrawerState createState() => _NavDrawerState();
}

class _NavDrawerState extends State<NavDrawer> {
  @override
  void initState() {
    // TODO: implement initState

    super.initState();
  }

  Size? _size;

  bool? subMenu = false;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Stack(
        children: [
          Container(
            width: _size!.width * 0.7,
            decoration: const BoxDecoration(
                color: Colours.PRIMARY_BLUE,
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(50),
                    bottomRight: Radius.circular(50)),
                gradient: LinearGradient(colors: [
                  Colours.PRIMARY_BLUE,
                  Colours.PRIMARY_BLUE,
                  Colours.PRIMARY_BLUE_MILD
                ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
            child: ListView(
// Important: Remove any padding from the ListView.
              padding: EdgeInsets.zero,
              children: <Widget>[
                SizedBox(
                  height: _size!.height * 0.04,
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  child: Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(3),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.black12,
                                  blurRadius: 2,
                                  spreadRadius: 2,
                                  offset: Offset(2, 3)),
                            ]),
                        child: CircleAvatar(
                            radius: 30,
                            backgroundColor: Colors.white,
                            backgroundImage: AssetImage(
                              Images.another_person_icon,
                            )),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Expanded(
                        child: Container(
                          height: _size!.height * 0.1,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                widget.userType != null
                                    ? widget.userType!.toUpperCase()
                                    : "",
                                style: new TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(
                                height: 3,
                              ),
                              Text(
                                model.userName != null
                                    ? model.userName!.toUpperCase()
                                    : "",
                                style: new TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(
                                height: 3,
                              ),
                              Text(
                                model.userPhone != null
                                    ? model.userPhone!.toUpperCase()
                                    : "",
                                style: new TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          if (widget.userType!
                              .toLowerCase()
                              .contains("driver")) {
                            Navigator.push(
                                context,
                                PageTransition(
                                    child: DriverEditScreens(),
                                    type: PageTransitionType.rightToLeft));
                          }
                          if (widget.userType!
                              .toLowerCase()
                              .contains("vehicle")) {
                            Navigator.push(
                                context,
                                PageTransition(
                                    child: AllEditVehicle(),
                                    type: PageTransitionType.rightToLeft));
                          }
                          if (widget.userType!
                              .toLowerCase()
                              .contains("labour")) {
                            Navigator.push(
                                context,
                                PageTransition(
                                    child: EditLabourScreen(),
                                    type: PageTransitionType.rightToLeft));
                          }
                          if (widget.userType!.toLowerCase().contains("sub")) {
                            Navigator.push(
                                context,
                                PageTransition(
                                    child: SubEditScreen(),
                                    type: PageTransitionType.rightToLeft));
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white),
                          ),
                          child: Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                Divider(),
                ListTile(
                  title: Text(
                    "Home",
                    style: TextStyles.ktext18(context),
                  ),
                  leading: const Icon(
                    Icons.home,
                    color: Colours.YELLOW_LIGHT,
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => BottomNavBar(0)));
                  },
                ),
                ListTile(
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CategoryScreen()));
                  },
                  title: Text(
                    "Categories",
                    style: TextStyles.ktext18(context),
                  ),
                  leading: const Icon(
                    Icons.category,
                    color: Colours.YELLOW_LIGHT,
                  ),
                ),
                ListTile(
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => RequirmentScreen()));
                  },
                  title: Text(
                    "Requirements",
                    style: TextStyles.ktext18(context),
                  ),
                  leading: const Icon(
                    Icons.dashboard_customize_outlined,
                    color: Colours.YELLOW_LIGHT,
                  ),
                ),
                /*    ListTile(
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => NotificationsScreen()));
                  },
                  title: Text(
                    "Notifications",
                    style: TextStyles.ktext18(context),
                  ),
                  leading: const Icon(
                    Icons.notification_add,
                    color: Colours.YELLOW_LIGHT,
                  ),
                ),*/
                ListTile(
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => AccountSettings()));
                  },
                  title: Text(
                    "Account",
                    style: TextStyles.ktext18(context),
                  ),
                  leading: const Icon(
                    Icons.account_box,
                    color: Colours.YELLOW_LIGHT,
                  ),
                ),
                Divider(),
              ],
            ),
          ),
          Positioned(
            bottom: 0,
            right: 0,
            child: InkWell(
              onTap: () async {
                logOut();
              },
              child: Container(
                height: 100,
                width: 100,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(50)),
                child: Center(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text(
                      "Logout ",
                      style: TextStyle(fontSize: 18),
                    ),
                    Icon(
                      Icons.logout,
                      color: Colors.black,
                      size: 18,
                    ),
                  ],
                )),
              ),
            ),
          ),
        ],
      );
    });
  }

  openSubMenu(val) {
    setState(() {
      subMenu = val;
    });
  }

  logOut() async {
    SharedPreferences myPrefs = await SharedPreferences.getInstance();
    await myPrefs.remove(AppConstants.USER_TOKEN);
    Navigator.push(context, MaterialPageRoute(builder: (context) => SignUp()));
  }
}
