import 'package:asiayai_heavy_vehicle_app/data/respnse/requirement_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';

class RequirementTile extends StatefulWidget {
  Requiremnts? obj;

  RequirementTile({this.obj});
  @override
  State<RequirementTile> createState() => _RequirementTileState();
}

class _RequirementTileState extends State<RequirementTile> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Container(
        margin: EdgeInsets.only(top: size.height / 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 200,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage("http://asiyaiheavyvehicle.com" +
                      widget.obj!.requirementImage!),
                  fit: BoxFit.fill,
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              widget.obj!.title!,
              style: TextStyles.ktext18(context),
            ),
            SizedBox(
              height: size.height / 60,
            ),
            Text(
              "Desription :",
              style: TextStyles.ktext14(context),
            ),
            SizedBox(
              height: size.height / 160,
            ),
            Text(
              widget.obj!.description!,
              style: TextStyles.ktext12(context),
            ),
            SizedBox(
              height: size.height / 40,
            ),
            Row(
              children: [
                widget.obj!.acceptedRequirement!.status == true
                    ? GestureDetector(
                        onTap: () {
                          showTostMsg("Already Requested");
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: size.width / 18,
                              vertical: size.height / 100),
                          decoration: BoxDecoration(
                            color: Colours.SKY_BLUE_LIGHT,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Center(
                            child: Text(
                              "REQUESTED",
                              style: TextStyles.ktext16(context).copyWith(
                                color: Colours.PRIMARY_BLACK,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      )
                    : GestureDetector(
                        onTap: () {
                          model.postRequirementAPI(context,
                              req_id: widget.obj!.id!.toString());
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: size.width / 18,
                              vertical: size.height / 100),
                          decoration: BoxDecoration(
                            color: Colours.YELLOW_DARK,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Center(
                            child: Text(
                              "REQUEST",
                              style: TextStyles.ktext16(context).copyWith(
                                color: Colours.PRIMARY_BLACK,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                SizedBox(
                  width: size.width / 24,
                ),
                /*  Container(
                  padding: EdgeInsets.symmetric(
                      horizontal: size.width / 18, vertical: size.height / 100),
                  decoration: BoxDecoration(
                    color: Colours.PRIMARY_BLUE_MILD,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    "CANCEL",
                    style: TextStyles.ktext16(context),
                    textAlign: TextAlign.center,
                  ),
                ),*/
              ],
            ),
            const Divider(
              color: Colours.PRIMARY_GREY,
              height: 30,
              thickness: 1,
            )
          ],
        ),
      );
    });
  }
}
