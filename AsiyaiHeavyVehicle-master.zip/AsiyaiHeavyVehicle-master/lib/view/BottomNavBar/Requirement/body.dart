import 'package:asiayai_heavy_vehicle_app/data/respnse/requirement_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Requirement/requirement_tile.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../utils/text_styles.dart';

class RequirmentScreen extends StatefulWidget {
  var from;
  RequirmentScreen({this.from});

  @override
  State<RequirmentScreen> createState() => _RequirmentScreenState();
}

class _RequirmentScreenState extends State<RequirmentScreen> {
  //
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200), () => getData());
  }

  getData() async {
    await Provider.of<UserProvider>(context, listen: false).getRequirement();
  }

  //
  bool loading = true;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: widget.from != null
            ? null
            : PreferredSize(
                preferredSize: Size.fromHeight(size.height / 16),
                child: AppBar(
                  title: Text(
                    "Requirements",
                    style: TextStyles.ktext20(context),
                  ),
                  backgroundColor: Colours.PRIMARY_GREY,
                ),
              ),
        body: Container(
          padding: EdgeInsets.symmetric(horizontal: size.width / 18),
          child: Column(
            children: [
              Container(
                child: Expanded(
                    child: model.myRequirements != null &&
                            model.myRequirements!.data != null &&
                            model.myRequirements!.data!.requiremnts != null &&
                            model.myRequirements!.data!.requiremnts!.length > 0
                        ? ListView.builder(
                            itemCount:
                                model.myRequirements!.data!.requiremnts!.length,
                            itemBuilder: (context, index) {
                              Requiremnts obj = model
                                  .myRequirements!.data!.requiremnts![index];
                              return RequirementTile(
                                obj: obj,
                              );
                            })
                        : Center(
                            child: Text(
                              "NO DATA",
                              style: TextStyle(
                                  fontSize: 18, color: Colours.PRIMARY_GREY),
                            ),
                          )),
              )
            ],
          ),
        ),
      );
    });
  }
}
