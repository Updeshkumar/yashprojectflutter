import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Account/account_information.dart';

import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Notifications/body.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Requirement/body.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/nav_drawe.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../utils/colour_resource.dart';
import '../../widgets/show_dialog.dart';
import '../home_screen.dart';
import 'Category/body.dart';
import 'Dashboard/body.dart';

class BottomNavBar extends StatefulWidget {
  int currentIndex = 0;
  BottomNavBar(this.currentIndex);

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  UserProvider? myProvider;
  final List<Widget> _childrens = [
    const DashBoardScreen(),
    CategoryScreen(from: "drawer"),
    RequirmentScreen(from: "drawer"),
    // NotificationsScreen(from: "drawer"),
    AccountSettings(from: "drawer"),
  ];

  //methods
  Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context);
        }));

    return request;
  }

  void onTabTapped(int index) {
    setState(() {
      widget.currentIndex = index;
    });
  }

  List<String> names = [
    "Category",
    "Requirements",
    // "Notifications",
    "Account Settings",
  ];

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context, listen: false);
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        key: scaffoldKey,
        drawer: NavDrawer(
          userType: model.userType,
        ),
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(size.height / 16),
          child: AppBar(
            centerTitle: true,
            title: widget.currentIndex == 0
                ? Image.asset(
                    Images.splash_logo,
                    width: size.width / 2.4,
                    height: size.height / 13.33,
                  )
                : Text(names[widget.currentIndex - 1]),
            leading: IconButton(
              onPressed: () {
                scaffoldKey.currentState!.openDrawer();
              },
              icon: const Icon(
                Icons.menu,
                color: Colors.white,
              ),
            ),
            // actions: [
            //   widget.currentIndex == 0
            //       ? IconButton(
            //           onPressed: () {
            //             Navigator.push(
            //                 context,
            //                 MaterialPageRoute(
            //                     builder: (context) => NotificationsScreen()));
            //           },
            //           icon: const Icon(
            //             Icons.notifications,
            //             color: Colors.white,
            //           ),
            //         )
            //       : Container(),
            // ],
            backgroundColor: Colours.PRIMARY_BLUE_MILD,
            elevation: 0.0,
            automaticallyImplyLeading: false,
          ),
        ),
        body: _childrens[widget.currentIndex],
        bottomNavigationBar: Theme(
          data: Theme.of(context).copyWith(
            canvasColor: Colours.PRIMARY_BLUE_MILD,
          ),
          child: WillPopScope(
            onWillPop: _onBackButtonPressed,
            child: Container(
              height: 60.0,
              child: BottomNavigationBar(
                  showSelectedLabels: true,
                  showUnselectedLabels: false,
                  selectedItemColor: Colours.YELLOW_LIGHT,
                  unselectedItemColor: Colors.white,
                  onTap: onTabTapped,
                  currentIndex: widget.currentIndex,
                  items: const [
                    BottomNavigationBarItem(
                      icon: Icon(Icons.home_filled),
                      label: 'Home',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.category),
                      label: 'Category',
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.dashboard_customize_sharp),
                      label: 'Requirement',
                    ),
                    // BottomNavigationBarItem(
                    //   icon: Icon(Icons.notifications),
                    //   label: 'Notifications',
                    // ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.info_outline),
                      label: 'Account',
                    ),
                  ]),
            ),
          ),
        ),
      );
    });
  }
}
