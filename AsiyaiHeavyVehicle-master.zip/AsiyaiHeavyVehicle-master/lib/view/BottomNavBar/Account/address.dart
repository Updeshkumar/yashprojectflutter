import 'package:flutter/material.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';
import 'account_information.dart';

class Addressess extends StatefulWidget {
  const Addressess({super.key});

  @override
  State<Addressess> createState() => _AddressessState();
}

class _AddressessState extends State<Addressess> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(size.height / 16),
        child: AppBar(
          title: Text(
            "Change Address",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
        ),
      ),
      body: Container(
        color: Colours.PRIMARY_BLUE,
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(left: size.width / 24),
              height: 50,
              color: Colours.PRIMARY_BLUE_MILD,
              child: Row(
                children: [
                  const Icon(
                    Icons.add,
                    color: Colours.YELLOW_DARK,
                  ),
                  SizedBox(
                    width: size.width / 60,
                  ),
                  Text(
                    "Add a new address",
                    style: TextStyles.ktext16(context)
                        .copyWith(color: Colours.YELLOW_DARK),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
