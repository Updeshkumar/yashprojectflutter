import 'package:flutter/material.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';
import 'account_information.dart';

class FAQ extends StatelessWidget {
  const FAQ({super.key});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    ;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(size.height / 16),
        child: AppBar(
          title: Text(
            "FAQ",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(
                  horizontal: size.width / 24, vertical: size.height / 70),
              child: Column(
                children: [
                  Text(
                    "Asiyai Heavy Vehicle Terms of Use",
                    style: TextStyles.ktext16(context),
                  ),
                  SizedBox(
                    height: size.height / 40,
                  ),
                  Text(
                    "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever  since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap",
                    style: TextStyles.ktext14(context)
                        .copyWith(fontWeight: FontWeight.w400),
                  )
                ],
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(vertical: size.height / 60),
            color: Colours.PRIMARY_BLUE_MILD,
            child: Center(
              child: Text(
                "@ 2022 Asiyai Heavy Vehicle",
                style: TextStyles.ktext12(context),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
