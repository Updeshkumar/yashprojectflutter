import 'package:flutter/material.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';
import 'account_information.dart';
import 'widgets/modules.dart';

class LegalPolicies extends StatefulWidget {
  const LegalPolicies({super.key});

  @override
  State<LegalPolicies> createState() => _LegalPoliciesState();
}

class _LegalPoliciesState extends State<LegalPolicies> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(size.height / 16),
        child: AppBar(
          title: Text(
            "Terms & Conditions",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
        ),
      ),
      body: Container(
        color: Colours.PRIMARY_BLUE,
        child: Column(
          children: [
            Expanded(
              child: Column(
                children: [
                  Container(
                    color: Colours.PRIMARY_BLUE_MILD,
                    padding: EdgeInsets.only(
                        left: size.width / 24,
                        right: size.width / 24,
                        top: size.height / 40),
                    child: Column(
                      children: [
                        Modules(title: "Terms of Use"),
                        Modules(title: "Privacy Policy"),
                        Modules(title: "Infringement Policy"),
                        Modules(title: "Licences"),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(vertical: size.height / 60),
              color: Colours.PRIMARY_BLUE_MILD,
              child: Center(
                child: Text(
                  "@ 2022 Asiyai Heavy Vehicle",
                  style: TextStyles.ktext12(context),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
