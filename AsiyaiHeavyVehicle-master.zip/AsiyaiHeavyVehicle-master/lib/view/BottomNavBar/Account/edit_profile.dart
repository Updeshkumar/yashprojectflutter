import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:flutter/material.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';
import '../../../widgets/customs_button.dart';
import '../../../widgets/textfield.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({super.key});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  //
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(size.height / 16),
        child: AppBar(
          title: Text(
            "Profile Update",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: CustomButton(
          height: size.height / 16,
          text: "SAVE",
          textColor: Colours.PRIMARY_BLACK,
          onTap: () {
            if (_formKey.currentState!.validate()) {}
          },
        ),
      ),
      body: Form(
        key: _formKey,
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: Colours.PRIMARY_BLUE,
          padding: EdgeInsets.symmetric(horizontal: size.width / 30),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: size.height / 20,
                ),
                Container(
                  height: size.height / 8,
                  width: size.width / 3.6,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      image: AssetImage(Images.full_person),
                    ),
                  ),
                ),
                SizedBox(
                  height: size.height / 40,
                ),
                IconTextField(
                  title: "First Name",
                  image: Images.person_icon,
                  onValidate: (value) {
                    if (value.isEmpty) {
                      return "First Name is Required";
                    }
                    return null;
                  },
                ),
                IconTextField(
                  title: "Last Name",
                  image: Images.person_icon,
                  onValidate: (value) {
                    if (value.isEmpty) {
                      return "Last Name is Required";
                    }
                    return null;
                  },
                ),
                SizedBox(
                  height: size.height / 80,
                ),
                IconTextField(
                  title: "Email Id",
                  image: Images.person_icon,
                  onValidate: (value) {
                    if (value.isEmpty) {
                      return "Email is Required";
                    }
                    return null;
                  },
                ),
                IconTextField(
                  title: "Mobile Number",
                  image: Images.number_icon,
                  onValidate: (value) {
                    if (value.isEmpty) {
                      return "Phone Number is Required";
                    }
                    return null;
                  },
                ),
                SizedBox(
                  height: size.height / 80,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
