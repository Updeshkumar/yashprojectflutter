import 'package:flutter/material.dart';

import '../../../../utils/text_styles.dart';

class Modules extends StatelessWidget {
  String? image;
  String title;
  VoidCallback? onTap;

  Modules({this.image, required this.title, this.onTap});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(bottom: 20),
        height: size.height / 20.3,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                if (image != null)
                  Image.asset(
                    image.toString(),
                    color: Colors.white,
                    height: 20,
                  ),
                if (image != null)
                  SizedBox(
                    width: size.width / 24,
                  ),
                Text(
                  title,
                  style: TextStyles.ktext16(context)
                      .copyWith(fontWeight: FontWeight.w400),
                )
              ],
            ),

            //
            if (title != "LogOut")
              Icon(
                Icons.arrow_forward_ios,
                color: Colors.white,
                size: 15,
              )
          ],
        ),
      ),
    );
  }
}
