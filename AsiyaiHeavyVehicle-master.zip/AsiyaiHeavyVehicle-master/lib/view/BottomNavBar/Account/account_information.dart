import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/app_constants.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Account/widgets/modules.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/driver_edit_screens.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/edit_vehicle/total_vehicle.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/labour_edit_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/sub_edit_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/heavy_vehicle.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';
import '../../../widgets/customs_button.dart';
import '../../../widgets/show_dialog.dart';
import 'address.dart';
import 'edit_profile.dart';
import 'faq.dart';
import 'legal_policies.dart';

class AccountSettings extends StatefulWidget {
  var from;

  AccountSettings({this.from});

  @override
  State<AccountSettings> createState() => _AccountSettingsState();
}

class _AccountSettingsState extends State<AccountSettings> {
  String? userType;
  String? userName;
  getData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userType = prefs.getString(AppConstants.USER_TYPE);
    userName = prefs.getString(AppConstants.USER_NAME);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  UserProvider? myProvider;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    myProvider = Provider.of<UserProvider>(context, listen: false);
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: widget.from != null
          ? null
          : PreferredSize(
              preferredSize: Size.fromHeight(size.height / 16),
              child: AppBar(
                title: Text(
                  "My Account Setting",
                  style: TextStyles.ktext20(context),
                ),
                backgroundColor: Colours.PRIMARY_GREY,
              ),
            ),
      body: Container(
        color: Colours.PRIMARY_BLUE,
        child: Column(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 50,
                    color: Colours.PRIMARY_BLUE_MILD,
                    child: Center(
                      child: Text(
                        "Hey! ${myProvider!.userName != null ? myProvider!.userName : ""}",
                        style: TextStyles.ktext16(context).copyWith(
                            color: Colours.YELLOW_LIGHT,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: size.height / 40,
                  ),
                  Container(
                    color: Colours.PRIMARY_BLUE_MILD,
                    padding: EdgeInsets.only(
                        left: size.width / 24,
                        right: size.width / 24,
                        top: size.height / 60),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Account Settings",
                          style: TextStyles.ktext18(context),
                        ),
                        SizedBox(
                          height: size.height / 60,
                        ),
                        Modules(
                          image: Images.person_icon,
                          title: "Edit Profile",
                          onTap: () {
                            if (userType!.toLowerCase().contains("driver")) {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      child: DriverEditScreens(),
                                      type: PageTransitionType.rightToLeft));
                            }
                            if (userType!.toLowerCase().contains("vehicle")) {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      child: AllEditVehicle(),
                                      type: PageTransitionType.rightToLeft));
                            }
                            if (userType!.toLowerCase().contains("labour")) {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      child: EditLabourScreen(),
                                      type: PageTransitionType.rightToLeft));
                            }
                            if (userType!.toLowerCase().contains("sub")) {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      child: SubEditScreen(),
                                      type: PageTransitionType.rightToLeft));
                            }
                          },
                        ),
                        // Modules(
                        //   image: Images.location_icon,
                        //   title: "Saved Addresses",
                        //   onTap: (() {
                        //     Navigator.push(
                        //         context,
                        //         MaterialPageRoute(
                        //             builder: (context) => Addressess()));
                        //   }),
                        // ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: size.height / 60,
                  ),
                  Container(
                    color: Colours.PRIMARY_BLUE_MILD,
                    padding: EdgeInsets.only(
                        left: size.width / 24,
                        right: size.width / 24,
                        top: size.height / 60),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Account Settings",
                          style: TextStyles.ktext18(context),
                        ),
                        SizedBox(
                          height: size.height / 80,
                        ),
                        Modules(
                          image: Images.docs_icon,
                          title: "Terms, Polocies and Licences",
                          onTap: (() {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LegalPolicies()));
                          }),
                        ),
                        Modules(
                          image: Images.faq_icon,
                          title: "Browse FAQs",
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => FAQ(),
                                ));
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Wrap(
        children: [
          myProvider!.userType != null &&
                  myProvider!.userType!.toLowerCase().contains("vehicle")
              ? Container(
                  margin: EdgeInsets.only(
                      bottom: size.height / 80,
                      left: size.width / 24,
                      right: size.width / 24),
                  child: CustomButton(
                    height: size.height / 20,
                    text: "Add More Vehicles",
                    textColor: Colours.PRIMARY_BLACK,
                    buttonColor: Colours.SKY_BLUE_LIGHT,
                    onTap: () {
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => HeavyVehiclePostScreen()));
                    },
                  ),
                )
              : Container(),
          Container(
            margin: EdgeInsets.only(
                bottom: size.height / 70,
                left: size.width / 24,
                right: size.width / 24),
            child: CustomButton(
              height: size.height / 20,
              text: "LOG OUT",
              textColor: Colours.PRIMARY_BLACK,
              onTap: () async {
                try {
                  ShowDialogsss().showDialogContainer(context);

                  final SharedPreferences sharedPreferences =
                      await SharedPreferences.getInstance();
                  sharedPreferences.remove(AppConstants.USER_TOKEN);
                  // sharedPreferences.remove("saveToken");
                  Future.delayed(Duration(microseconds: 300))
                      .whenComplete(() => SystemNavigator.pop());
                } catch (e) {}
              },
            ),
          ),
        ],
      ),
    );
  }
}
