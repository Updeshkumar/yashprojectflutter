import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/app_constants.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Account/account_information.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Category/body.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Dashboard/search_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Dashboard/widgets/banner.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Dashboard/widgets/search_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Requirement/body.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/nav_drawe.dart';
import 'package:asiayai_heavy_vehicle_app/view/Driver/driver_body.dart';
import 'package:asiayai_heavy_vehicle_app/view/Labour/labour_body.dart';
import 'package:asiayai_heavy_vehicle_app/view/SubContructor/sc_body.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/hv_body.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Dashboard/widgets/imag_vid.dart';
import 'package:asiayai_heavy_vehicle_app/view/BottomNavBar/Notifications/body.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/show_dialog.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../utils/text_styles.dart';

String? userDetail;

class DashBoardScreen extends StatefulWidget {
  const DashBoardScreen({super.key});

  @override
  State<DashBoardScreen> createState() => _DashBoardScreenState();
}

class _DashBoardScreenState extends State<DashBoardScreen> {
  //

  //variables
  getData() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    userDetail = sharedPreferences.getString(AppConstants.USER_PHONE);
    print("USER DETAILS >>>>" + userDetail.toString());

    // await Provider.of<UserProvider>(context, listen: false).getVehicleData();
    // await Provider.of<UserProvider>(context, listen: false).getLabourData();
    // await Provider.of<UserProvider>(context, listen: false)
    //     .getSubContructorData();
    // await Provider.of<UserProvider>(context, listen: false).getDriverData();
    await Provider.of<UserProvider>(context, listen: false).homeDataShow();
    if (myProvider!.userType != null) {
      if (myProvider!.userType!.toLowerCase().contains("labour")) {
        myProvider!.getLabourData();
      } else if (myProvider!.userType!.toLowerCase().contains("driver")) {
        myProvider!.getDriverData();
      } else if (myProvider!.userType!.toLowerCase().contains("sub")) {
        myProvider!.getSubContructorData();
      } else if (myProvider!.userType!.toLowerCase().contains("vehicle")) {
        myProvider!.getVehicleData();
      }
    }
  }

  UserProvider? myProvider;
  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(Duration(milliseconds: 200), () => getData());

    super.initState();
  }

  List<String> searchCategory = [
    "Heavy Vehicle",
    "Driver",
    "SubContructor",
    "LabourContructor",
  ];

  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context, listen: false);
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              // for search field\
              InkWell(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => SearchScreen()));
                },
                child: Container(
                    width: size.width,
                    height: 45,
                    padding: EdgeInsets.symmetric(
                      horizontal: size.width / 30,
                    ),
                    margin: EdgeInsets.only(
                      left: size.width / 30,
                      right: size.width / 30,
                      bottom: size.height / 40,
                      top: size.height / 80,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colours.PRIMARY_BLUE_MILD,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                            child: Text(
                          "Search Vehicle,Contractor,labour...",
                          style: TextStyles.ktext14(context).copyWith(
                              color: Colours.PRIMARY_GREY_LIGHT,
                              fontWeight: FontWeight.w500,
                              letterSpacing: 0.5),
                        )),
                        const Icon(
                          Icons.search,
                          size: 30,
                          color: Colours.PRIMARY_GREY_LIGHT,
                        ),
                      ],
                    )
                    /* PopupMenuButton(
                    onSelected: (value) {},
                    elevation: 0.0,
                    child: Row(children: [
                      Expanded(
                          child: Text(
                        "Search Vehicle,Contractor,labour...",
                        style: TextStyles.ktext14(context).copyWith(
                            color: Colours.PRIMARY_GREY_LIGHT,
                            fontWeight: FontWeight.w500,
                            letterSpacing: 0.5),
                      )),
                      const Icon(
                        Icons.search,
                        size: 30,
                        color: Colours.PRIMARY_GREY_LIGHT,
                      )
                    ]),
                    itemBuilder: (context) {
                      return List.generate(searchCategory.length, (index) {
                        return PopupMenuItem(
                          // onTap: () {
                          //   print(searchCategory[index]);
                          // },
              
                          child: InkWell(
                              onTap: () {
                                print(searchCategory[index] + '$index');
                                Navigator.pop(context);
                                // Navigator.push(
                                //     context,
                                //     MaterialPageRoute(
                                //         builder: (context) => SearchScreen(
                                //               index: '$index',
                                //             )));
                                setState(() {});
                              },
                              child: Text(searchCategory[index])),
                        );
                      });
                    },
                  ),*/
                    ),
              ),

              // for banner
              BannerView(),
              //
              // ImgVidUrl(),
              ImgVidProduct(
                imgUrl: "",
                vidUrl: "",
              ),
              // //
              HeavyVehicleBody(),

              DriverBody(),
              // //
              SubContructorDetailasList(),

              LAbourBody(),
            ],
          ),
        ),
      );
    });
  }
}
