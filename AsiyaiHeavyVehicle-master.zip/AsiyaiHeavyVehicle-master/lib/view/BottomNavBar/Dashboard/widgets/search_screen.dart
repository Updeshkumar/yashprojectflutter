// import 'dart:convert';

// import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
// import 'package:asiayai_heavy_vehicle_app/data/respnse/vehicel_details_model.dart';
// import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
// import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../../../../data/respnse/driver_details_model.dart';
// import '../../../../data/respnse/labour_details_model.dart';
// import '../../../../data/respnse/sub_details_model.dart';
// import '../../../../utils/images.dart';
// import '../../../../utils/text_styles.dart';
// import '../../../Driver/DriverDetails/driver_details.dart';
// import '../../../Labour/LabourDetails/labour_details.dart';
// import '../../../SubContructor/SubContDetails/sub_details.dart';
// import '../../../Vehicel/VehicleDetails/vehicle_details.dart';

// class SearchScreen extends StatefulWidget {
//   String? index;
//   SearchScreen({this.index});

//   @override
//   State<SearchScreen> createState() => _SearchScreenState();
// }

// class _SearchScreenState extends State<SearchScreen> {
//   @override
//   void initState() {
//     // TODO: implement initState
//     Future.delayed(Duration(seconds: 100), () => getData());

//     super.initState();
//   }

//   getData() async {
//     if (widget.index == "0") {
//       await Provider.of<UserProvider>(context, listen: false).getVehicleData();
//     } else if (widget.index == "1") {
//       await Provider.of<UserProvider>(context, listen: false).getDriverData();
//     } else if (widget.index == "2") {
//       await Provider.of<UserProvider>(context, listen: false)
//           .getSubContructorData();
//     } else if (widget.index == "3") {
//       await Provider.of<UserProvider>(context, listen: false).getLabourData();
//     }
//   }

//   TextEditingController searchController = TextEditingController();

//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;
//     return Consumer<UserProvider>(builder: (context, model, child) {
//       return Scaffold(
//           backgroundColor: Colours.PRIMARY_BLUE,
//           appBar: AppBar(
//             automaticallyImplyLeading: false,
//             backgroundColor: Colours.PRIMARY_BLUE_MILD,
//             title: TextField(
//               controller: searchController,
//             ),
//             actions: [
//               IconButton(
//                   onPressed: () {
//                     if (widget.index == "0") {
//                       model.searchVehicle(searchController.text);
//                     } else if (widget.index == "1") {
//                       model.searchDriverData(searchController.text);
//                     } else if (widget.index == "2") {
//                       model.searchSUBData(searchController.text);
//                     } else if (widget.index == "3") {
//                       model.searchLabourData(searchController.text);
//                     }
//                   },
//                   icon: Icon(
//                     Icons.search,
//                     color: Colours.YELLOW_DARK,
//                   ))
//             ],
//           ),
//           body: Column(
//             children: [
//               if (widget.index == "0")
//                 Expanded(
//                   child: Container(
//                     child: ListView.builder(
//                         itemCount: model.vehicle_details.length,
//                         itemBuilder: (context, index) {
//                           Vehiclelist obj = model.vehicle_details[index];
//                           return InkWell(
//                               onTap: () {
//                                 Navigator.push(
//                                     context,
//                                     MaterialPageRoute(
//                                         builder: (context) =>
//                                             HeavyVehicleDeatilsPage(
//                                               obj: obj,
//                                             )));
//                               },
//                               child: Column(
//                                 children: [
//                                   Container(
//                                     decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(8),
//                                     ),
//                                     child: Row(
//                                       children: [
//                                         Container(
//                                           height: size.height / 8,
//                                           width: size.width / 4,
//                                           decoration: BoxDecoration(
//                                             borderRadius:
//                                                 BorderRadius.circular(8),
//                                           ),
//                                           child: ClipRRect(
//                                             borderRadius:
//                                                 BorderRadius.circular(8),
//                                             child: FadeInImage.assetNetwork(
//                                               placeholder: Images.vehicle_icon,
//                                               placeholderFit: BoxFit.none,
//                                               image:
//                                                   obj.vehicleImage.toString(),
//                                               fit: BoxFit.fill,
//                                             ),
//                                           ),
//                                         ),
//                                         Expanded(
//                                           child: Padding(
//                                             padding: const EdgeInsets.all(10.0),
//                                             child: Column(
//                                               crossAxisAlignment:
//                                                   CrossAxisAlignment.start,
//                                               children: [
//                                                 Text(
//                                                   obj.vehicalName
//                                                       .toString()
//                                                       .toUpperCase(),
//                                                   style: TextStyles.ktext16(
//                                                           context)
//                                                       .copyWith(
//                                                           fontWeight:
//                                                               FontWeight.bold),
//                                                 ),
//                                                 const SizedBox(
//                                                   height: 6,
//                                                 ),
//                                                 Text(
//                                                   "",
//                                                   // obj.distict.toString() +
//                                                   //     "  " +
//                                                   //     obj.state.toString() +
//                                                   //     "  " +
//                                                   //     obj.country.toString(),
//                                                   style: TextStyles.ktext14(
//                                                           context)
//                                                       .copyWith(
//                                                           fontWeight:
//                                                               FontWeight.w400,
//                                                           color: Colours
//                                                               .PRIMARY_GREY_LIGHT),
//                                                   maxLines: 2,
//                                                 ),
//                                                 SizedBox(
//                                                   height: size.height / 80,
//                                                 ),
//                                                 Row(
//                                                   children: [
//                                                     Text(
//                                                       "Vehicle Number: ",
//                                                       style: TextStyles.ktext16(
//                                                               context)
//                                                           .copyWith(
//                                                               fontWeight:
//                                                                   FontWeight
//                                                                       .w400),
//                                                     ),
//                                                     Text(
//                                                       "${obj.vehicleregistrationnumber.toString()}",
//                                                       style: TextStyles.ktext16(
//                                                           context),
//                                                     ),
//                                                   ],
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                   Divider(
//                                     color: Colours.PRIMARY_GREY,
//                                   ),
//                                 ],
//                               ));
//                         }),
//                   ),
//                 ),
//               if (widget.index == "1")
//                 Expanded(
//                   child: Container(
//                     child: ListView.builder(
//                         itemCount: model.drivers_data.length,
//                         itemBuilder: (context, index) {
//                           HomeDriverList obj = model.drivers_data[index];
//                           return InkWell(
//                             onTap: () {
//                               Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                       builder: (context) => DriverDetailsPage(
//                                             obj: obj,
//                                           )));
//                             },
//                             child: Column(
//                               children: [
//                                 Container(
//                                   decoration: BoxDecoration(
//                                     borderRadius: BorderRadius.circular(8),
//                                   ),
//                                   child: Row(
//                                     children: [
//                                       Container(
//                                         height: size.height / 8,
//                                         width: size.width / 4,
//                                         decoration: BoxDecoration(
//                                           borderRadius:
//                                               BorderRadius.circular(8),
//                                         ),
//                                         child: ClipRRect(
//                                           borderRadius:
//                                               BorderRadius.circular(8),
//                                           child: FadeInImage.assetNetwork(
//                                             placeholder: Images.person_icon,
//                                             placeholderFit: BoxFit.none,
//                                             image: obj.driverImage.toString(),
//                                             fit: BoxFit.fill,
//                                           ),
//                                         ),
//                                       ),
//                                       Expanded(
//                                         child: Padding(
//                                           padding: const EdgeInsets.symmetric(
//                                               horizontal: 10, vertical: 20),
//                                           child: Column(
//                                             crossAxisAlignment:
//                                                 CrossAxisAlignment.start,
//                                             children: [
//                                               Text(
//                                                 obj.driveroperatorname
//                                                     .toString()
//                                                     .toUpperCase(),
//                                                 style:
//                                                     TextStyles.ktext16(context)
//                                                         .copyWith(
//                                                             fontWeight:
//                                                                 FontWeight
//                                                                     .bold),
//                                               ),
//                                               // if (obj.distict != "" &&
//                                               //     obj.distict != null &&
//                                               //     obj.state != "" &&
//                                               //     obj.state != null &&
//                                               //     obj.country != "" &&
//                                               //     obj.country != null)
//                                               Text(
//                                                 "",
//                                                 // obj.distict! +
//                                                 //     " , " +
//                                                 //     obj.state! +
//                                                 //     " , " +
//                                                 //     obj.country!,
//                                                 style: TextStyles.ktext14(
//                                                         context)
//                                                     .copyWith(
//                                                         fontWeight:
//                                                             FontWeight.w400,
//                                                         color: Colours
//                                                             .PRIMARY_GREY_LIGHT),
//                                                 maxLines: 2,
//                                               ),
//                                               SizedBox(
//                                                 height: size.height / 80,
//                                               ),
//                                               Row(
//                                                 children: [
//                                                   Text(
//                                                     "Experience : ",
//                                                     style: TextStyles.ktext16(
//                                                             context)
//                                                         .copyWith(
//                                                             fontWeight:
//                                                                 FontWeight
//                                                                     .w400),
//                                                   ),
//                                                   Text(
//                                                     "${obj.expriencesinyear.toString()}",
//                                                     style: TextStyles.ktext16(
//                                                         context),
//                                                   ),
//                                                 ],
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                                 Divider(
//                                   color: Colours.PRIMARY_GREY,
//                                 ),
//                               ],
//                             ),
//                           );
//                         }),
//                   ),
//                 ),
//               if (widget.index == "2")
//                 Expanded(
//                   child: Container(
//                     child: ListView.builder(
//                         itemCount: model.sub_data.length,
//                         itemBuilder: (context, index) {
//                           SubData obj = model.sub_data[index];
//                           List imageList = jsonDecode(obj.subcontractorImage!);
//                           return GestureDetector(
//                             onTap: () {
//                               Navigator.push(
//                                   context,
//                                   MaterialPageRoute(
//                                       builder: (context) =>
//                                           SubContractorDetailsPage(
//                                             obj: obj,
//                                           )));
//                             },
//                             child: Column(
//                               children: [
//                                 Container(
//                                   decoration: BoxDecoration(
//                                     borderRadius: BorderRadius.circular(8),
//                                   ),
//                                   child: Row(
//                                     children: [
//                                       Container(
//                                         height: size.height / 8,
//                                         width: size.width / 4,
//                                         decoration: BoxDecoration(
//                                           borderRadius:
//                                               BorderRadius.circular(8),
//                                         ),
//                                         child: ClipRRect(
//                                           borderRadius:
//                                               BorderRadius.circular(8),
//                                           child: FadeInImage.assetNetwork(
//                                             placeholder: Images.person_icon,
//                                             placeholderFit: BoxFit.none,
//                                             image: imageList != null
//                                                 ? imageList[0]
//                                                 : Images.person_icon,
//                                             fit: BoxFit.fill,
//                                           ),
//                                         ),
//                                       ),
//                                       Expanded(
//                                         child: Padding(
//                                           padding: const EdgeInsets.all(10.0),
//                                           child: Column(
//                                             crossAxisAlignment:
//                                                 CrossAxisAlignment.start,
//                                             children: [
//                                               Text(
//                                                 obj.contractorname
//                                                     .toString()
//                                                     .toUpperCase(),
//                                                 style:
//                                                     TextStyles.ktext16(context)
//                                                         .copyWith(
//                                                             fontWeight:
//                                                                 FontWeight
//                                                                     .bold),
//                                               ),
//                                               Text(
//                                                 obj.distict.toString() +
//                                                     "  " +
//                                                     obj.state.toString() +
//                                                     "  " +
//                                                     obj.country.toString(),
//                                                 style: TextStyles.ktext14(
//                                                         context)
//                                                     .copyWith(
//                                                         fontWeight:
//                                                             FontWeight.w400,
//                                                         color: Colours
//                                                             .PRIMARY_GREY_LIGHT),
//                                                 maxLines: 2,
//                                               ),
//                                               SizedBox(
//                                                 height: size.height / 80,
//                                               ),
//                                               Row(
//                                                 children: [
//                                                   Text(
//                                                     "License Number: ",
//                                                     style: TextStyles.ktext16(
//                                                             context)
//                                                         .copyWith(
//                                                             fontWeight:
//                                                                 FontWeight
//                                                                     .w400),
//                                                   ),
//                                                   Text(
//                                                     "${obj.licenseNumber.toString()}",
//                                                     style: TextStyles.ktext16(
//                                                         context),
//                                                   ),
//                                                 ],
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                                 Divider(
//                                   color: Colours.PRIMARY_GREY,
//                                 ),
//                               ],
//                             ),
//                           );
//                         }),
//                   ),
//                 ),
//               if (widget.index == "3")
//                 Expanded(
//                     child: Container(
//                   child: ListView.builder(
//                       itemCount: model.labour_data.length,
//                       itemBuilder: (context, index) {
//                         LabourData obj = model.labour_data[index];
//                         List imageList = jsonDecode(obj.labourImage!);
//                         return GestureDetector(
//                           onTap: () {
//                             Navigator.push(
//                                 context,
//                                 MaterialPageRoute(
//                                     builder: (context) => LabourDetaislPage(
//                                           obj: obj,
//                                         )));
//                           },
//                           child: Column(
//                             children: [
//                               Container(
//                                 decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(8),
//                                 ),
//                                 child: Row(
//                                   children: [
//                                     Container(
//                                       height: size.height / 8,
//                                       width: size.width / 4,
//                                       decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(8),
//                                       ),
//                                       child: ClipRRect(
//                                         borderRadius: BorderRadius.circular(8),
//                                         child: FadeInImage.assetNetwork(
//                                           placeholder: Images.person_icon,
//                                           placeholderFit: BoxFit.none,
//                                           image: imageList != null
//                                               ? imageList[0]
//                                               : Images.person_icon,
//                                           fit: BoxFit.fill,
//                                         ),
//                                       ),
//                                     ),
//                                     Expanded(
//                                       child: Padding(
//                                         padding: const EdgeInsets.all(10.0),
//                                         child: Column(
//                                           crossAxisAlignment:
//                                               CrossAxisAlignment.start,
//                                           children: [
//                                             Text(
//                                               obj.labourcontractorname
//                                                   .toString()
//                                                   .toUpperCase(),
//                                               style: TextStyles.ktext16(context)
//                                                   .copyWith(
//                                                       fontWeight:
//                                                           FontWeight.bold),
//                                             ),
//                                             Text(
//                                               obj.distict.toString() +
//                                                   "  " +
//                                                   obj.state.toString() +
//                                                   "  " +
//                                                   obj.country.toString(),
//                                               style: TextStyles.ktext14(context)
//                                                   .copyWith(
//                                                       fontWeight:
//                                                           FontWeight.w400,
//                                                       color: Colours
//                                                           .PRIMARY_GREY_LIGHT),
//                                               maxLines: 2,
//                                             ),
//                                             SizedBox(
//                                               height: size.height / 80,
//                                             ),
//                                             Row(
//                                               children: [
//                                                 Text(
//                                                   "Labour Work : ",
//                                                   style: TextStyles.ktext16(
//                                                           context)
//                                                       .copyWith(
//                                                           fontWeight:
//                                                               FontWeight.w400),
//                                                 ),
//                                                 Text(
//                                                   "${obj.labourwork.toString()}",
//                                                   style: TextStyles.ktext16(
//                                                       context),
//                                                 ),
//                                               ],
//                                             ),
//                                           ],
//                                         ),
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                               Divider(
//                                 color: Colours.PRIMARY_GREY,
//                               ),
//                             ],
//                           ),
//                         );
//                       }),
//                 ))
//             ],
//           ));
//     });
//   }
// }
