import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import '../../../../utils/colour_resource.dart';

class BannerView extends StatefulWidget {
  const BannerView({super.key});

  @override
  State<BannerView> createState() => _BannerViewState();
}

class _BannerViewState extends State<BannerView> {
  //
  List<String> images = [
    "https://www.freepnglogos.com/uploads/jcb-png/jcb-png-transparent-images-2.png",
    "https://i.pinimg.com/originals/64/10/79/641079a5ed7de9261ab64c232121cfe4.png",
    "https://www.freepnglogos.com/uploads/jcb-png/jcb-png-transparent-images-2.png",
  ];

  var _currentIndex = 0.0;

  void setCurrentIndex(double index) {
    _currentIndex = index;
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: size.width / 24),
      width: size.width,
      height: size.height / 5,
      child: Stack(
        fit: StackFit.expand,
        children: [
          CarouselSlider.builder(
            options: CarouselOptions(
              viewportFraction: 1,
              autoPlay: true,
              enlargeCenterPage: true,
              disableCenter: true,
              // onPageChanged: (index, reason) {

              // },
            ),
            itemCount: images.length,
            itemBuilder: (context, index, _) {
              return Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colours.PRIMARY_GREY_LIGHT.withOpacity(0.1),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: FadeInImage.assetNetwork(
                    placeholder: Images.vehicle_icon,
                    placeholderFit: BoxFit.none,
                    fit: BoxFit.fill,
                    alignment: Alignment.center,
                    image: images[index],
                  ),
                ),
              );
            },
          ),
          // Positioned(
          //   bottom: -2,
          //   left: 0.0,
          //   right: 0.0,
          //   // child: DotsIndicator(
          //   //   dotsCount: images.length,
          //   //   position: _currentIndex,
          //   //   decorator: DotsDecorator(
          //   //     size: const Size.square(9.0),
          //   //     activeSize: const Size.square(11),

          //   //     // activeSize: const Size(20.0, 9.0),
          //   //     activeColor: Colours.PRIMARY_BLUE_MILD,
          //   //     activeShape: RoundedRectangleBorder(
          //   //       borderRadius: BorderRadius.circular(5.0),
          //   //     ),
          //   //   ),
          //   // ),
          // ),
        ],
      ),
    );
  }
}
