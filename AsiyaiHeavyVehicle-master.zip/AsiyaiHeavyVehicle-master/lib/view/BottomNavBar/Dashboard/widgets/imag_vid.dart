import 'package:asiayai_heavy_vehicle_app/provider/img_vid_provider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

// class ImgVidUrl extends StatefulWidget {
//   const ImgVidUrl({super.key});

//   @override
//   State<ImgVidUrl> createState() => _ImgVidUrlState();
// }

// class _ImgVidUrlState extends State<ImgVidUrl> {
//   //
//   @override
//   void initState() {
//     Provider.of<ImgVideoProvider>(context, listen: false).getImgVid();

//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;

//     return Consumer<ImgVideoProvider>(builder: (context, model, child) {
//       return Container(
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(8),
//         ),
//         height: size.height / 8,
//         child: ListView.builder(
//             shrinkWrap: true,
//             physics: NeverScrollableScrollPhysics(),
//             itemCount: model.imgVidUrl.length,
//             itemBuilder: (context, index) {
//               return ImgVidProduct(
//                 imgUrl: model.imgVidUrl[index].imageUplaod.toString(),
//                 vidUrl: model.imgVidUrl[index].vediourl.toString(),
//               );
//             }),
//       );
//     });
//   }
// }

class ImgVidProduct extends StatefulWidget {
  String imgUrl, vidUrl;
  ImgVidProduct({required this.imgUrl, required this.vidUrl});

  @override
  State<ImgVidProduct> createState() => _ImgVidProductState();
}

class _ImgVidProductState extends State<ImgVidProduct> {
  //
  Future<void> launchUrlStart({required String url}) async {
    if (!await launchUrl(Uri.parse(url))) {
      throw "Could not launch $url";
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return InkWell(
      onTap: () {
        launchUrlStart(url: widget.vidUrl);
      },
      child: Container(
        height: size.height / 9,
        width: double.infinity,
        margin: EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
        decoration: BoxDecoration(
          color: Colours.PRIMARY_GREY_LIGHT.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: FadeInImage.assetNetwork(
              placeholder: Images.splash_logo,
              placeholderFit: BoxFit.contain,
              fit: BoxFit.fill,
              image: widget.imgUrl,
              imageErrorBuilder: (BuildContext? context, Object? exception,
                  StackTrace? stackTrace) {
                return Image.asset(Images.splash_logo, fit: BoxFit.fill);
              }),
        ),
      ),
    );
  }
}
