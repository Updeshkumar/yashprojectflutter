import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/Driver/driver_body.dart';
import 'package:asiayai_heavy_vehicle_app/view/Driver/driver_product.dart';
import 'package:asiayai_heavy_vehicle_app/view/Labour/labour_body.dart';
import 'package:asiayai_heavy_vehicle_app/view/Labour/labour_product.dart';
import 'package:asiayai_heavy_vehicle_app/view/SubContructor/sc_body.dart';
import 'package:asiayai_heavy_vehicle_app/view/SubContructor/sc_prouct.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/VehicleDetails/more_vehicles.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/hv_body.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/hv_product.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/blank_dta.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this);
    Future.delayed(Duration(milliseconds: 200), () => getData());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  getData() async {
    await Provider.of<UserProvider>(context, listen: false)
        .searchDataApi(context, query: "");
  }

  TextEditingController queryController = TextEditingController();
  Size? size;
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: AppBar(
          backgroundColor: Colours.PRIMARY_BLUE_MILD,
          title: Text("Search "),
        ),
        body: Container(
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Column(children: [
            Container(
                height: 50,
                padding: EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colours.PRIMARY_BLUE_MILD,
                  border: Border.all(color: Colours.PRIMARY_GREY_LIGHT),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TextFormField(
                  controller: queryController,
                  cursorColor: Colours.PRIMARY_GREY_LIGHT,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Search Vehicle,Contractor,labour...",
                    hintStyle: TextStyles.ktext12(context).copyWith(
                        color: Colours.PRIMARY_GREY_LIGHT.withOpacity(0.6),
                        fontWeight: FontWeight.w400,
                        letterSpacing: 0.5),
                  ),
                  onChanged: (val) {
                    model.searchDataApi(context, query: queryController.text);
                  },
                )),
            const SizedBox(
              height: 20,
            ),
            model.mySearchData != null && model.mySearchData!.data != null
                ? Expanded(
                    child: Container(
                      child: ListView(
                        children: [
                          //
                          model.mySearchData != null &&
                                  model.mySearchData!.data != null &&
                                  model.mySearchData!.data!.vehiclelist !=
                                      null &&
                                  model.mySearchData!.data!.vehiclelist!
                                          .length >
                                      0
                              ? Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: size!.width / 30,
                                      vertical: 8),
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "Heavy Vehicle",
                                            style: TextStyles.ktext18(context),
                                          ),
                                        ],
                                      ),
                                      Container(
                                        height: size!.height / 7,
                                        margin: EdgeInsets.only(top: 8),
                                        child: Consumer<UserProvider>(
                                          builder: (context, model, child) {
                                            return ListView.builder(
                                                scrollDirection:
                                                    Axis.horizontal,
                                                itemCount: model.mySearchData!
                                                    .data!.vehiclelist!.length,
                                                itemBuilder: ((context, index) {
                                                  HomeVehiclelist obj = model
                                                      .mySearchData!
                                                      .data!
                                                      .vehiclelist![index];
                                                  return HVProduct(
                                                    obj: obj,
                                                  );
                                                }));
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : Container(),

                          model.mySearchData != null &&
                                  model.mySearchData!.data != null &&
                                  model.mySearchData!.data!.driverList !=
                                      null &&
                                  model.mySearchData!.data!.driverList!.length >
                                      0
                              ? Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: size!.width / 30,
                                      vertical: 8),
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "Driver/Operator",
                                            style: TextStyles.ktext18(context),
                                          ),
                                        ],
                                      ),
                                      Container(
                                        height: size!.height / 7,
                                        margin: EdgeInsets.only(top: 8),
                                        child: Consumer<UserProvider>(
                                          builder: (context, model, child) {
                                            return ListView.builder(
                                                scrollDirection:
                                                    Axis.horizontal,
                                                itemCount: model.mySearchData!
                                                    .data!.driverList!.length,
                                                itemBuilder: ((context, index) {
                                                  HomeDriverList obj = model
                                                      .mySearchData!
                                                      .data!
                                                      .driverList![index];
                                                  return DriverProduct(
                                                    obj: obj,
                                                  );
                                                }));
                                          },
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              : Container(),
                          // // //
                          model.mySearchData != null &&
                                  model.mySearchData!.data != null &&
                                  model.mySearchData!.data!.subcontructorList !=
                                      null &&
                                  model.mySearchData!.data!.subcontructorList!
                                          .length >
                                      0
                              ? Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: size!.width / 30,
                                      vertical: 8),
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "Sub Contructor",
                                            style: TextStyles.ktext18(context),
                                          ),
                                        ],
                                      ),
                                      Container(
                                        height: size!.height / 7,
                                        margin: EdgeInsets.only(top: 8),
                                        child: Consumer<UserProvider>(
                                          builder: (context, model, child) {
                                            return ListView.builder(
                                                scrollDirection:
                                                    Axis.horizontal,
                                                itemCount: model
                                                    .mySearchData!
                                                    .data!
                                                    .subcontructorList!
                                                    .length,
                                                itemBuilder: ((context, index) {
                                                  SubcontructorList obj = model
                                                          .mySearchData!
                                                          .data!
                                                          .subcontructorList![
                                                      index];

                                                  return SubcontructorProduct(
                                                      obj: obj);
                                                }));
                                          },
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              : Container(),

                          model.mySearchData != null &&
                                  model.mySearchData!.data != null &&
                                  model.mySearchData!.data!.labourList !=
                                      null &&
                                  model.mySearchData!.data!.labourList!.length >
                                      0
                              ? Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: size!.width / 30,
                                      vertical: 8),
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "Labour Contractor",
                                            style: TextStyles.ktext18(context),
                                          ),
                                        ],
                                      ),
                                      Container(
                                        height: size!.height / 7,
                                        margin: EdgeInsets.only(top: 8),
                                        child: Consumer<UserProvider>(
                                          builder: (context, model, child) {
                                            return ListView.builder(
                                                scrollDirection:
                                                    Axis.horizontal,
                                                itemCount: model.mySearchData!
                                                    .data!.labourList!.length,
                                                itemBuilder: (context, index) {
                                                  LabourList obj = model
                                                      .mySearchData!
                                                      .data!
                                                      .labourList![index];
                                                  return LabourProduct(
                                                    obj: obj,
                                                  );
                                                });
                                          },
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              : Container(),
                        ],
                      ),
                    ),
                  )
                : Container(
                    child: Center(
                      child: Text(
                        "No Data",
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.w600,
                            color: Colours.PRIMARY_GREY),
                      ),
                    ),
                  )
          ]),
        ),
      );
    });
  }
}
