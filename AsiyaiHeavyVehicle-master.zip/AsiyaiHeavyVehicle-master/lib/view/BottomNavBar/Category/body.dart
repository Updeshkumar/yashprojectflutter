import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:flutter/material.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';
import 'category_tile.dart';

class CategoryScreen extends StatefulWidget {
  var from;

  CategoryScreen({this.from});

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  List category = [
    {
      "title": "Heavy\nVehicle",
      "images": Images.category_vehicle,
    },
    {
      "title": "Sub\n Contractor",
      "images": Images.category_subcontr,
    },
    {
      "title": "Labour\n Contractor",
      "images": Images.category_labour,
    },
    {
      "title": "Driver/Operator",
      "images": Images.category_driver,
    }
  ];

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: widget.from != null
          ? null
          : PreferredSize(
              preferredSize: Size.fromHeight(size.height / 16),
              child: AppBar(
                title: Text(
                  "Category",
                  style: TextStyles.ktext20(context),
                ),
                backgroundColor: Colours.PRIMARY_GREY,
              ),
            ),
      body: Column(
        children: [
          SizedBox(
            height: size.height / 40,
          ),
          Expanded(
            child: GridView.builder(
              itemCount: category.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 5,
                childAspectRatio: 0.75,
              ),
              itemBuilder: (context, index) {
                return CategoryTile(
                  title: category[index]['title'],
                  image: category[index]['images'],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
