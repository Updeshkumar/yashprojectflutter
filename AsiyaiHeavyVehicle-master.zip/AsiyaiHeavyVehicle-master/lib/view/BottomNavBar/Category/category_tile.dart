import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/view/Driver/DriverDetails/more_driver.dart';
import 'package:asiayai_heavy_vehicle_app/view/Labour/LabourDetails/more_labour.dart';
import 'package:asiayai_heavy_vehicle_app/view/SubContructor/SubContDetails/more_sub.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/VehicleDetails/more_vehicles.dart';
import 'package:flutter/material.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';

class CategoryTile extends StatefulWidget {
  String title, image;

  CategoryTile({required this.title, required this.image});

  @override
  State<CategoryTile> createState() => _CategoryTileState();
}

class _CategoryTileState extends State<CategoryTile> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () {
        if (widget.title == "Heavy\nVehicle") {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => MoreVehicles()));
        }
        if (widget.title == "Driver/Operator") {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => MoreDrivers()));
        }
        if (widget.title == "Labour\n Contractor") {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => MoreLabour()));
        }
        if (widget.title == "Sub\n Contractor") {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => MoreSubContructors()));
        }
      },
      child: Container(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              height: size.height / 8,
              width: size.width / 3.6,
              decoration: BoxDecoration(
                border: Border.all(
                  color: Color.fromARGB(255, 63, 129, 167),
                  width: 1,
                ),
                shape: BoxShape.circle,
                color: Color.fromARGB(255, 87, 123, 134),
              ),
              child: Image.asset(widget.image),
            ),
            SizedBox(
              height: size.height / 80,
            ),
            Text(
              widget.title,
              textAlign: TextAlign.center,
              style: TextStyles.ktext12(context)
                  .copyWith(color: Colours.YELLOW_LIGHT),
            )
          ],
        ),
      ),
    );
  }
}
