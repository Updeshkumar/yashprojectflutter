import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:flutter/material.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';

class NotificationsScreen extends StatefulWidget {
  var from;
  NotificationsScreen({this.from});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  //variabls

  bool isActive = false;
  bool isOffer = false;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: widget.from != null
          ? null
          : PreferredSize(
              preferredSize: Size.fromHeight(size.height / 16),
              child: AppBar(
                title: Text(
                  "Notifications",
                  style: TextStyles.ktext20(context),
                ),
                backgroundColor: Colours.PRIMARY_GREY,
              ),
            ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
            color: Color.fromARGB(255, 87, 125, 146),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 25, vertical: 8),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colours.SKY_BLUE_LIGHT, width: 1),
                    borderRadius: BorderRadius.circular(20),
                    color: isActive
                        ? Colours.SKY_BLUE_DARK
                        : Colours.PRIMARY_BLUE_MILD,
                  ),
                  child: Text(
                    "All",
                    style: TextStyles.ktext14(context),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 25, vertical: 8),
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: Colours.SKY_BLUE_LIGHT, width: 1),
                      borderRadius: BorderRadius.circular(20),
                      color: isActive
                          ? Colours.SKY_BLUE_DARK
                          : Colours.PRIMARY_BLUE_MILD),
                  child: Text(
                    "Offer",
                    style: TextStyles.ktext14(context),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: size.height / 40,
          ),
          Expanded(
              child: ListView.builder(
            itemCount: 5,
            itemBuilder: (context, index) {
              return NotiFicationTile();
            },
          ))
        ],
      ),
    );
  }
}

class NotiFicationTile extends StatefulWidget {
  const NotiFicationTile({super.key});

  @override
  State<NotiFicationTile> createState() => _NotiFicationTileState();
}

class _NotiFicationTileState extends State<NotiFicationTile> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              "Lorem Ipsum is simply dummy text The printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.",
              style: TextStyles.ktext12(context),
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          Container(
            height: size.height / 20,
            width: size.width / 9,
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Color.fromARGB(255, 87, 125, 146),
            ),
            child: Image.asset(Images.vehicle_icon),
          ),
        ],
      ),
    );
  }
}
