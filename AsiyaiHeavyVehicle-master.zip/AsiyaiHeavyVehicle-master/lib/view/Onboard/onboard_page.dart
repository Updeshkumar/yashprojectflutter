import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/view/SigunUp/signup_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../../utils/size_config.dart';
import '../../utils/text_styles.dart';
import '../../widgets/logo_text.dart';

class OnBoardPage extends StatefulWidget {
  const OnBoardPage({super.key});

  @override
  State<OnBoardPage> createState() => _OnBoardPageState();
}

class _OnBoardPageState extends State<OnBoardPage> {
  PageController controller = PageController();

  //

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    Widget page1() {
      return Container(
        height: size.height,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Images.onboard_bg1),
            fit: BoxFit.fill,
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  LogoText(),
                  SizedBox(
                    height: size.height / 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        style: TextStyles.ktext20(context),
                        children: [
                          TextSpan(
                            text: "All Types of ".tr().toString(),
                          ),
                          TextSpan(
                            text: " Machines ".tr().toString(),
                            style: TextStyles.ktext20(context)
                                .copyWith(color: Colours.YELLOW_DARK),
                          ),
                          TextSpan(
                            text: "Available".tr().toString(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: size.height / 40,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: size.width / 18),
                    child: Text(
                      "Text(String data, {Key? key, TextStyle? style, StrutStyle? strutStyle, TextAlign? textAlign, TextDirection? textDirection, Locale? locale, bool? softWrap, TextOverflow? overflow, double? textScaleFactor, int? maxLines, String? semanticsLabel, TextWidthBasis? textWidthBasis, TextHeightBehavior?",
                      style: TextStyles.ktext14(context),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  SizedBox(
                    height: size.height / 10,
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: (() => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => SignUp()))),
              child: Container(
                margin: EdgeInsets.symmetric(
                    horizontal: size.width / 10, vertical: size.height / 40),
                height: size.height / 16,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colours.YELLOW_DARK,
                ),
                child: Center(
                  child: Text(
                    "START",
                    style: TextStyles.ktext14(context).copyWith(
                        color: Colors.black, fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            )
          ],
        ),
      );
    }

    Widget page2() {
      return Container(
        height: size.height,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Images.onboard_bg2),
            fit: BoxFit.fill,
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: Column(
                children: [
                  SizedBox(
                    height: getSize(35),
                  ),
                  Container(
                    height: size.height / 13.33,
                    width: size.width / 2.4,
                    child: Image.asset(
                      Images.splash_logo,
                    ),
                  ),
                  SizedBox(
                    height: getSize(10),
                  ),
                  Text(
                    "BEST ONLINE",
                    style: TextStyles.ktext20(context).copyWith(
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: getSize(20),
                  ),
                  Text(
                    "HEAVY VEHICLE",
                    style: TextStyles.ktext32(context).copyWith(
                      color: Colours.YELLOW_DARK,
                      shadows: <Shadow>[
                        Shadow(
                          offset: Offset(0.5, 4),
                          blurRadius: 3.0,
                          color: Colors.black26,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: getSize(10),
                  ),
                  Text(
                    "RENT SERVICES",
                    style: TextStyles.ktext24(context).copyWith(
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: size.height / 5,
                  ),
                  RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      style: TextStyles.ktext20(context),
                      children: [
                        TextSpan(
                          text: "All Types of ".tr().toString(),
                        ),
                        TextSpan(
                          text: " Machines ".tr().toString(),
                          style: TextStyles.ktext20(context)
                              .copyWith(color: Colours.YELLOW_DARK),
                        ),
                        TextSpan(
                          text: "Available".tr().toString(),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: size.height / 20,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: size.width / 18),
                    child: Text(
                      "Text(String data, {Key? key, TextStyle? style, StrutStyle? strutStyle, TextAlign? textAlign, TextDirection? textDirection, Locale? locale, bool? softWrap, TextOverflow? overflow, double? textScaleFactor, int? maxLines, String? semanticsLabel, TextWidthBasis? textWidthBasis, TextHeightBehavior?",
                      style: TextStyles.ktext14(context),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  SizedBox(
                    height: size.height / 10,
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: (() => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => SignUp()))),
              child: Container(
                margin: EdgeInsets.symmetric(
                    horizontal: size.width / 10, vertical: size.height / 40),
                height: size.height / 16,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colours.YELLOW_DARK,
                ),
                child: Center(
                  child: Text(
                    "Started",
                    style: TextStyles.ktext14(context).copyWith(
                        color: Colors.black, fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            )
          ],
        ),
      );
    }

    return Scaffold(
        body: PageView(
      controller: controller,
      children: [
        page1(),
        // page2(),
      ],
    ));
  }
}
