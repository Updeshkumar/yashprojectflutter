import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/sub_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/view/SubContructor/SubContDetails/sub_details.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

import '../../utils/colour_resource.dart';
import '../../utils/fade_image.dart';
import '../../utils/images.dart';

class SubcontructorProduct extends StatefulWidget {
  SubcontructorList? obj;

  SubcontructorProduct({this.obj});

  @override
  State<SubcontructorProduct> createState() => _SubcontructorProductState();
}

class _SubcontructorProductState extends State<SubcontructorProduct> {
  // List<String> imageList = [];
  // List? imageList;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // if (widget.obj!.subcontractorImage!.contains("[") &&
    //     widget.obj!.subcontractorImage!.contains("]")) {
    //   imageList = jsonDecode(widget.obj!.subcontractorImage!);
    // } else {
    //   imageList = null;
    // }

    // print(">>>>>>>>>>>>" + imageList.toString());
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                child: SubContractorDetailsPage(
                  obj: widget.obj,
                ),
                type: PageTransitionType.leftToRight));
      },
      child: Container(
        height: size.height / 8,
        width: size.width / 3.6,
        margin: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: Colours.PRIMARY_GREY_LIGHT.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: FadeImageWithError(
              placeImage: Images.person_icon,
              imgPath: widget.obj!.subcontractorImage != null
                  ? "http://asiyaiheavyvehicle.com" +
                      widget.obj!.subcontractorImage!
                  : Images.person_icon,
              fit: BoxFit.fill,
            )),
      ),
    );
  }
}
