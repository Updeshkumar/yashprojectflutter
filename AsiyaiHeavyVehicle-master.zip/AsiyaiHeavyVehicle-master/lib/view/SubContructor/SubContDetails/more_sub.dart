import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/sub_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/view/SubContructor/SubContDetails/sub_details.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/fade_image.dart';
import '../../../utils/images.dart';
import '../../../utils/text_styles.dart';

class MoreSubContructors extends StatefulWidget {
  const MoreSubContructors({super.key});

  @override
  State<MoreSubContructors> createState() => _MoreSubContructorsState();
}

class _MoreSubContructorsState extends State<MoreSubContructors> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: AppBar(
          backgroundColor: Colours.PRIMARY_BLUE_MILD,
          title: Text("Sub Contructors"),
        ),
        // appBar: buildBar(context, model),
        body: Padding(
            padding:
                EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
            child: Consumer<UserProvider>(
              builder: ((context, model, child) {
                return model.myHomeData != null &&
                        model.myHomeData!.data != null &&
                        model.myHomeData!.data!.subcontructorList != null &&
                        model.myHomeData!.data!.subcontructorList!.length > 0
                    ? ListView.builder(
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        itemCount:
                            model.myHomeData!.data!.subcontructorList!.length,
                        itemBuilder: (context, index) {
                          SubcontructorList obj =
                              model.myHomeData!.data!.subcontructorList![index];
                          return MoreSubProduct(
                            obj: obj,
                          );
                        })
                    : Center(
                        child: CircularProgressIndicator(
                          color: Colours.YELLOW_DARK,
                        ),
                      );
              }),
            )),
      );
    });
  }

  void _handleSearchStart() {
    setState(() {
      _IsSearching = true;
    });
  }

  serachClose() {
    setState(() {
      _IsSearching = false;
      _searchQuery.clear();
    });
  }

  void _handleSearchEnd(UserProvider model) {
    setState(() {
      this.actionIcon = new Icon(
        Icons.search,
        color: Colors.white,
      );
      this.appBarTitle = new Text(
        "Sub Contructors",
        style: new TextStyle(color: Colors.white),
      );

      _IsSearching = false;
      _searchQuery.clear();
    });
  }

  String? hintText = "Search ...";
  buildBar(BuildContext context, UserProvider model) {
    return new AppBar(
        //centerTitle: true,
        backgroundColor: Colours.PRIMARY_BLUE,
        title: appBarTitle,
        actions: <Widget>[
          new IconButton(
            icon: actionIcon,
            onPressed: () {
              setState(() {
                if (this.actionIcon.icon == Icons.search) {
                  this.actionIcon = new Icon(
                    Icons.close,
                    color: Colors.white,
                  );
                  this.appBarTitle = new TextField(
                    controller: _searchQuery,
                    style: new TextStyle(
                      color: Colors.white,
                    ),
                    decoration: new InputDecoration(
                        prefixIcon: new Icon(Icons.search, color: Colors.white),
                        hintText: hintText,
                        hintStyle: new TextStyle(color: Colors.white)),
                    onChanged: (str) {},
                  );
                  _handleSearchStart();
                } else {
                  _handleSearchEnd(model);
                }
              });
            },
          ),
        ]);
  }

  Widget appBarTitle = new Text(
    "Sub Contructors",
    style: new TextStyle(color: Colors.white),
  );
  Icon actionIcon = new Icon(
    Icons.search,
    color: Colors.white,
  );
  final key = new GlobalKey<ScaffoldState>();
  final TextEditingController _searchQuery = new TextEditingController();
  bool? _IsSearching = false;
  String _searchText = "";
}

class MoreSubProduct extends StatefulWidget {
  SubcontructorList? obj;
  MoreSubProduct({this.obj});

  @override
  State<MoreSubProduct> createState() => _MoreSubProductState();
}

class _MoreSubProductState extends State<MoreSubProduct> {
  List? imageList;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // if (widget.obj!.subcontractorImage!.contains("[]")) {
    // imageList = jsonDecode(widget.obj!.subcontractorImage!);
    // } else {
    //   imageList = null;
    // }

    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                child: SubContractorDetailsPage(
                  obj: widget.obj,
                ),
                type: PageTransitionType.rightToLeft));
      },
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Container(
                  height: size.height / 8,
                  width: size.width / 4,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: FadeImageWithError(
                        placeImage: Images.person_icon,
                        imgPath:
                            ![null, ""].contains(widget.obj!.subcontractorImage)
                                ? "http://asiyaiheavyvehicle.com" +
                                    widget.obj!.subcontractorImage!
                                : Images.person_icon,
                        fit: BoxFit.fill,
                      )),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.obj!.contractorname.toString().toUpperCase(),
                          style: TextStyles.ktext16(context)
                              .copyWith(fontWeight: FontWeight.bold),
                        ),
                        // if (![null, ""].contains(widget.obj!.country) &&
                        //     ![null, ""].contains(widget.obj!.distict))
                        widget.obj!.address!.districtId != null &&
                                widget.obj!.address!.stateId != null
                            ? Text(
                                widget.obj!.address!.districtId!.districtName! +
                                    " , " +
                                    widget.obj!.address!.stateId!.stateName! +
                                    "  ",
                                style: TextStyles.ktext14(context).copyWith(
                                  color: Colours.PRIMARY_GREY_LIGHT,
                                  fontWeight: FontWeight.w400,
                                ),
                                maxLines: 2,
                              )
                            : Container(),
                        SizedBox(
                          height: size.height / 80,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "License Number: ",
                              style: TextStyles.ktext16(context)
                                  .copyWith(fontWeight: FontWeight.w400),
                            ),
                            Expanded(
                              child: Text(
                                "${widget.obj!.licenseNumber.toString()}",
                                style: TextStyles.ktext16(context),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: Colours.PRIMARY_GREY,
          ),
        ],
      ),
    );
  }
}
