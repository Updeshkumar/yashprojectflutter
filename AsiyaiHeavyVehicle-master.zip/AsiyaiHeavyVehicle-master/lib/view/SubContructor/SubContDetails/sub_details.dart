import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/sub_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/SubContructor/SubContDetails/requestButton.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/fade_image.dart';
import '../../../utils/images.dart';
import '../../../widgets/important_text.dart';
import '../../../widgets/row_text.dart';

class SubContractorDetailsPage extends StatefulWidget {
  SubcontructorList? obj;
  SubContractorDetailsPage({this.obj});

  @override
  State<SubContractorDetailsPage> createState() =>
      _SubContractorDetailsPageState();
}

class _SubContractorDetailsPageState extends State<SubContractorDetailsPage> {
  getData() {
    if (myProvider!.userType != null &&
        myProvider!.userType!.toLowerCase().contains("sub")) {
      myProvider!.getSubContructorData();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 100), () => getData());
  }

  UserProvider? myProvider;

  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context, listen: false);
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(size.height / 16),
          child: AppBar(
            elevation: 0.0,
            title: Text(
              "Sub Contructor Details",
              style: TextStyles.ktext20(context),
            ),
            backgroundColor: Colours.PRIMARY_GREY,
          ),
        ),
        body: Container(
          padding:
              EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ShowImage(
                        image: widget.obj!.subcontractorImageRight != null
                            ? "http://asiyaiheavyvehicle.com" +
                                widget.obj!.subcontractorImageRight!
                            : Images.person_icon,
                      ),
                      ShowImage(
                        image: ![null, ""]
                                .contains(widget.obj!.subcontractorImageBack)
                            ? "http://asiyaiheavyvehicle.com" +
                                widget.obj!.subcontractorImageBack!
                            : Images.person_icon,
                      ),
                      ShowImage(
                        image: ![null, ""]
                                .contains(widget.obj!.subcontractorImageLeft)
                            ? "http://asiyaiheavyvehicle.com" +
                                widget.obj!.subcontractorImageLeft!
                            : Images.person_icon,
                      ),
                    ],
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  Expanded(
                    child: Container(
                      height: size.height / 3,
                      width: double.infinity,
                      margin: EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: FadeImageWithError(
                            placeImage: Images.person_icon,
                            imgPath: ![null, ""]
                                    .contains(widget.obj!.subcontractorImage)
                                ? "http://asiyaiheavyvehicle.com" +
                                    widget.obj!.subcontractorImage!
                                : Images.person_icon,
                            fit: BoxFit.fill,
                          )),
                    ),
                  ),
                ],
              ),
              ImportantText(name: widget.obj!.contractorname.toString()),
              // if (![null, ""].contains(widget.obj!.address!.districtId!.districtName!) &&
              //     ![null, ""].contains(widget.obj!.distict))
              widget.obj!.address!.districtId != null &&
                      widget.obj!.address!.stateId != null
                  ? Text(
                      widget.obj!.address!.districtId!.districtName! +
                          " , " +
                          widget.obj!.address!.stateId!.stateName! +
                          "  ",
                      style: TextStyles.ktext14(context)
                          .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
                    )
                  : Container(),
              SizedBox(
                height: size.height / 40,
              ),
              Container(
                padding: EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  border:
                      Border.all(color: Colours.PRIMARY_BLUE_MILD, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Container(
                      height: 50,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      margin: const EdgeInsets.only(bottom: 20),
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(12),
                          topRight: Radius.circular(12),
                        ),
                        color: Colours.PRIMARY_GREY,
                      ),
                      child: Row(
                        children: [
                          Text(
                            "Details ",
                            style: TextStyles.ktext18(context),
                          ),
                        ],
                      ),
                    ),
                    // Rowtext(
                    //     title1: "SubContructor Name",
                    //     title2: widget.obj!.contractorname.toString()),
                    Rowtext(
                        title1: "Type of Work",
                        title2: widget.obj!.typeofwork.toString()),
                    Rowtext(
                      title1: "Experience ",
                      title2: widget.obj!.expriencesinyear.toString(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: myProvider!.sub_data != null &&
                myProvider!.sub_data!.id == widget.obj!.id
            ? InkWell(
                onTap: () {
                  showTostMsg("This is Added By You !!");
                },
                child: Container(
                  height: 45,
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 15),
                  decoration: BoxDecoration(
                    color: Colours.GREEN_LIGHT,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: Text(
                      "Your Details",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black),
                    ),
                  ),
                ),
              )
            : SUbRequestButton(
                obj: widget.obj,
              ));
  }
}

class ShowImage extends StatelessWidget {
  String image;
  ShowImage({required this.image});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(bottom: 3),
      height: size.height / 10,
      width: 80,
      decoration: BoxDecoration(
        border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
        borderRadius: BorderRadius.circular(10),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: FadeInImage.assetNetwork(
            placeholder: Images.person_icon,
            placeholderFit: BoxFit.contain,
            fit: BoxFit.fill,
            image: image.toString()),
      ),
    );
  }
}
