import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/datamodel/sub_cont_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';

import '../../../data/respnse/sub_details_model.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/common.dart';
import '../../../utils/text_styles.dart';
import '../../../widgets/show_dialog.dart';

class SUbRequestButton extends StatefulWidget {
  SubcontructorList? obj;
  SUbRequestButton({this.obj});

  @override
  State<SUbRequestButton> createState() => _SUbRequestButtonState();
}

class _SUbRequestButtonState extends State<SUbRequestButton> {
  Size? size;
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;

    return Consumer<UserProvider>(builder: (context, model, child) {
      return buildRquestButton(model);
    });
  }

  buildRquestButton(UserProvider model) {
    return widget.obj!.isReserved == true
        ? GestureDetector(
            onTap: () async {
              showTostMsg("Already Reserved!!");
            },
            child: Container(
              height: size!.height / 18,
              margin: EdgeInsets.symmetric(
                  horizontal: size!.width / 30, vertical: 20),
              decoration: BoxDecoration(
                color: Colours.GREEN_LIGHT,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  "Already Reserved",
                  style:
                      TextStyles.ktext18(context).copyWith(color: Colors.white),
                ),
              ),
            ),
          )
        : widget.obj!.myRequest == false
            ? GestureDetector(
                onTap: () async {
                  model.postSUBRequest(context, Id: widget.obj!.id.toString());
                },
                child: Container(
                  height: size!.height / 18,
                  margin: EdgeInsets.symmetric(
                      horizontal: size!.width / 30, vertical: 20),
                  decoration: BoxDecoration(
                    color: Colours.YELLOW_LIGHT,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      " REQUEST",
                      style: TextStyles.ktext18(context)
                          .copyWith(color: Colours.PRIMARY_BLACK),
                    ),
                  ),
                ),
              )
            : GestureDetector(
                onTap: () async {
                  showTostMsg("Already Requested!!");
                },
                child: Container(
                  height: size!.height / 18,
                  margin: EdgeInsets.symmetric(
                      horizontal: size!.width / 30, vertical: 20),
                  decoration: BoxDecoration(
                    color: Colours.SKY_BLUE_LIGHT,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      "Already Request!!",
                      style: TextStyles.ktext18(context)
                          .copyWith(color: Colours.PRIMARY_BLACK),
                    ),
                  ),
                ),
              );
  }
}
