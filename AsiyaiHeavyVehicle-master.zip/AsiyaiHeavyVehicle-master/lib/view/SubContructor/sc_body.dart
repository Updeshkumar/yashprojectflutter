import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/sub_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/view/SubContructor/SubContDetails/more_sub.dart';
import 'package:asiayai_heavy_vehicle_app/view/SubContructor/sc_prouct.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/blank_dta.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/product_shimmer.dart';

class SubContructorDetailasList extends StatefulWidget {
  const SubContructorDetailasList({super.key});

  @override
  State<SubContructorDetailasList> createState() =>
      _SubContructorDetailasListState();
}

class _SubContructorDetailasListState extends State<SubContructorDetailasList> {
  //
  @override
  void initState() {
    // TODO: implement initState
    //  Future.delayed(Duration(milliseconds: 200), () => getData());
    super.initState();
  }

  List imageList = [];
  getData() async {
    await Provider.of<UserProvider>(context, listen: false)
        .getSubContructorData();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Sub Contructor",
                style: TextStyles.ktext18(context),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      PageTransition(
                          child: MoreSubContructors(),
                          type: PageTransitionType.bottomToTop));
                },
                child: Text(
                  "View All",
                  style: TextStyles.ktext16(context)
                      .copyWith(color: Colours.PRIMARY_GREY_MILD),
                ),
              ),
            ],
          ),
          Container(
            height: size.height / 7,
            margin: EdgeInsets.only(top: 8),
            child: Consumer<UserProvider>(
              builder: (context, model, child) {
                return model.myHomeData != null &&
                        model.myHomeData!.data != null &&
                        model.myHomeData!.data!.subcontructorList != null &&
                        model.myHomeData!.data!.subcontructorList!.length > 0
                    ? ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount:
                            model.myHomeData!.data!.subcontructorList!.length,
                        itemBuilder: ((context, index) {
                          SubcontructorList obj =
                              model.myHomeData!.data!.subcontructorList![index];

                          return SubcontructorProduct(obj: obj);
                        }))
                    : BlankData();
              },
            ),
          )
        ],
      ),
    );
  }
}
