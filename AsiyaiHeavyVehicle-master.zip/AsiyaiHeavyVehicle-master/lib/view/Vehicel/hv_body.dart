import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/vehicel_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/VehicleDetails/more_vehicles.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/hv_product.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/blank_dta.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/product_shimmer.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

class HeavyVehicleBody extends StatefulWidget {
  const HeavyVehicleBody({super.key});

  @override
  State<HeavyVehicleBody> createState() => _HeavyVehicleBodyState();
}

class _HeavyVehicleBodyState extends State<HeavyVehicleBody> {
  //
  @override
  void initState() {
    // TODO: implement initState

    super.initState();
    // Provider.of<UserProvider>(context, listen: false).getVehicleData();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Heavy Vehicle",
                style: TextStyles.ktext18(context),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      PageTransition(
                          child: MoreVehicles(),
                          type: PageTransitionType.bottomToTop));
                },
                child: Text(
                  "View All",
                  style: TextStyles.ktext16(context)
                      .copyWith(color: Colours.PRIMARY_GREY_MILD),
                ),
              ),
            ],
          ),
          Container(
            height: size.height / 7,
            margin: EdgeInsets.only(top: 8),
            child: Consumer<UserProvider>(
              builder: (context, model, child) {
                return model.myHomeData != null &&
                        model.myHomeData!.data != null &&
                        model.myHomeData!.data!.vehiclelist != null &&
                        model.myHomeData!.data!.vehiclelist!.length > 0
                    ? ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: model.myHomeData!.data!.vehiclelist!.length,
                        itemBuilder: ((context, index) {
                          HomeVehiclelist obj =
                              model.myHomeData!.data!.vehiclelist![index];
                          return HVProduct(
                            obj: obj,
                          );
                        }))
                    : BlankData();
              },
            ),
          )
        ],
      ),
    );
  }
}
