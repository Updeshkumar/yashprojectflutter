import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/vehicel_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/fade_image.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/VehicleDetails/vehicle_details.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

class HVProduct extends StatefulWidget {
  HomeVehiclelist? obj;
  HVProduct({this.obj});
  @override
  State<HVProduct> createState() => _HVProductState();
}

class _HVProductState extends State<HVProduct> {
  // List? imageList = [];
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    // if (widget.obj!.vehicleImage!.contains("[") &&
    //     widget.obj!.vehicleImage!.contains("]")) {
    //   imageList = jsonDecode(widget.obj!.vehicleImage!);
    // } else {
    //   imageList = null;
    // }
    return InkWell(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                child: HeavyVehicleDeatilsPage(
                  obj: widget.obj,
                ),
                type: PageTransitionType.leftToRight));
      },
      child: Container(
        height: size.height / 8,
        width: size.width / 3.6,
        margin: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: Colours.PRIMARY_GREY_LIGHT.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        // child: Image.network(list[0].toString().trim()),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: FadeImageWithError(
            placeImage: Images.vehicle_icon,
            imgPath: widget.obj!.vehicleImage != null
                ? "http://asiyaiheavyvehicle.com" + widget.obj!.vehicleImage!
                : Images.vehicle_icon,
            fit: BoxFit.fill,
          ),
        ),
      ),
    );
  }
}
