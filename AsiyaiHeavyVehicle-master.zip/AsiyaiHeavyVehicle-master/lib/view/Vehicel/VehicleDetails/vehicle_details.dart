import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/vehicel_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/VehicleDetails/request_button.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/row_text.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/important_text.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../utils/fade_image.dart';
import '../../../utils/text_styles.dart';
import '../../../widgets/row_text.dart';

class HeavyVehicleDeatilsPage extends StatefulWidget {
  HomeVehiclelist? obj;

  HeavyVehicleDeatilsPage({this.obj});

  @override
  State<HeavyVehicleDeatilsPage> createState() =>
      _HeavyVehicleDeatilsPageState();
}

class _HeavyVehicleDeatilsPageState extends State<HeavyVehicleDeatilsPage> {
  List<Vehiclelist> list = [];
  getData() {
    if (myProvider!.userType != null &&
        myProvider!.userType!.toLowerCase().contains("sub")) {
      myProvider!.getSubContructorData();
    }
  }

  UserProvider? myProvider;

  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context, listen: false);
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(size.height / 16),
        child: AppBar(
          elevation: 0.0,
          title: Text(
            "Vehicle Details",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
        ),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: size.width / 30, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: size.height / 3,
              width: double.infinity,
              margin: EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ShowImage(
                        image: widget.obj!.vehicleImageBack != null
                            ? "http://asiyaiheavyvehicle.com" +
                                widget.obj!.vehicleImageBack!
                            : Images.vehicle_icon,
                      ),
                      ShowImage(
                        image: widget.obj!.vehicleImageLeft != null
                            ? "http://asiyaiheavyvehicle.com" +
                                widget.obj!.vehicleImageLeft!
                            : Images.vehicle_icon,
                      ),
                      ShowImage(
                        image: widget.obj!.vehicleImageRight != null
                            ? "http://asiyaiheavyvehicle.com" +
                                widget.obj!.vehicleImageRight!
                            : Images.vehicle_icon,
                      ),
                    ],
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  Expanded(
                    child: Container(
                      height: size.height / 3,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: FadeImageWithError(
                          placeImage: Images.vehicle_icon,
                          imgPath: widget.obj!.vehicleImage != null
                              ? "http://asiyaiheavyvehicle.com" +
                                  widget.obj!.vehicleImage!
                              : Images.vehicle_icon,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            ImportantText(name: widget.obj!.vehicalName.toString()),
            // if (![null, ""].contains(widget.obj!.country) &&
            //     ![null, ""].contains(widget.obj!.distict))
            widget.obj!.address!.districtId != null &&
                    widget.obj!.address!.stateId != null
                ? Text(
                    widget.obj!.address!.districtId!.districtName! +
                        " , " +
                        widget.obj!.address!.stateId!.stateName! +
                        "  ",
                    style: TextStyles.ktext14(context)
                        .copyWith(color: Colours.PRIMARY_GREY_LIGHT),
                  )
                : Container(),
            SizedBox(
              height: size.height / 40,
            ),
            Container(
              padding: EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                border: Border.all(color: Colours.PRIMARY_BLUE_MILD, width: 2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Container(
                    height: 50,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(12),
                        topRight: Radius.circular(12),
                      ),
                      color: Colours.PRIMARY_GREY,
                    ),
                    child: Row(
                      children: [
                        Text(
                          "Details ",
                          style: TextStyles.ktext18(context),
                        ),
                      ],
                    ),
                  ),
                  Rowtext(
                      title1: "Model Name",
                      title2: widget.obj!.vehiclemodelnumber.toString()),
                  Rowtext(
                      title1: "Manufacture Year",
                      title2: widget.obj!.manufactureDate.toString()),
                  Rowtext(
                    title1: "Owner Name",
                    title2: widget.obj!.ownername.toString(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: myProvider!.vehcileDashList != null &&
              myProvider!.vehcileDashList.length > 0 &&
              myProvider!.vehcileDashList[0].id == widget.obj!.id
          ? InkWell(
              onTap: () {
                showTostMsg("This is Added By You !!");
              },
              child: Container(
                height: 45,
                margin:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 15),
                decoration: BoxDecoration(
                  color: Colours.GREEN_LIGHT,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    "Your Details",
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black),
                  ),
                ),
              ),
            )
          : RequestButton(
              obj: widget.obj,
            ),
    );
  }
}

class ShowImage extends StatelessWidget {
  String image;
  ShowImage({required this.image});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(bottom: 3),
      height: size.height / 10,
      width: 80,
      decoration: BoxDecoration(
        border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
        borderRadius: BorderRadius.circular(10),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: FadeImageWithError(
          placeImage: Images.vehicle_icon,
          imgPath: image != null ? image : Images.vehicle_icon,
          fit: BoxFit.fill,
        ),
      ),
    );
  }
}
