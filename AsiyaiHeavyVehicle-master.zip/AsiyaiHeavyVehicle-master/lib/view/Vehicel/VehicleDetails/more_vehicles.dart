import 'dart:convert';

import 'package:asiayai_heavy_vehicle_app/data/new_model/home_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/vehicel_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/VehicleDetails/vehicle_details.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '../../../utils/text_styles.dart';

class MoreVehicles extends StatefulWidget {
  const MoreVehicles({super.key});

  @override
  State<MoreVehicles> createState() => _MoreVehiclesState();
}

class _MoreVehiclesState extends State<MoreVehicles> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(
      builder: (context, model, child) {
        return Scaffold(
          backgroundColor: Colours.PRIMARY_BLUE,
          appBar: AppBar(
            backgroundColor: Colours.PRIMARY_BLUE_MILD,
            title: Text("Heavy Vehicles"),
          ),
          //appBar: buildBar(context, model),
          body: Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: size.width / 30, vertical: 8),
              child: Consumer<UserProvider>(
                builder: ((context, model, child) {
                  return model.myHomeData != null &&
                          model.myHomeData!.data != null &&
                          model.myHomeData!.data!.vehiclelist != null &&
                          model.myHomeData!.data!.vehiclelist!.length > 0
                      ? ListView.builder(
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          itemCount:
                              model.myHomeData!.data!.vehiclelist!.length,
                          itemBuilder: (context, index) {
                            HomeVehiclelist obj =
                                model.myHomeData!.data!.vehiclelist![index];
                            return MoreVehicleProdct(
                              obj: obj,
                            );
                          })
                      : Center(
                          child: CircularProgressIndicator(
                            color: Colours.YELLOW_DARK,
                          ),
                        );
                }),
              )),
        );
      },
    );
  }

  void _handleSearchStart() {
    setState(() {
      _IsSearching = true;
    });
  }

  serachClose() {
    setState(() {
      _IsSearching = false;
      _searchQuery.clear();
    });
  }

  void _handleSearchEnd(UserProvider model) {
    setState(() {
      this.actionIcon = new Icon(
        Icons.search,
        color: Colors.white,
      );
      this.appBarTitle = new Text(
        "Vehicles",
        style: new TextStyle(color: Colors.white),
      );
      //  model.searchVehicle(null);
      _IsSearching = false;
      _searchQuery.clear();
    });
  }

  String? hintText = "Search ...";
  buildBar(BuildContext context, UserProvider model) {
    return new AppBar(
        //centerTitle: true,
        backgroundColor: Colours.PRIMARY_BLUE,
        title: appBarTitle,
        actions: <Widget>[
          new IconButton(
            icon: actionIcon,
            onPressed: () {
              setState(() {
                if (this.actionIcon.icon == Icons.search) {
                  this.actionIcon = new Icon(
                    Icons.close,
                    color: Colors.white,
                  );
                  this.appBarTitle = new TextField(
                    controller: _searchQuery,
                    style: new TextStyle(
                      color: Colors.white,
                    ),
                    decoration: new InputDecoration(
                        prefixIcon: new Icon(Icons.search, color: Colors.white),
                        hintText: hintText,
                        hintStyle: new TextStyle(color: Colors.white)),
                    onChanged: (str) {
                      // model.searchVehicle(str);
                    },
                  );
                  _handleSearchStart();
                } else {
                  _handleSearchEnd(model);
                }
              });
            },
          ),
        ]);
  }

  Widget appBarTitle = new Text(
    "Vehicles",
    style: new TextStyle(color: Colors.white),
  );
  Icon actionIcon = new Icon(
    Icons.search,
    color: Colors.white,
  );
  final key = new GlobalKey<ScaffoldState>();
  final TextEditingController _searchQuery = new TextEditingController();
  bool? _IsSearching = false;
  String _searchText = "";
}

class MoreVehicleProdct extends StatefulWidget {
  HomeVehiclelist? obj;
  MoreVehicleProdct({this.obj});

  @override
  State<MoreVehicleProdct> createState() => _MoreVehicleProdctState();
}

class _MoreVehicleProdctState extends State<MoreVehicleProdct> {
//  List? imageList = [];
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // if (widget.obj!.vehicleImage!.contains("[") &&
    //     widget.obj!.vehicleImage!.contains("]")) {
    //   imageList = jsonDecode(widget.obj!.vehicleImage!);
    // }
    //  final list = value.split(',');
    return InkWell(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                child: HeavyVehicleDeatilsPage(
                  obj: widget.obj,
                ),
                type: PageTransitionType.rightToLeft));
      },
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Container(
                  height: size.height / 8,
                  width: size.width / 4,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: FadeInImage.assetNetwork(
                      placeholder: Images.vehicle_icon,
                      placeholderFit: BoxFit.none,
                      image: widget.obj!.vehicleImage != null
                          ? "http://asiyaiheavyvehicle.com" +
                              widget.obj!.vehicleImage!
                          : Images.vehicle_icon,
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.obj!.vehicalName.toString().toUpperCase(),
                          style: TextStyles.ktext16(context)
                              .copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(
                          height: 6,
                        ),
                        // if (![null, ""].contains(widget.obj!.country) &&
                        //     ![null, ""].contains(widget.obj!.distict))
                        widget.obj!.address!.districtId != null &&
                                widget.obj!.address!.stateId != null
                            ? Text(
                                widget.obj!.address!.districtId!.districtName! +
                                    " , " +
                                    widget.obj!.address!.stateId!.stateName! +
                                    "  ",
                                style: TextStyles.ktext14(context).copyWith(
                                    fontWeight: FontWeight.w400,
                                    color: Colours.PRIMARY_GREY_LIGHT),
                                maxLines: 2,
                              )
                            : Container(),
                        SizedBox(
                          height: size.height / 80,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Vehicle Number: ",
                              style: TextStyles.ktext16(context)
                                  .copyWith(fontWeight: FontWeight.w400),
                            ),
                            Expanded(
                              child: Text(
                                "${widget.obj!.vehicleregistrationnumber.toString()}",
                                style: TextStyles.ktext16(context),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: Colours.PRIMARY_GREY,
          ),
        ],
      ),
    );
  }
}
