import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/aadhar_image_item.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AddLabourImage extends StatefulWidget {
  const AddLabourImage({super.key});

  @override
  State<AddLabourImage> createState() => _AddLabourImageState();
}

class _AddLabourImageState extends State<AddLabourImage> {
  File? selectedImage;

  final picker = ImagePicker();

  Future getImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        selectedImage = File(pickedFile.path);
      } else {
        print("No Image selected");
      }
    });
    // return selectedImage!;
  }

  Size? _size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: AppBar(
        backgroundColor: Colours.PRIMARY_GREY,
        title: Text("Add Labour Images"),
      ),
      body: ListView(
        children: [
          InkWell(
            onTap: () {
              getImage();
            },
            child: AadharImageItem(
              title: "Labour Image",
              selectedFile: selectedImage != null ? selectedImage : null,
            ),
          ),
        ],
      ),
      bottomNavigationBar: InkWell(
        onTap: () {
          if (selectedImage != null) {
            Navigator.pop(context, selectedImage);
          } else {
            showTostMsg("Please Select Image");
          }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Container(
            height: _size!.height * 0.05,
            decoration: BoxDecoration(
              color: Colours.YELLOW_LIGHT,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Text(
                "SUBMIT",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
