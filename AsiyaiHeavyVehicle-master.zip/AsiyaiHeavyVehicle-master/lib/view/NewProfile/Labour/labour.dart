import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/data/datamodel/labour_cont_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/add_aadhar_image.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/Labour/add_labour_image.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/textfield.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

class LabourRegister extends StatefulWidget {
  const LabourRegister({super.key});

  @override
  State<LabourRegister> createState() => _LabourRegisterState();
}

class _LabourRegisterState extends State<LabourRegister> {
  Size? _size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(_size!.height / 16),
        child: AppBar(
          title: Text(
            "Labour Contructor Register",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
        ),
      ),
      body: Consumer<UserProvider>(builder: (context, model, child) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: SingleChildScrollView(
            child: Column(
              children: [
                labourContructorWidget(model),
                labourDetailswidget(model),
                InkWell(
                  onTap: () async {
                    FocusScope.of(context).requestFocus(FocusNode());
                    if (labourContructorController.text.isEmpty &&
                        mobileCOntroller.text.isEmpty) {
                      showTostMsg("Enter Labour Contructor Details");
                      return;
                    }
                    if (labourWorkController.text.isEmpty &&
                        labourNumberController.text.isEmpty &&
                        professionalController.text.isEmpty &&
                        skilledLabourController.text.isEmpty &&
                        unskilledLabourController.text.isEmpty) {
                      showTostMsg("Enter Labour Details");
                      return;
                    }

                    if (finalSelctedAadhar != null &&
                        finalSelctedAadhar!.length > 0) {
                      if (labourFile != null) {
                        LabourContModel labourContModel = LabourContModel(
                            labourcontractorname:
                                labourContructorController.text,
                            labourwork: labourWorkController.text,
                            mobileNumber: mobileCOntroller.text,
                            lobourinnumber: labourNumberController.text,
                            skilledLabour: skilledLabourController.text,
                            unskiledLabour: unskilledLabourController.text,
                            proffesionalLabour: professionalController.text,
                            aadharback: finalSelctedAadhar![1],
                            aadharfront: finalSelctedAadhar![0],
                            labourImage: labourFile);
                        await model.labourDataPost(
                          context,
                          model: labourContModel,
                        );
                        print("HYY");
                      } else {
                        showTostMsg("Add Labour Image");
                      }
                    } else {
                      showTostMsg("Please Select Aadhar Images");
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Container(
                      height: _size!.height * 0.05,
                      decoration: BoxDecoration(
                        color: Colours.YELLOW_LIGHT,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Text(
                          "SUBMIT",
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  List<File>? finalSelctedAadhar = [];
  final labourContructorController = TextEditingController();
  final mobileCOntroller = TextEditingController();

  labourContructorWidget(UserProvider model) {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Labour Contructor Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          IconTextField(
            title: "Labour Contructor Name".tr().toString(),
            controller: labourContructorController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Mobile Number".tr().toString(),
            controller: mobileCOntroller,
            textInputType: TextInputType.phone,
            textInputFormatter: [
              LengthLimitingTextInputFormatter(10),
              FilteringTextInputFormatter.digitsOnly
            ],
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              List<File> selectFiles = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddAadharImages(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFiles)) {
                finalSelctedAadhar!.addAll(selectFiles);
                print("selectFiles.length : " + selectFiles.length.toString());
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Aadhar Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  //
  File? labourFile;
  final labourWorkController = TextEditingController();
  final labourNumberController = TextEditingController();
  final professionalController = TextEditingController();
  final skilledLabourController = TextEditingController();
  final unskilledLabourController = TextEditingController();

  labourDetailswidget(UserProvider model) {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Labour Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          IconTextField(
            title: "Labour Work".tr().toString(),
            controller: labourWorkController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Labour(In Numbers)".tr().toString(),
            controller: labourNumberController,
            textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
            textInputType: TextInputType.number,
          ),
          IconTextField(
            title: "Professional Labour(In Number)".tr().toString(),
            controller: professionalController,
            textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
            textInputType: TextInputType.number,
          ),
          IconTextField(
            title: "Skilled Labour(In Number)".tr().toString(),
            controller: skilledLabourController,
            textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
            textInputType: TextInputType.number,
          ),
          IconTextField(
            title: "UnSkilled Labour(In Number)".tr().toString(),
            controller: unskilledLabourController,
            textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
            textInputType: TextInputType.number,
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              File selectFiles = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddLabourImage(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFiles)) {
                labourFile = selectFiles;
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Labour Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
