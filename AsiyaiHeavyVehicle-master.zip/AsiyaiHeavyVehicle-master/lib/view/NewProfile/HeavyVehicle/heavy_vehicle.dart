import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/data/datamodel/heavy_vehicle_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/dat_container.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/add_aadhar_image.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/add_vehicle_images.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/show_dialog.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/textfield.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

class HeavyVehiclePostScreen extends StatefulWidget {
  const HeavyVehiclePostScreen({super.key});

  @override
  State<HeavyVehiclePostScreen> createState() => _HeavyVehiclePostScreenState();
}

class _HeavyVehiclePostScreenState extends State<HeavyVehiclePostScreen> {
  ////methods
  Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context, text: "Back");
        }));

    return request;
  }

  Size? _size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: _onBackButtonPressed,
      child: Scaffold(
          backgroundColor: Colours.PRIMARY_BLUE,
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(_size!.height / 16),
            child: AppBar(
              title: Text(
                "Heavy Vehicle Register",
                style: TextStyles.ktext20(context),
              ),
              backgroundColor: Colours.PRIMARY_GREY,
            ),
          ),
          body: Consumer<UserProvider>(builder: (context, model, child) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: _size!.height * 0.01,
                    ),
                    addVehicleWidget(),
                    ownerDetails(),
                    InkWell(
                      onTap: () async {
                        //Navigator.pop(context);
                        FocusScope.of(context).requestFocus(FocusNode());
                        if (vehicleNameController.text.isEmpty &&
                            registrationNUmberController.text.isEmpty &&
                            modelNumberController.text.isEmpty) {
                          showTostMsg("Please Enter Vehicle Details");
                          return;
                        }

                        if (companyNameController.text.isEmpty &&
                            ownerNameController.text.isEmpty &&
                            emailIdNUmber.text.isEmpty &&
                            phoneNumberController.text.isEmpty) {
                          showTostMsg("Please Enter Owner Details");
                          return;
                        }

                        if (finalVehicleImage != null &&
                            finalVehicleImage!.length > 0) {
                          if (finalSelctedAadhar != null &&
                              finalSelctedAadhar!.length > 0) {
                            HeavyVehicleModel heavyVehicleModel =
                                HeavyVehicleModel(
                              vehicalName: vehicleNameController.text,
                              vehiclemodelnumber: modelNumberController.text,
                              vehicleregistrationnumber:
                                  registrationNUmberController.text,
                              manufectoringDate: getDate(),
                              companyName: companyNameController.text,
                              ownername: ownerNameController.text,
                              emailId: emailIdNUmber.text,
                              alternativemobileNumber:
                                  phoneNumberController.text,
                              aadharImage1: finalSelctedAadhar![0],
                              aadharImage2: finalSelctedAadhar![1],
                              vehicleImage: finalVehicleImage![0],
                              vehicle_image_back: finalVehicleImage![1],
                              vehicle_image_left: finalVehicleImage![2],
                              vehicle_image_right: finalVehicleImage![3],
                            );
                            // print(getDate());
                            await model.heavyVehiclePost(
                              context,
                              model: heavyVehicleModel,
                            );
                          } else {
                            showTostMsg("Please Add Aadhar Images");
                          }
                        } else {
                          showTostMsg("Please Add Vehicle Images");
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Container(
                          height: _size!.height * 0.05,
                          decoration: BoxDecoration(
                            color: Colours.YELLOW_LIGHT,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Text(
                              "SUBMIT",
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          })),
    );
  }

  DateTime selectedDate = DateTime.now();
  bool showDate = false;
  Future<DateTime> selectDate(BuildContext context) async {
    final selected = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (selected != null && selected != selectedDate) {
      setState(() {
        selectedDate = selected;
      });
    }
    return selectedDate;
  }

//
  String getDate() {
    // ignore: unnecessary_null_comparison
    if (selectedDate == null) {
      return 'Select Date'.tr().toString();
    } else {
      return DateFormat('yyyy-MM-dd').format(selectedDate);
    }
  }

  List<File>? finalVehicleImage = [];
  final vehicleNameController = TextEditingController();
  final modelNumberController = TextEditingController();
  final registrationNUmberController = TextEditingController();
  final manufactureDateController = TextEditingController();
  addVehicleWidget() {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Vehicle Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          IconTextField(
            title: "Vehicle Name".tr().toString(),
            controller: vehicleNameController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Vehicle Model Number".tr().toString(),
            controller: modelNumberController,
          ),
          IconTextField(
            title: "Vehicle Registration Number".tr().toString(),
            controller: registrationNUmberController,
          ),
          DateContainer(
            onTap: () {
              selectDate(context);
              showDate = true;
            },
            date: showDate ? getDate() : "Manufacturing Year".tr().toString(),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              List<File> selectFile = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddVehicleImages(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFile)) {
                finalVehicleImage!.addAll(selectFile);
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Vehicle Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  List<File>? finalSelctedAadhar = [];
  final companyNameController = TextEditingController();
  final ownerNameController = TextEditingController();
  final emailIdNUmber = TextEditingController();
  final phoneNumberController = TextEditingController();
  ownerDetails() {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Owner Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(height: _size!.height * 0.02),
          IconTextField(
            title: "Company Name".tr().toString(),
            controller: companyNameController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Owner Name".tr().toString(),
            controller: ownerNameController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Email Id".tr().toString(),
            controller: emailIdNUmber,
            textInputType: TextInputType.emailAddress,
            // textInputFormatter: [
            //   FilteringTextInputFormatter.allow(
            //     // RegExp(
            //     //     r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$'),
            //   )
            // ],
          ),
          IconTextField(
            title: "Mobile Number".tr().toString(),
            controller: phoneNumberController,
            textInputType: TextInputType.phone,
            textInputFormatter: [
              LengthLimitingTextInputFormatter(10),
              FilteringTextInputFormatter.digitsOnly
            ],
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              List<File> selectFiles = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddAadharImages(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFiles)) {
                finalSelctedAadhar!.addAll(selectFiles);
                print("selectFiles.length : " + selectFiles.length.toString());
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Aadhar Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
