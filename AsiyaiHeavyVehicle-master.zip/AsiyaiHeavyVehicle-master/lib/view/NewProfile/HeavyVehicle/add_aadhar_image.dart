import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/aadhar_image_item.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AddAadharImages extends StatefulWidget {
  const AddAadharImages({super.key});

  @override
  State<AddAadharImages> createState() => _AddAadharImagesState();
}

class _AddAadharImagesState extends State<AddAadharImages> {
  File? selectedImage;
  File? selectedImage2;
  final picker = ImagePicker();
  List<File>? selectedAadharImgaes = [];

  Future getImage({String? back}) async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        back != null
            ? selectedImage2 = File(pickedFile.path)
            : selectedImage = File(pickedFile.path);
        selectedAadharImgaes!.add(File(pickedFile.path));
        print("length " + selectedAadharImgaes!.length.toString());
      } else {
        print("No Image selected");
      }
    });
    // return selectedImage!;
  }

  Size? _size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: AppBar(
        backgroundColor: Colours.PRIMARY_GREY,
        title: Text("Add Aadhar Images"),
      ),
      body: ListView(
        children: [
          InkWell(
            onTap: () {
              getImage();
            },
            child: AadharImageItem(
              title: "Aadhar Front Image",
              selectedFile: selectedImage != null ? selectedImage : null,
            ),
          ),
          InkWell(
              onTap: () {
                getImage(back: "back");
              },
              child: AadharImageItem(
                title: "Aadhar Back Image",
                selectedFile: selectedImage2 != null ? selectedImage2 : null,
              )),
        ],
      ),
      bottomNavigationBar: InkWell(
        onTap: () {
          if (selectedAadharImgaes != null &&
              selectedAadharImgaes!.length > 1) {
            Navigator.pop(context, selectedAadharImgaes);
          } else {
            showTostMsg("Please Select Images");
          }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Container(
            height: _size!.height * 0.05,
            decoration: BoxDecoration(
              color: Colours.YELLOW_LIGHT,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Text(
                "SUBMIT",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
