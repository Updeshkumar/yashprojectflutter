import 'package:flutter/material.dart';

import '../../../utils/colour_resource.dart';
import '../../../utils/text_styles.dart';

class DateContainer extends StatelessWidget {
  VoidCallback onTap;
  String date;
  DateContainer({required this.date, required this.onTap});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: 45,
      padding: EdgeInsets.symmetric(horizontal: size.width / 18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        color: Colours.PRIMARY_BLUE_MILD,
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: onTap,
            child: const Icon(
              Icons.date_range,
              color: Colours.PRIMARY_GREY_LIGHT,
            ),
          ),
          SizedBox(
            width: size.width / 36,
          ),
          Expanded(
              child: Text(
            date,
            style: TextStyles.ktext18(context).copyWith(
                color: Colours.PRIMARY_GREY_LIGHT, fontWeight: FontWeight.w300),
          ))
        ],
      ),
    );
  }
}
