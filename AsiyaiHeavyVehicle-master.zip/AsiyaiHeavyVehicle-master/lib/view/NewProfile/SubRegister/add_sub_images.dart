import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AddSubImages extends StatefulWidget {
  const AddSubImages({super.key});

  @override
  State<AddSubImages> createState() => _AddSubImagesState();
}

class _AddSubImagesState extends State<AddSubImages> {
  File? selectedImage;
  File? selectedImage2;
  File? selectedImage3;
  File? selectedImage4;
  final picker = ImagePicker();
  List<File>? selectedVehicleImgaes = [];

  Future getImage({String? from}) async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        if (from == "front") {
          selectedImage = File(pickedFile.path);
        } else if (from == "back") {
          selectedImage2 = File(pickedFile.path);
        } else if (from == "left") {
          selectedImage3 = File(pickedFile.path);
        } else if (from == "right") {
          selectedImage4 = File(pickedFile.path);
        }
        selectedVehicleImgaes!.add(File(pickedFile.path));
        print("length " + selectedVehicleImgaes!.length.toString());
      } else {
        print("No Image selected");
      }
    });
    // return selectedImage!;
  }

  Size? _size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: AppBar(
        backgroundColor: Colours.PRIMARY_BLUE_MILD,
        title: Text("Add Images"),
      ),
      body: ListView(
        children: [
          Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: () {
                    getImage(from: "front");
                  },
                  child: VehicleImageItem(
                    title: "First",
                    selectedFile: selectedImage != null ? selectedImage : null,
                  ),
                ),
              ),
              Expanded(
                child: InkWell(
                  onTap: () {
                    getImage(from: "back");
                  },
                  child: VehicleImageItem(
                    title: "Second",
                    selectedFile:
                        selectedImage2 != null ? selectedImage2 : null,
                  ),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: () {
                    getImage(from: "left");
                  },
                  child: VehicleImageItem(
                    title: "Third",
                    selectedFile:
                        selectedImage3 != null ? selectedImage3 : null,
                  ),
                ),
              ),
              Expanded(
                child: InkWell(
                  onTap: () {
                    getImage(from: "right");
                  },
                  child: VehicleImageItem(
                    title: "Fouth",
                    selectedFile:
                        selectedImage4 != null ? selectedImage4 : null,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: InkWell(
        onTap: () {
          if (selectedVehicleImgaes != null &&
              selectedVehicleImgaes!.length > 3) {
            Navigator.pop(context, selectedVehicleImgaes);
          } else {
            showTostMsg("Please Select All Images");
          }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Container(
            height: _size!.height * 0.05,
            decoration: BoxDecoration(
              color: Colours.YELLOW_LIGHT,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Text(
                "SUBMIT",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class VehicleImageItem extends StatefulWidget {
  String? title;
  File? selectedFile;
  VehicleImageItem({this.selectedFile, this.title});

  @override
  State<VehicleImageItem> createState() => _VehicleImageItemState();
}

class _VehicleImageItemState extends State<VehicleImageItem> {
  @override
  Size? _size;
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      height: _size!.height * 0.2,
      decoration: BoxDecoration(
        color: Colours.PRIMARY_BLUE_MILD,
        borderRadius: BorderRadius.circular(12),
      ),
      child: widget.selectedFile != null
          ? ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(
                File(widget.selectedFile!.path),
                fit: BoxFit.fill,
              ),
            )
          : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  Images.docs_icon,
                  color: Colours.YELLOW_LIGHT,
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  widget.title!,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Colours.YELLOW_LIGHT,
                  ),
                )
              ],
            ),
    );
  }
}
