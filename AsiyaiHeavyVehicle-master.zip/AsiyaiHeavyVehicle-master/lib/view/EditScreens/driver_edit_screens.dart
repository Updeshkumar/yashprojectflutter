import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/data/datamodel/driver_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/fade_image.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/utils/preview_image.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/DriverNew/add_driver_image.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/add_aadhar_image.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/textfield.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

class DriverEditScreens extends StatefulWidget {
  const DriverEditScreens({super.key});

  @override
  State<DriverEditScreens> createState() => _DriverEditScreensState();
}

class _DriverEditScreensState extends State<DriverEditScreens> {
  getData() async {
    await Provider.of<UserProvider>(context, listen: false).getDriverData();
    print("HELLO");
    if (myProvider!.drivers_data != null) {
      print("HELLOufhuiew");
      vehicleNameController.text = myProvider!.drivers_data!.vehicalname!;
      driverNameController.text = myProvider!.drivers_data!.driveroperatorname!;
      experienceController.text = myProvider!.drivers_data!.expriencesinyear!;
      licenseCotroller.text = myProvider!.drivers_data!.heavyLicense!;
      mobileController.text = myProvider!.drivers_data!.mobilenumber!;
      aadharFront = myProvider!.drivers_data!.aadharnumberfrontimage!;
      aadhrBAck = myProvider!.drivers_data!.aadharnumberbackimage!;
      driverImage = myProvider!.drivers_data!.driverImage!;
      licesCImage = myProvider!.drivers_data!.licenseImage!;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200), () => getData());
    //   Future.delayed(Duration(milliseconds: 400), () => getDriverData());
  }

  getDriverData() async {}

  UserProvider? myProvider;

  String? aadharFront;
  String? aadhrBAck;
  String? driverImage;
  String? licesCImage;

  List<File>? finalSelctedAadhar = [];
  List<File>? finaldriverLicImage = [];

  Size? _size;

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    myProvider = Provider.of<UserProvider>(context, listen: false);
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(_size!.height / 16),
          child: AppBar(
            title: Text(
              "Driver Profile",
              style: TextStyles.ktext20(context),
            ),
            backgroundColor: Colours.PRIMARY_GREY,
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 10,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: _size!.height * 0.01,
                ),
                addDetailsWidget(),
                const SizedBox(
                  height: 20,
                ),
                InkWell(
                  onTap: () async {
                    FocusScope.of(context).requestFocus(FocusNode());
                    List<File> selectFiles = await Navigator.push(
                        context,
                        PageTransition(
                            child: AddDriverImage(),
                            type: PageTransitionType.rightToLeft));
                    if (![null, ""].contains(selectFiles)) {
                      finaldriverLicImage!.addAll(selectFiles);
                      print("selectFiles.length : " +
                          finaldriverLicImage!.length.toString());
                    }
                  },
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colours.YELLOW_LIGHT),
                          ),
                          child: Icon(
                            Icons.add,
                            color: Colours.YELLOW_LIGHT,
                          ),
                        ),
                        SizedBox(width: 10),
                        Text(
                          "Edit Driver & License Image",
                          style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: Colours.YELLOW_LIGHT),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 12,
                ),
                Row(
                  children: [
                    driverImage != null
                        ? InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      child: ImagePreviewScreen(
                                        path: "http://asiyaiheavyvehicle.com" +
                                            driverImage!,
                                      ),
                                      type: PageTransitionType.bottomToTop));
                            },
                            child: Container(
                              height: 100,
                              width: 100,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: FadeImageWithError(
                                  imgPath: "http://asiyaiheavyvehicle.com" +
                                      driverImage!,
                                  placeImage: Images.docs_icon,
                                ),
                              ),
                            ),
                          )
                        : Container(),
                    const SizedBox(
                      width: 10,
                    ),
                    licesCImage != null
                        ? InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      child: ImagePreviewScreen(
                                        path: "http://asiyaiheavyvehicle.com" +
                                            licesCImage!,
                                      ),
                                      type: PageTransitionType.bottomToTop));
                            },
                            child: Container(
                              height: 100,
                              width: 100,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: FadeImageWithError(
                                  imgPath: "http://asiyaiheavyvehicle.com" +
                                      licesCImage!,
                                ),
                              ),
                            ),
                          )
                        : Container(),
                  ],
                ),
                const SizedBox(height: 20),
                InkWell(
                  onTap: () async {
                    FocusScope.of(context).requestFocus(FocusNode());
                    List<File> selectFiles = await Navigator.push(
                        context,
                        PageTransition(
                            child: AddAadharImages(),
                            type: PageTransitionType.rightToLeft));
                    if (![null, ""].contains(selectFiles)) {
                      finalSelctedAadhar!.addAll(selectFiles);
                      print("selectFiles.length : " +
                          finalSelctedAadhar!.length.toString());
                    }
                  },
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colours.YELLOW_LIGHT),
                          ),
                          child: Icon(
                            Icons.add,
                            color: Colours.YELLOW_LIGHT,
                          ),
                        ),
                        SizedBox(width: 10),
                        Text(
                          "Add Or Edit Aadhar Images",
                          style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: Colours.YELLOW_LIGHT),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 12,
                ),
                Row(
                  children: [
                    aadharFront != null
                        ? InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      child: ImagePreviewScreen(
                                        path: "http://asiyaiheavyvehicle.com" +
                                            aadharFront!,
                                      ),
                                      type: PageTransitionType.bottomToTop));
                            },
                            child: Container(
                              height: 100,
                              width: 100,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: FadeImageWithError(
                                  placeImage: Images.docs_icon,
                                  imgPath: "http://asiyaiheavyvehicle.com" +
                                      aadharFront!,
                                ),
                              ),
                            ),
                          )
                        : Container(),
                    const SizedBox(
                      width: 10,
                    ),
                    aadhrBAck != null
                        ? InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  PageTransition(
                                      child: ImagePreviewScreen(
                                        path: "http://asiyaiheavyvehicle.com" +
                                            aadhrBAck!,
                                      ),
                                      type: PageTransitionType.bottomToTop));
                            },
                            child: Container(
                              height: 100,
                              width: 100,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: FadeImageWithError(
                                  placeImage: Images.docs_icon,
                                  imgPath: "http://asiyaiheavyvehicle.com" +
                                      aadhrBAck!,
                                ),
                              ),
                            ),
                          )
                        : Container(),
                  ],
                ),
              ],
            ),
          ),
        ),
        bottomNavigationBar: InkWell(
          onTap: () async {
            FocusScope.of(context).requestFocus(FocusNode());
            //Navigator.pop(context);
            if (vehicleNameController.text.isEmpty &&
                driverNameController.text.isEmpty &&
                experienceController.text.isEmpty &&
                licenseCotroller.text.isEmpty &&
                mobileController.text.isEmpty) {
              showTostMsg("Please Enter Details");
              return;
            }

            // if (finaldriverLicImage != null &&
            //     finaldriverLicImage!.length > 0) {
            //   if (finalSelctedAadhar != null &&
            //       finalSelctedAadhar!.length > 0) {

            //   } else {
            //     showTostMsg("Please Add Aadhar Images");
            //   }
            // } else {
            //   showTostMsg("Please Add Driver & License Images");
            // }
            DriverModel driverModel = DriverModel(
              vehicalname: vehicleNameController.text,
              driveroperatorname: driverNameController.text,
              mobileNumber: mobileController.text,
              expriencesinyear: experienceController.text,
              license_check: licenseCotroller.text,
              aadharFront: finalSelctedAadhar != null &&
                      finalSelctedAadhar!.length > 0 &&
                      finalSelctedAadhar![0] != null
                  ? finalSelctedAadhar![0]
                  : null,
              aadharBack: finalSelctedAadhar != null &&
                      finalSelctedAadhar!.length > 0 &&
                      finalSelctedAadhar![1] != null
                  ? finalSelctedAadhar![1]
                  : null,
              driverImage: finaldriverLicImage != null &&
                      finaldriverLicImage!.length > 0 &&
                      finaldriverLicImage![0] != null
                  ? finaldriverLicImage![0]
                  : null,
              licenseImage: finaldriverLicImage != null &&
                      finaldriverLicImage!.length > 0 &&
                      finaldriverLicImage![1] != null
                  ? finaldriverLicImage![1]
                  : null,
            );
            await model.UpdateDriverDataPost(
              context,
              model: driverModel,
            );
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
            child: Container(
              height: _size!.height * 0.05,
              decoration: BoxDecoration(
                color: Colours.YELLOW_LIGHT,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Text(
                  "SUBMIT",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ),
      );
    });
  }

  final vehicleNameController = TextEditingController();
  final driverNameController = TextEditingController();
  final experienceController = TextEditingController();
  final licenseCotroller = TextEditingController();
  final mobileController = TextEditingController();

  addDetailsWidget() {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Driver Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          IconTextField(
            title: "Vehicle Name".tr().toString(),
            controller: vehicleNameController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Driver/Operator Name".tr().toString(),
            controller: driverNameController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Experience(In Year)".tr().toString(),
            controller: experienceController,
            textInputType: TextInputType.number,
            textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
          ),
          IconTextField(
            title: "License(Yes/No)".tr().toString(),
            controller: licenseCotroller,
          ),
          IconTextField(
            title: "Mobile Number".tr().toString(),
            controller: mobileController,
            textInputType: TextInputType.phone,
            textInputFormatter: [LengthLimitingTextInputFormatter(10)],
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
        ],
      ),
    );
  }
}
