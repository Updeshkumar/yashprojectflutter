import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/data/datamodel/sub_cont_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/fade_image.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/utils/preview_image.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/SubRegister/add_sub_images.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/textfield.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '../NewProfile/HeavyVehicle/add_aadhar_image.dart';

class SubEditScreen extends StatefulWidget {
  const SubEditScreen({super.key});

  @override
  State<SubEditScreen> createState() => _SubEditScreenState();
}

class _SubEditScreenState extends State<SubEditScreen> {
  getData() async {
    await Provider.of<UserProvider>(context, listen: false)
        .getSubContructorData();
    if (myProvider!.sub_data != null) {
      subContNameControler.text = myProvider!.sub_data!.contractorname != null
          ? myProvider!.sub_data!.contractorname!
          : "";
      emailIdNUmber.text = myProvider!.sub_data!.emailId != null
          ? myProvider!.sub_data!.emailId!
          : "";
      phoneNumberController.text = myProvider!.sub_data!.mobilenumber != null
          ? myProvider!.sub_data!.mobilenumber!
          : "";
      firmNameController.text = myProvider!.sub_data!.firmname != null
          ? myProvider!.sub_data!.firmname!
          : "";
      typeOFworkController.text = myProvider!.sub_data!.typeofwork != null
          ? myProvider!.sub_data!.typeofwork!
          : "";
      experinceController.text = myProvider!.sub_data!.expriencesinyear != null
          ? myProvider!.sub_data!.expriencesinyear!
          : "";
      licenseController.text = myProvider!.sub_data!.licenseNumber != null
          ? myProvider!.sub_data!.licenseNumber!
          : "";
      expiredAtController.text = myProvider!.sub_data!.expiredAt != null
          ? myProvider!.sub_data!.expiredAt!
          : "";
      img_subs!.add(myProvider!.sub_data!.subcontractorImageBack!);
      img_subs!.add(myProvider!.sub_data!.subcontractorImageRight!);
      img_subs!.add(myProvider!.sub_data!.subcontractorImageLeft!);
      img_subs!.add(myProvider!.sub_data!.subcontractorImage!);

      aadhar_img!.add(myProvider!.sub_data!.aadharnumberbackimage!);

      aadhar_img!.add(myProvider!.sub_data!.aadharnumberfrontimage!);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200), () => getData());
  }

  UserProvider? myProvider;
  List<String>? img_subs = [];
  List<String>? aadhar_img = [];

  Size? _size;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context, listen: false);
    _size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(_size!.height / 16),
        child: AppBar(
          title: Text(
            "Sub Contructor Profile",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
        ),
      ),
      body: Consumer<UserProvider>(builder: (context, model, child) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: SingleChildScrollView(
            child: Column(
              children: [
                addSubContDetailWidget(model),
                addSubDetailWidget(model),
                InkWell(
                  onTap: () async {
                    if (subContNameControler.text.isEmpty &&
                        emailIdNUmber.text.isEmpty &&
                        phoneNumberController.text.isEmpty) {
                      showTostMsg("Enter Contructor Details");
                      return;
                    }
                    if (firmNameController.text.isEmpty &&
                        typeOFworkController.text.isEmpty &&
                        experinceController.text.isEmpty &&
                        licenseController.text.isEmpty &&
                        expiredAtController.text.isEmpty) {
                      showTostMsg("Add Details");
                      return;
                    }

                    // if (finalSelctedAadhar != null &&
                    //     finalSelctedAadhar!.length > 0) {
                    //   if (finalSelectSubImages != null &&
                    //       finalSelectSubImages!.length > 0) {

                    //     await model.UpdateSuBContDataPost(context,
                    //         model: subContModel);
                    //   } else {
                    //     showTostMsg("Add Group Images");
                    //   }
                    // } else {
                    //   showTostMsg("Add Aadhar Images");
                    // }
                    SubContModel subContModel = SubContModel(
                      contractorname: subContNameControler.text,
                      emailId: emailIdNUmber.text,
                      mobileNumber: phoneNumberController.text,
                      firmname: firmNameController.text,
                      typeofWork: typeOFworkController.text,
                      expriencesinyear: experinceController.text,
                      expiredAt: expiredAtController.text,
                      licenseNumber: licenseController.text,
                      aadharFront: finalSelctedAadhar != null &&
                              finalSelctedAadhar!.length > 0 &&
                              finalSelctedAadhar![0] != null
                          ? finalSelctedAadhar![0]
                          : null,
                      aadharBack: finalSelctedAadhar != null &&
                              finalSelctedAadhar!.length > 0 &&
                              finalSelctedAadhar![1] != null
                          ? finalSelctedAadhar![1]
                          : null,
                      subcontractorImage: finalSelectSubImages != null &&
                              finalSelectSubImages!.length > 0 &&
                              finalSelectSubImages![0] != null
                          ? finalSelectSubImages![0]
                          : null,
                      subcontractor_image_right: finalSelectSubImages != null &&
                              finalSelectSubImages!.length > 0 &&
                              finalSelectSubImages![1] != null
                          ? finalSelectSubImages![1]
                          : null,
                      subcontractor_image_back: finalSelectSubImages != null &&
                              finalSelectSubImages!.length > 0 &&
                              finalSelectSubImages![2] != null
                          ? finalSelectSubImages![2]
                          : null,
                      subcontractor_image_left: finalSelectSubImages != null &&
                              finalSelectSubImages!.length > 0 &&
                              finalSelectSubImages![3] != null
                          ? finalSelectSubImages![3]
                          : null,
                    );
                    await model.UpdateSuBContDataPost(context,
                        model: subContModel);
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Container(
                      height: _size!.height * 0.05,
                      decoration: BoxDecoration(
                        color: Colours.YELLOW_LIGHT,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Text(
                          "UPDATE",
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  List<File>? finalSelctedAadhar = [];

  final subContNameControler = TextEditingController();
  final emailIdNUmber = TextEditingController();
  final phoneNumberController = TextEditingController();

  addSubContDetailWidget(UserProvider model) {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Sub Contructor Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          IconTextField(
            title: "Sub Contructor Name".tr().toString(),
            controller: subContNameControler,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Email Id".tr().toString(),
            textInputType: TextInputType.emailAddress,
            controller: emailIdNUmber,
          ),
          IconTextField(
            title: "Mobile Number".tr().toString(),
            textInputType: TextInputType.phone,
            textInputFormatter: [
              LengthLimitingTextInputFormatter(10),
              FilteringTextInputFormatter.digitsOnly,
            ],
            controller: phoneNumberController,
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              List<File> selectFile = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddAadharImages(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFile)) {
                finalSelctedAadhar!.addAll(selectFile);
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Aadhar Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            height: 120,
            child: ListView.builder(
                itemCount: aadhar_img!.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          PageTransition(
                              child: ImagePreviewScreen(
                                path: "http://asiyaiheavyvehicle.com" +
                                    aadhar_img![index],
                              ),
                              type: PageTransitionType.bottomToTop));
                    },
                    child: Container(
                      height: 80,
                      width: 100,
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: FadeImageWithError(
                          imgPath: "http://asiyaiheavyvehicle.com" +
                              aadhar_img![index],
                          placeImage: Images.docs_icon,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  );
                }),
          )
        ],
      ),
    );
  }

  List<File>? finalSelectSubImages = [];

  final firmNameController = TextEditingController();
  final typeOFworkController = TextEditingController();
  final experinceController = TextEditingController();
  final licenseController = TextEditingController();
  final expiredAtController = TextEditingController();
  addSubDetailWidget(UserProvider model) {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Add Other Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          IconTextField(
            title: "Firm Name".tr().toString(),
            controller: firmNameController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Type of work".tr().toString(),
            textInputType: TextInputType.name,
            controller: typeOFworkController,
          ),
          IconTextField(
            title: "Experience (In Number)".tr().toString(),
            textInputType: TextInputType.phone,
            textInputFormatter: [
              LengthLimitingTextInputFormatter(10),
              FilteringTextInputFormatter.digitsOnly,
            ],
            controller: experinceController,
          ),
          IconTextField(
            title: "License Number".tr().toString(),
            controller: licenseController,
          ),
          IconTextField(
            title: "Expired At".tr().toString(),
            controller: expiredAtController,
            textInputType: TextInputType.datetime,
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              List<File> selectFile = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddSubImages(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFile)) {
                finalSelectSubImages!.addAll(selectFile);
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Group Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            height: 120,
            child: ListView.builder(
                itemCount: img_subs!.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          PageTransition(
                              child: ImagePreviewScreen(
                                path: "http://asiyaiheavyvehicle.com" +
                                    img_subs![index],
                              ),
                              type: PageTransitionType.bottomToTop));
                    },
                    child: Container(
                      height: 80,
                      width: 100,
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: FadeImageWithError(
                          imgPath: "http://asiyaiheavyvehicle.com" +
                              img_subs![index],
                          placeImage: Images.docs_icon,
                        ),
                      ),
                    ),
                  );
                }),
          )
        ],
      ),
    );
  }
}
