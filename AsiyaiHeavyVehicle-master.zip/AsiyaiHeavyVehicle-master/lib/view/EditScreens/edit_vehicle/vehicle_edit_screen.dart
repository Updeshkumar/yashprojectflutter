import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/data/datamodel/heavy_vehicle_model.dart';
import 'package:asiayai_heavy_vehicle_app/data/respnse/vehicel_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/fade_image.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/utils/preview_image.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/add_aadhar_image.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/add_vehicle_images.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/dat_container.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/textfield.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

class EditVehicleScreen extends StatefulWidget {
  Vehiclelist? obj;
  EditVehicleScreen({this.obj});

  @override
  State<EditVehicleScreen> createState() => _EditVehicleScreenState();
}

class _EditVehicleScreenState extends State<EditVehicleScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  getData() async {
    vehicleNameController.text = widget.obj!.vehicalName!;
    modelNumberController.text = widget.obj!.vehiclemodelnumber!;
    registrationNUmberController.text = widget.obj!.vehicleregistrationnumber!;
    companyNameController.text = widget.obj!.companyName!;
    ownerNameController.text = widget.obj!.ownername!;
    emailIdNUmber.text = widget.obj!.emailId!;
    phoneNumberController.text = widget.obj!.alternativemobilenumber!;
    selectedDate = DateTime.parse(widget.obj!.manufactureDate!);
    aadhar_img!.add(widget.obj!.aadharnumberfrontimage!);
    aadhar_img!.add(widget.obj!.aadharnumberbackimage!);
    img_vehicle!.add(widget.obj!.vehicleImage!);
    img_vehicle!.add(widget.obj!.vehicleImageBack!);
    img_vehicle!.add(widget.obj!.vehicleImageLeft!);
    img_vehicle!.add(widget.obj!.vehicleImageRight!);
  }

  List<String>? img_vehicle = [];
  List<String>? aadhar_img = [];

  Size? _size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(_size!.height / 16),
          child: AppBar(
            title: Text(
              "Heavy Vehicle Profile",
              style: TextStyles.ktext20(context),
            ),
            backgroundColor: Colours.PRIMARY_GREY,
          ),
        ),
        body: Consumer<UserProvider>(builder: (context, model, child) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: _size!.height * 0.01,
                  ),
                  addVehicleWidget(),
                  ownerDetails(),
                  InkWell(
                    onTap: () async {
                      //Navigator.pop(context);
                      FocusScope.of(context).requestFocus(FocusNode());
                      if (vehicleNameController.text.isEmpty &&
                          registrationNUmberController.text.isEmpty &&
                          modelNumberController.text.isEmpty) {
                        showTostMsg("Please Enter Vehicle Details");
                        return;
                      }

                      if (companyNameController.text.isEmpty &&
                          ownerNameController.text.isEmpty &&
                          emailIdNUmber.text.isEmpty &&
                          phoneNumberController.text.isEmpty) {
                        showTostMsg("Please Enter Owner Details");
                        return;
                      }

                      // if (finalVehicleImage != null &&
                      //     finalVehicleImage!.length > 0) {
                      //   if (finalSelctedAadhar != null &&
                      //       finalSelctedAadhar!.length > 0) {

                      //     // print(getDate());
                      //     await model.heavyVehiclePost(
                      //       context,
                      //       model: heavyVehicleModel,
                      //     );
                      //   } else {
                      //     showTostMsg("Please Add Aadhar Images");
                      //   }
                      // } else {
                      //   showTostMsg("Please Add Vehicle Images");
                      // }
                      HeavyVehicleModel heavyVehicleModel = HeavyVehicleModel(
                        Id: widget.obj!.id!.toString(),
                        vehicalName: vehicleNameController.text,
                        vehiclemodelnumber: modelNumberController.text,
                        vehicleregistrationnumber:
                            registrationNUmberController.text,
                        manufectoringDate: getDate() != null
                            ? getDate()
                            : widget.obj!.manufactureDate,
                        companyName: companyNameController.text,
                        ownername: ownerNameController.text,
                        emailId: emailIdNUmber.text,
                        alternativemobileNumber: phoneNumberController.text,
                        aadharImage1: finalSelctedAadhar != null &&
                                finalSelctedAadhar!.length > 0 &&
                                finalSelctedAadhar![0] != null
                            ? finalSelctedAadhar![0]
                            : null,
                        aadharImage2: finalSelctedAadhar != null &&
                                finalSelctedAadhar!.length > 0 &&
                                finalSelctedAadhar![1] != null
                            ? finalSelctedAadhar![1]
                            : null,
                        vehicleImage: finalVehicleImage != null &&
                                finalVehicleImage!.length > 0 &&
                                finalVehicleImage![0] != null
                            ? finalVehicleImage![0]
                            : null,
                        vehicle_image_back: finalVehicleImage != null &&
                                finalVehicleImage!.length > 0 &&
                                finalVehicleImage![1] != null
                            ? finalVehicleImage![1]
                            : null,
                        vehicle_image_left: finalVehicleImage != null &&
                                finalVehicleImage!.length > 0 &&
                                finalVehicleImage![2] != null
                            ? finalVehicleImage![2]
                            : null,
                        vehicle_image_right: finalVehicleImage != null &&
                                finalVehicleImage!.length > 0 &&
                                finalVehicleImage![3] != null
                            ? finalVehicleImage![3]
                            : null,
                      );

                      await model.UpdateHeavyVehiclePost(context,
                          model: heavyVehicleModel);
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Container(
                        height: _size!.height * 0.05,
                        decoration: BoxDecoration(
                          color: Colours.YELLOW_LIGHT,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            "UPDATE",
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        }));
  }

  DateTime selectedDate = DateTime.now();
  bool showDate = false;
  Future<DateTime> selectDate(BuildContext context) async {
    final selected = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (selected != null && selected != selectedDate) {
      setState(() {
        selectedDate = selected;
      });
    }
    return selectedDate;
  }

//
  String getDate() {
    // ignore: unnecessary_null_comparison
    if (selectedDate == null) {
      return 'Select Date'.tr().toString();
    } else {
      return DateFormat('yyyy-MM-dd').format(selectedDate);
    }
  }

  List<File>? finalVehicleImage = [];
  final vehicleNameController = TextEditingController();
  final modelNumberController = TextEditingController();
  final registrationNUmberController = TextEditingController();
  final manufactureDateController = TextEditingController();
  addVehicleWidget() {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Vehicle Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          IconTextField(
            title: "Vehicle Name".tr().toString(),
            controller: vehicleNameController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Vehicle Model Number".tr().toString(),
            controller: modelNumberController,
          ),
          IconTextField(
            title: "Vehicle Registration Number".tr().toString(),
            controller: registrationNUmberController,
          ),
          DateContainer(
            onTap: () {
              selectDate(context);
              showDate = true;
            },
            date: showDate ? getDate() : "Manufacturing Year".tr().toString(),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              List<File> selectFile = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddVehicleImages(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFile)) {
                finalVehicleImage!.addAll(selectFile);
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Vehicle Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            height: 120,
            child: ListView.builder(
                itemCount: img_vehicle!.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          PageTransition(
                              child: ImagePreviewScreen(
                                path: "http://asiyaiheavyvehicle.com" +
                                    img_vehicle![index],
                              ),
                              type: PageTransitionType.bottomToTop));
                    },
                    child: Container(
                      height: 80,
                      width: 100,
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: FadeImageWithError(
                          imgPath: "http://asiyaiheavyvehicle.com" +
                              img_vehicle![index],
                          placeImage: Images.docs_icon,
                        ),
                      ),
                    ),
                  );
                }),
          )
        ],
      ),
    );
  }

  List<File>? finalSelctedAadhar = [];
  final companyNameController = TextEditingController();
  final ownerNameController = TextEditingController();
  final emailIdNUmber = TextEditingController();
  final phoneNumberController = TextEditingController();
  ownerDetails() {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Owner Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(height: _size!.height * 0.02),
          IconTextField(
            title: "Company Name".tr().toString(),
            controller: companyNameController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Owner Name".tr().toString(),
            controller: ownerNameController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Email Id".tr().toString(),
            controller: emailIdNUmber,
            textInputType: TextInputType.emailAddress,
            // textInputFormatter: [
            //   FilteringTextInputFormatter.allow(
            //     // RegExp(
            //     //     r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$'),
            //   )
            // ],
          ),
          IconTextField(
            title: "Mobile Number".tr().toString(),
            controller: phoneNumberController,
            textInputType: TextInputType.phone,
            textInputFormatter: [
              LengthLimitingTextInputFormatter(10),
              FilteringTextInputFormatter.digitsOnly
            ],
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              List<File> selectFiles = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddAadharImages(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFiles)) {
                finalSelctedAadhar!.addAll(selectFiles);
                print("selectFiles.length : " + selectFiles.length.toString());
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Aadhar Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            height: 120,
            child: ListView.builder(
                itemCount: aadhar_img!.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          PageTransition(
                              child: ImagePreviewScreen(
                                path: "http://asiyaiheavyvehicle.com" +
                                    aadhar_img![index],
                              ),
                              type: PageTransitionType.bottomToTop));
                    },
                    child: Container(
                      height: 80,
                      width: 100,
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: FadeImageWithError(
                          imgPath: "http://asiyaiheavyvehicle.com" +
                              aadhar_img![index],
                          placeImage: Images.docs_icon,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  );
                }),
          )
        ],
      ),
    );
  }
}
