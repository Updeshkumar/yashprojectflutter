import 'package:asiayai_heavy_vehicle_app/data/respnse/vehicel_details_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/EditScreens/edit_vehicle/vehicle_edit_screen.dart';
import 'package:asiayai_heavy_vehicle_app/view/Vehicel/VehicleDetails/vehicle_details.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

class AllEditVehicle extends StatefulWidget {
  const AllEditVehicle({super.key});

  @override
  State<AllEditVehicle> createState() => _AllEditVehicleState();
}

class _AllEditVehicleState extends State<AllEditVehicle> {
  getData() async {
    await Provider.of<UserProvider>(context, listen: false).getVehicleData();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200), () => getData());
  }

  Size? _size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(_size!.height / 16),
          child: AppBar(
            title: Text(
              "All Vehicles",
              style: TextStyles.ktext20(context),
            ),
            backgroundColor: Colours.PRIMARY_GREY,
          ),
        ),
        body: ListView(
          padding: EdgeInsets.symmetric(horizontal: 14),
          children: [
            SizedBox(
              height: _size!.height * 0.02,
            ),
            ListView.builder(
                itemCount: model.vehcileDashList.length,
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  Vehiclelist obj = model.vehcileDashList[index];
                  return MoreVehicleProdct(
                    obj: obj,
                  );
                })
          ],
        ),
      );
    });
  }
}

class MoreVehicleProdct extends StatefulWidget {
  Vehiclelist? obj;
  MoreVehicleProdct({this.obj});

  @override
  State<MoreVehicleProdct> createState() => _MoreVehicleProdctState();
}

class _MoreVehicleProdctState extends State<MoreVehicleProdct> {
//  List? imageList = [];
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // if (widget.obj!.vehicleImage!.contains("[") &&
    //     widget.obj!.vehicleImage!.contains("]")) {
    //   imageList = jsonDecode(widget.obj!.vehicleImage!);
    // }
    //  final list = value.split(',');
    return InkWell(
      onTap: () {
        Navigator.push(
            context,
            PageTransition(
                child: EditVehicleScreen(obj: widget.obj),
                type: PageTransitionType.rightToLeft));
      },
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Container(
                  height: size.height / 8,
                  width: size.width / 4,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: FadeInImage.assetNetwork(
                      placeholder: Images.vehicle_icon,
                      placeholderFit: BoxFit.none,
                      image: widget.obj!.vehicleImage != null
                          ? "http://asiyaiheavyvehicle.com" +
                              widget.obj!.vehicleImage!
                          : Images.vehicle_icon,
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.obj!.vehicalName.toString().toUpperCase(),
                          style: TextStyles.ktext16(context)
                              .copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(
                          height: 6,
                        ),
                        // if (![null, ""].contains(widget.obj!.country) &&
                        //     ![null, ""].contains(widget.obj!.distict))
                        // widget.obj!.address!.districtId != null &&
                        //         widget.obj!.address!.stateId != null
                        //     ? Text(
                        //         widget.obj!.address!.districtId!.districtName! +
                        //             " , " +
                        //             widget.obj!.address!.stateId!.stateName! +
                        //             "  ",
                        //         style: TextStyles.ktext14(context).copyWith(
                        //             fontWeight: FontWeight.w400,
                        //             color: Colours.PRIMARY_GREY_LIGHT),
                        //         maxLines: 2,
                        //       )
                        //     : Container(),
                        SizedBox(
                          height: size.height / 80,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Vehicle Number: ",
                              style: TextStyles.ktext16(context)
                                  .copyWith(fontWeight: FontWeight.w400),
                            ),
                            Expanded(
                              child: Text(
                                "${widget.obj!.vehicleregistrationnumber.toString()}",
                                style: TextStyles.ktext16(context),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: Colours.PRIMARY_GREY,
          ),
        ],
      ),
    );
  }
}
