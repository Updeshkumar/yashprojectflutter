import 'dart:io';

import 'package:asiayai_heavy_vehicle_app/data/datamodel/labour_cont_model.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';
import 'package:asiayai_heavy_vehicle_app/utils/colour_resource.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/fade_image.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';
import 'package:asiayai_heavy_vehicle_app/utils/preview_image.dart';
import 'package:asiayai_heavy_vehicle_app/utils/text_styles.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/HeavyVehicle/add_aadhar_image.dart';
import 'package:asiayai_heavy_vehicle_app/view/NewProfile/Labour/add_labour_image.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/textfield.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

class EditLabourScreen extends StatefulWidget {
  const EditLabourScreen({super.key});

  @override
  State<EditLabourScreen> createState() => _EditLabourScreenState();
}

class _EditLabourScreenState extends State<EditLabourScreen> {
  getData() async {
    await Provider.of<UserProvider>(context, listen: false).getLabourData();
    if (myProvider!.labour_data != null) {
      labourContructorController.text = myProvider!.labour_data!.name != null
          ? myProvider!.labour_data!.name!
          : "";
      mobileCOntroller.text = myProvider!.labour_data!.mobileNumber != null
          ? myProvider!.labour_data!.mobileNumber!
          : "";
      labourWorkController.text = myProvider!.labour_data!.labourwork != null
          ? myProvider!.labour_data!.labourwork!
          : "";
      labourNumberController.text =
          myProvider!.labour_data!.lobourinnumber != null
              ? myProvider!.labour_data!.lobourinnumber!
              : "";
      professionalController.text =
          myProvider!.labour_data!.professionallabour != null
              ? myProvider!.labour_data!.professionallabour!
              : "";
      unskilledLabourController.text =
          myProvider!.labour_data!.unskilledlabour != null
              ? myProvider!.labour_data!.unskilledlabour!
              : "";
      skilledLabourController.text =
          myProvider!.labour_data!.skilledlabour != null
              ? myProvider!.labour_data!.skilledlabour!
              : "";

      labourImage = myProvider!.labour_data!.labourImage;
      aadha_one = myProvider!.labour_data!.aadharnumberbackimage;
      add_two = myProvider!.labour_data!.aadharnumberfrontimage;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200), () => getData());
  }

  UserProvider? myProvider;
  String? aadha_one;

  String? add_two;
  String? labourImage;

  Size? _size;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context, listen: false);
    _size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colours.PRIMARY_BLUE,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(_size!.height / 16),
        child: AppBar(
          title: Text(
            "Labour Contructor Profile",
            style: TextStyles.ktext20(context),
          ),
          backgroundColor: Colours.PRIMARY_GREY,
        ),
      ),
      body: Consumer<UserProvider>(builder: (context, model, child) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: SingleChildScrollView(
            child: Column(
              children: [
                labourContructorWidget(model),
                labourDetailswidget(model),
                InkWell(
                  onTap: () async {
                    FocusScope.of(context).requestFocus(FocusNode());
                    if (labourContructorController.text.isEmpty &&
                        mobileCOntroller.text.isEmpty) {
                      showTostMsg("Enter Labour Contructor Details");
                      return;
                    }
                    if (labourWorkController.text.isEmpty &&
                        labourNumberController.text.isEmpty &&
                        professionalController.text.isEmpty &&
                        skilledLabourController.text.isEmpty &&
                        unskilledLabourController.text.isEmpty) {
                      showTostMsg("Enter Labour Details");
                      return;
                    }

                    // if (finalSelctedAadhar != null &&
                    //     finalSelctedAadhar!.length > 0) {
                    //   if (labourFile != null) {
                    //     print("HYY");
                    //   } else {
                    //     showTostMsg("Add Labour Image");
                    //   }
                    // } else {
                    //   showTostMsg("Please Select Aadhar Images");
                    // }
                    LabourContModel labourContModel = LabourContModel(
                        labourcontractorname: labourContructorController.text,
                        labourwork: labourWorkController.text,
                        mobileNumber: mobileCOntroller.text,
                        lobourinnumber: labourNumberController.text,
                        skilledLabour: skilledLabourController.text,
                        unskiledLabour: unskilledLabourController.text,
                        proffesionalLabour: professionalController.text,
                        aadharback: finalSelctedAadhar != null &&
                                finalSelctedAadhar!.length > 0 &&
                                finalSelctedAadhar![1] != null
                            ? finalSelctedAadhar![1]
                            : null,
                        aadharfront: finalSelctedAadhar != null &&
                                finalSelctedAadhar!.length > 0 &&
                                finalSelctedAadhar![0] != null
                            ? finalSelctedAadhar![0]
                            : null,
                        labourImage: labourFile != null ? labourFile : null);

                    await model.UpdateLabourDataPost(
                      context,
                      model: labourContModel,
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Container(
                      height: _size!.height * 0.05,
                      decoration: BoxDecoration(
                        color: Colours.YELLOW_LIGHT,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Text(
                          "SUBMIT",
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  List<File>? finalSelctedAadhar = [];
  final labourContructorController = TextEditingController();
  final mobileCOntroller = TextEditingController();

  labourContructorWidget(UserProvider model) {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Labour Contructor Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          IconTextField(
            title: "Labour Contructor Name".tr().toString(),
            controller: labourContructorController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Mobile Number".tr().toString(),
            controller: mobileCOntroller,
            textInputType: TextInputType.phone,
            textInputFormatter: [
              LengthLimitingTextInputFormatter(10),
              FilteringTextInputFormatter.digitsOnly
            ],
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              List<File> selectFiles = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddAadharImages(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFiles)) {
                finalSelctedAadhar!.addAll(selectFiles);
                print("selectFiles.length : " + selectFiles.length.toString());
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Aadhar Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              aadha_one != null
                  ? InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            PageTransition(
                                child: ImagePreviewScreen(
                                  path: "http://asiyaiheavyvehicle.com" +
                                      aadha_one!,
                                ),
                                type: PageTransitionType.bottomToTop));
                      },
                      child: Container(
                        height: 100,
                        width: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: FadeImageWithError(
                            imgPath:
                                "http://asiyaiheavyvehicle.com" + aadha_one!,
                            placeImage: Images.docs_icon,
                          ),
                        ),
                      ),
                    )
                  : Container(),
              const SizedBox(
                width: 10,
              ),
              add_two != null
                  ? InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            PageTransition(
                                child: ImagePreviewScreen(
                                  path: "http://asiyaiheavyvehicle.com" +
                                      add_two!,
                                ),
                                type: PageTransitionType.bottomToTop));
                      },
                      child: Container(
                        height: 100,
                        width: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: FadeImageWithError(
                            imgPath: "http://asiyaiheavyvehicle.com" + add_two!,
                          ),
                        ),
                      ),
                    )
                  : Container(),
            ],
          ),
        ],
      ),
    );
  }

  //
  File? labourFile;
  final labourWorkController = TextEditingController();
  final labourNumberController = TextEditingController();
  final professionalController = TextEditingController();
  final skilledLabourController = TextEditingController();
  final unskilledLabourController = TextEditingController();

  labourDetailswidget(UserProvider model) {
    return Container(
      margin: EdgeInsets.only(bottom: 10, top: 10),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          border: Border.all(color: Colours.PRIMARY_BLUE_MILD),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: Colours.YELLOW_DARK,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              "Labour Details",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colours.PRIMARY_BLUE),
            ),
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          IconTextField(
            title: "Labour Work".tr().toString(),
            controller: labourWorkController,
            textInputType: TextInputType.name,
            textInputFormatter: [
              FilteringTextInputFormatter.allow(
                RegExp(r"[a-zA-Z]+|\s"),
              )
            ],
          ),
          IconTextField(
            title: "Labour(In Numbers)".tr().toString(),
            controller: labourNumberController,
            textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
            textInputType: TextInputType.number,
          ),
          IconTextField(
            title: "Professional Labour(In Number)".tr().toString(),
            controller: professionalController,
            textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
            textInputType: TextInputType.number,
          ),
          IconTextField(
            title: "Skilled Labour(In Number)".tr().toString(),
            controller: skilledLabourController,
            textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
            textInputType: TextInputType.number,
          ),
          IconTextField(
            title: "UnSkilled Labour(In Number)".tr().toString(),
            controller: unskilledLabourController,
            textInputFormatter: [FilteringTextInputFormatter.digitsOnly],
            textInputType: TextInputType.number,
          ),
          SizedBox(
            height: _size!.height * 0.02,
          ),
          InkWell(
            onTap: () async {
              FocusScope.of(context).requestFocus(FocusNode());
              File selectFiles = await Navigator.push(
                  context,
                  PageTransition(
                      child: AddLabourImage(),
                      type: PageTransitionType.rightToLeft));
              if (![null, ""].contains(selectFiles)) {
                labourFile = selectFiles;
              }
            },
            child: Container(
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colours.YELLOW_LIGHT),
                    ),
                    child: Icon(
                      Icons.add,
                      color: Colours.YELLOW_LIGHT,
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Add Labour Images",
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colours.YELLOW_LIGHT),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          labourImage != null
              ? InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        PageTransition(
                            child: ImagePreviewScreen(
                              path: "http://asiyaiheavyvehicle.com" +
                                  labourImage!,
                            ),
                            type: PageTransitionType.bottomToTop));
                  },
                  child: Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: FadeImageWithError(
                        imgPath: "http://asiyaiheavyvehicle.com" + labourImage!,
                      ),
                    ),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
