import 'package:alt_sms_autofill/alt_sms_autofill.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/app_constants.dart';
import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';

import 'package:asiayai_heavy_vehicle_app/view/SigunUp/signup_page.dart';
import 'package:asiayai_heavy_vehicle_app/widgets/loading_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'package:timer_count_down/timer_controller.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/app_snack_bar.dart';
import '../../widgets/customs_button.dart';
import '../../widgets/logo_text.dart';
import '../../widgets/show_dialog.dart';
import '../../widgets/textfield.dart';

class SignUpOTP extends StatefulWidget {
  String? phone_number;
  SignUpOTP({this.phone_number});
  @override
  State<SignUpOTP> createState() => _SignUpOTPState();
}

class _SignUpOTPState extends State<SignUpOTP> {
//variables
  TextEditingController otpController = TextEditingController();
//
  final _formKey = GlobalKey<FormState>();
  // String? phoneNumber;

  @override
  void initState() {
    getData();
    print("PHONE NUMBER >>>>>>>>>" + widget.phone_number.toString());
    super.initState();
  }

  getData() async {
    textEditingController1 = TextEditingController();
    await initSmsListener();
  }

  // getData() async {
  //   SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  //   phoneNumber = sharedPreferences.getString(AppConstants.USER_PHONE);
  // }

  TextEditingController textEditingController1 = TextEditingController();

  String _comingSms = 'Unknown';

  Future<void> initSmsListener() async {
    String? comingSms;
    try {
      comingSms = await AltSmsAutofill().listenForSms;
    } on PlatformException {
      comingSms = 'Failed to get Sms.';
    }
    if (!mounted) return;
    setState(() {
      _comingSms = comingSms!;
      print("====>Message: ${_comingSms}");
      print("${_comingSms.substring(4)}");
      textEditingController1.text =
          _comingSms[4] + _comingSms[5] + _comingSms[6] + _comingSms[7];
      // _comingSms[7] +
      // _comingSms[
      //     37]; //used to set the code in the message to a string and setting it to a textcontroller. message length is 38. so my code is in string index 32-37.
    });
  }

  _listenSmsCode() async {
    await SmsAutoFill().listenForCode();
  }

  @override
  void dispose() {
    // SmsAutoFill().unregisterListener();
    textEditingController1.dispose();
    AltSmsAutofill().unregisterListener();
    super.dispose();
  }

  CountdownController countdownController = CountdownController();
  TextEditingController textEditingController = TextEditingController();
  var messageOtpCode = '';

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        body: Consumer<UserProvider>(builder: (context, model, child) {
          return Form(
            key: _formKey,
            child: Container(
              height: size.height,
              width: double.infinity,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(Images.app_bg),
                  fit: BoxFit.fill,
                ),
              ),
              child: Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: size.width / 24, vertical: size.height / 80),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    const LogoText(),
                    SizedBox(height: size.height * 0.03),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: size.width / 24,
                      ),
                      margin: EdgeInsets.symmetric(vertical: size.height / 100),
                      decoration: BoxDecoration(
                        color: Colours.PRIMARY_BLUE_MILD,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "+91-" + widget.phone_number.toString(),
                            style: TextStyles.ktext16(context).copyWith(
                                color: Colours.PRIMARY_GREY_LIGHT,
                                fontWeight: FontWeight.w500),
                          ),
                          TextButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => const SignUp(),
                                    ));
                              },
                              child: Text(
                                "Change?",
                                style: TextStyles.ktext16(context).copyWith(
                                    color: Colours.YELLOW_DARK,
                                    fontWeight: FontWeight.w500),
                              ))
                        ],
                      ),
                    ),
                    SizedBox(height: size.height * 0.02),
                    /*   // PinFieldAutoFill(
                    //   codeLength: 4,
                    //   autoFocus: true,
                    //   decoration: UnderlineDecoration(
                    //     lineHeight: 2,
                    //     lineStrokeCap: StrokeCap.square,
                    //     textStyle: TextStyle(color: Colours.YELLOW_DARK),
                    //     bgColorBuilder: PinListenColorBuilder(
                    //       Colours.PRIMARY_BLUE_MILD,
                    //       Colours.PRIMARY_BLUE_MILD,
                    //     ),
                    //     colorBuilder:
                    //         const FixedColorBuilder(Colors.transparent),
                    //   ),
                    // ), */
                    /*  IconTextField(
                      title: "Enter OTP",
                      controller: otpController,
                      textInputType: TextInputType.phone,
                      image: Images.phone_icon,
                      onValidate: (value) {
                        if (value.isEmpty) {
                          return "OTP Required";
                        } else {
                          null;
                        }
                      },
                    ),*/
                    PinCodeTextField(
                      appContext: context,
                      pastedTextStyle: TextStyle(
                        color: Colors.green.shade600,
                        fontWeight: FontWeight.bold,
                      ),
                      length: 4,
                      obscureText: false,
                      animationType: AnimationType.fade,
                      pinTheme: PinTheme(
                        shape: PinCodeFieldShape.box,
                        borderRadius: BorderRadius.circular(10),
                        fieldHeight: 50,
                        fieldWidth: 40,
                        inactiveFillColor: Colors.white,
                        inactiveColor: Colours.PRIMARY_GREY_LIGHT,
                        selectedColor: Colours.PRIMARY_GREY_LIGHT,
                        selectedFillColor: Colors.white,
                        activeFillColor: Colors.white,
                        activeColor: Colours.PRIMARY_GREY_LIGHT,
                      ),
                      cursorColor: Colors.black,
                      animationDuration: Duration(milliseconds: 300),
                      enableActiveFill: true,
                      controller: textEditingController1,
                      keyboardType: TextInputType.number,
                      boxShadows: [
                        BoxShadow(
                          offset: Offset(0, 1),
                          color: Colors.black12,
                          blurRadius: 10,
                        )
                      ],
                      onCompleted: (v) {
                        //do something or move to next screen when code complete
                      },
                      onChanged: (value) {
                        print(value);
                        setState(() {
                          print('$value');
                        });
                      },
                    ),
                    SizedBox(
                      height: size.height * 0.05,
                    ),

                    //
                  ],
                ),
              ),
            ),
          );
        }),
        bottomNavigationBar:
            Consumer<UserProvider>(builder: (context, model, child) {
          return Wrap(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: size.width / 24,
                ),
                child: CustomButton(
                  height: size.height / 16,
                  text: "SIGNUP",
                  textColor: Colours.PRIMARY_BLACK,
                  onTap: () async {
                    if (textEditingController1.text.isNotEmpty) {
                      await model.otpVerify(context,
                          otp: textEditingController1.text,
                          phoneNumber: widget.phone_number.toString());
                    } else {
                      showTostMsg("Please Enter OTP!!");
                    }
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: size.width / 24, vertical: size.height / 40),
                child: CustomButton(
                  buttonColor: Colours.SKY_BLUE_MID,
                  height: size.height / 16,
                  text: "RESEND OTP",
                  textColor: Colours.PRIMARY_BLACK,
                  onTap: () async {
                    loginCalled(model);
                    // final authProvider =
                    //     Provider.of<AuthProvider>(context, listen: false);
                    // await authProvider.sendOtp(
                    //     phnNumber: phoneNumber, context: context);
                  },
                ),
              ),
            ],
          );
        }));
  }

  loginCalled(UserProvider model) async {
    if (widget.phone_number.toString().isNotEmpty &&
        widget.phone_number.toString().length == 10) {
      await model.loginAPI(context,
          phone_number: widget.phone_number.toString());
    } else {
      showTostMsg("Enter Details");
    }
  }
}
