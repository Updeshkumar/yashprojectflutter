import 'package:asiayai_heavy_vehicle_app/helper/validation.dart';
import 'package:asiayai_heavy_vehicle_app/provider/UserProvider.dart';

import 'package:asiayai_heavy_vehicle_app/utils/common.dart';
import 'package:asiayai_heavy_vehicle_app/utils/images.dart';

import 'package:asiayai_heavy_vehicle_app/view/SigunUp/otp_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../../utils/colour_resource.dart';
import '../../utils/text_styles.dart';
import '../../widgets/app_snack_bar.dart';
import '../../widgets/customs_button.dart';
import '../../widgets/logo_text.dart';
import '../../widgets/show_dialog.dart';
import '../../widgets/textfield.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  //
  // variables
  final _globalKey = GlobalKey<FormState>();
  TextEditingController _phoneController = TextEditingController();

  // methods
  Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context);
        }));

    return request;
  }

  // build method

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Consumer<UserProvider>(builder: (context, model, child) {
      return Scaffold(
        backgroundColor: Colours.PRIMARY_BLUE,
        body: WillPopScope(
          onWillPop: _onBackButtonPressed,
          child: Form(
            key: _globalKey,
            child: Container(
              height: size.height,
              width: double.infinity,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(Images.app_bg),
                  fit: BoxFit.fill,
                ),
              ),
              child: Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: size.width / 24, vertical: size.width / 80),
                child: ListView(
                  // mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: size.height * 0.3,
                    ),
                    const LogoText(),
                    SizedBox(
                      height: size.height / 80,
                    ),

                    IconTextField(
                      title: "Enter Mobile Number".tr().toString(),
                      image: Images.phone_icon,
                      controller: _phoneController,
                      textInputType: TextInputType.number,
                      textInputFormatter: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(10),
                      ],
                    ),

                    SizedBox(
                      height: size.height / 80,
                    ),
                    //
                    CustomButton(
                      height: size.height / 16,
                      text: "CONTINUE".tr().toString(),
                      textColor: Colours.PRIMARY_BLACK,
                      onTap: () async {
                        final String signature =
                            await SmsAutoFill().getAppSignature;
                        print("Signature: $signature");
                        loginCalled(model);
                      },
                    ),
                    SizedBox(
                      height: size.height / 20,
                    ),

                    /*   Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Existing User Login",
                        style: TextStyles.ktext16(context),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height / 40,
                  ),
                  CustomButton(
                    buttonColor: Colors.white,
                    height: size.height / 16,
                    text: "EXISTING USER LOGIN",
                    textColor: Colours.PRIMARY_BLACK,
                    image: Images.person_icon,
                    onTap: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => LogIn()));
                    },
                  ),
                  SizedBox(
                    height: size.height / 80,
                  ) */
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    });
  }

  loginCalled(UserProvider model) async {
    if (_phoneController.text.isNotEmpty &&
        _phoneController.text.length == 10) {
      await model.loginAPI(context,
          phone_number: _phoneController.text.toString());
    } else {
      showTostMsg("Something went wrong");
    }
  }
}
