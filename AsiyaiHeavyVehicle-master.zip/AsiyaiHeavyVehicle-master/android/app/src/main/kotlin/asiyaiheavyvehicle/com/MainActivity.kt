package asiyaiheavyvehicle.com

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
